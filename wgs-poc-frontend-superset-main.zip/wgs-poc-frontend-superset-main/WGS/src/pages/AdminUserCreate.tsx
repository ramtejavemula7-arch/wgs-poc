import { useEffect, useState, type FormEvent } from "react";
import {
  AlertTriangle,
  ClipboardPlus,
  Edit2,
  Loader2,
  Trash2,
  UserPlus,
  X,
} from "lucide-react";
import { apiFetch } from "../utils/api";
import SidebarLayout from "../components/SidebarLayout";
import StyledSelect from "../components/StyledSelect";
import PageChatbot from "../components/PageChatbot";
import LogoSpinner from "../components/LogoSpinner";

type RoleRecord = {
  id?: string | number;
  name?: string;
  [key: string]: unknown;
};

const normalizeRoles = (data: unknown): RoleRecord[] =>
  Array.isArray(data)
    ? (data as RoleRecord[])
    : data && typeof data === "object"
      ? Array.isArray((data as { results?: unknown }).results)
        ? ((data as { results: RoleRecord[] }).results ?? [])
        : Array.isArray((data as { roles?: unknown }).roles)
          ? ((data as { roles: RoleRecord[] }).roles ?? [])
          : [data as RoleRecord]
      : [];

import { API } from "../utils/api-endpoints";
const ADMIN_CREATE_API = API.users.create;
const ADMIN_ROLES_API = API.roles.list;

type AdminUser = {
  id?: string | number;
  username?: string;
  email?: string;
  role?: string;
  role_name?: string;
  role_id?: string | number;
  is_active?: boolean;
  first_name?: string;
  last_name?: string;
  [key: string]: unknown;
};

const normalizeUsers = (data: unknown): AdminUser[] =>
  Array.isArray(data)
    ? (data as AdminUser[])
    : data && typeof data === "object"
      ? Array.isArray((data as { results?: unknown }).results)
        ? ((data as { results: AdminUser[] }).results ?? [])
        : Array.isArray((data as { users?: unknown }).users)
          ? ((data as { users: AdminUser[] }).users ?? [])
          : [data as AdminUser]
      : [];

function getUserName(user: AdminUser) {
  return (
    user.username ||
    [user.first_name, user.last_name].filter(Boolean).join(" ") ||
    user.email ||
    String(user.id ?? "Unknown")
  );
}

export default function AdminUserCreate() {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [usersLoading, setUsersLoading] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [usersError, setUsersError] = useState<string | null>(null);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [editingUser, setEditingUser] = useState<AdminUser | null>(null);
  const [rolesLoading, setRolesLoading] = useState(false);
  const [availableRoles, setAvailableRoles] = useState<RoleRecord[]>([]);
  const [confirmingDelete, setConfirmingDelete] = useState<AdminUser | null>(null);
  const [deletingId, setDeletingId] = useState<string | number | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const resetForm = () => {
    setUsername("");
    setEmail("");
    setRole("");
    setEditingUser(null);
  };

  const openCreateDrawer = () => {
    setError(null);
    setSuccess(null);
    resetForm();
    setIsDrawerOpen(true);
  };

  const openEditDrawer = (user: AdminUser) => {
    setError(null);
    setSuccess(null);
    setEditingUser(user);
    setUsername(user.username || "");
    setEmail(user.email || "");
    setRole("");
    setIsDrawerOpen(true);
  };

  const loadUsers = async () => {
    setUsersError(null);
    setUsersLoading(true);

    try {
      const response = await apiFetch(ADMIN_CREATE_API);
      if (!response.ok) {
        const text = await response.text();
        throw new Error(text || "Failed to load users.");
      }

      const contentType = response.headers.get("content-type") || "";
      if (!contentType.includes("application/json")) {
        const text = await response.text();
        throw new Error(
          text.includes("<!doctype")
            ? "The users API returned HTML instead of JSON."
            : text || "The users API did not return JSON."
        );
      }

      const data = await response.json();
      setUsers(normalizeUsers(data));
    } catch (err) {
      setUsers([]);
      setUsersError(err instanceof Error ? err.message : "Failed to load users.");
    } finally {
      setUsersLoading(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!confirmingDelete?.id) return;
    const user = confirmingDelete;
    setDeleteError(null);
    setDeletingId(user.id!);

    try {
      const resp = await apiFetch(API.users.delete(user.id!), { method: "DELETE" });
      if (!resp.ok) {
        const body = await resp.json().catch(() => null);
        throw new Error(body?.detail || "Unable to delete the user.");
      }
      setUsers((prev) => prev.filter((u) => u.id !== user.id));
      setConfirmingDelete(null);
    } catch (err) {
      setDeleteError(err instanceof Error ? err.message : "Unable to delete the user.");
    } finally {
      setDeletingId(null);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    setSuccess(null);

    if (!username.trim()) {
      setError("Please enter the username.");
      return;
    }

    if (!email.trim()) {
      setError("Please enter the user's email address.");
      return;
    }
    if (!role.trim()) {
      setError("Please select a role.");
      return;
    }

    setLoading(true);

    try {
      const isEditing = Boolean(editingUser?.id);
      const targetUrl = isEditing
        ? `${ADMIN_CREATE_API}${editingUser?.id}`
        : ADMIN_CREATE_API;

      const response = await apiFetch(targetUrl, {
        method: isEditing ? "PUT" : "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username: username.trim(),
          email: email.trim(),
          role_id: role,
        }),
      });

      const body = await response.json().catch(() => null);

      if (!response.ok) {
        throw new Error(body?.message || "Unable to create user.");
      }

      setSuccess(
        body?.message ||
          (isEditing
            ? "User updated successfully."
            : "User created successfully. An activation email can now be sent.")
      );
      resetForm();
      setIsDrawerOpen(false);
      await loadUsers();
    } catch (err) {
      setError(err instanceof Error ? err.message : "User creation failed.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    let isMounted = true;

    const loadRoleOptions = async () => {
      setRolesLoading(true);

      try {
        const response = await apiFetch(ADMIN_ROLES_API);
        if (!response.ok) return;

        const contentType = response.headers.get("content-type") || "";
        if (!contentType.includes("application/json")) return;

        const data = await response.json();
        if (isMounted) {
          setAvailableRoles(normalizeRoles(data));
        }
      } catch (err) {
        if (isMounted) {
          setAvailableRoles([]);
          setError(err instanceof Error ? err.message : "Failed to load roles.");
        }
      } finally {
        if (isMounted) {
          setRolesLoading(false);
        }
      }
    };

    loadRoleOptions();

    return () => {
      isMounted = false;
    };
  }, []);

  // When editingUser or availableRoles change, resolve the role name → ID match.
  // Handles: roles loading after drawer opens, and GET detail returning a name string.
  useEffect(() => {
    if (!isDrawerOpen || !editingUser || !availableRoles.length) return;
    setRole((current) => {
      // Already set to a valid role ID — keep it
      if (current && availableRoles.some((r) => String(r.id) === current)) return current;
      // Try match by role_id first, then by name
      if (editingUser.role_id) {
        const byId = availableRoles.find((r) => String(r.id) === String(editingUser.role_id));
        if (byId) return String(byId.id ?? "");
      }
      const name = (editingUser.role_name || editingUser.role || "").toString().toLowerCase();
      if (name) {
        const byName = availableRoles.find((r) => r.name?.toString().toLowerCase() === name);
        if (byName) return String(byName.id ?? "");
      }
      return current;
    });
  }, [availableRoles, editingUser, isDrawerOpen]);

  return (
    <>
      <SidebarLayout active="admin-users" contentClassName="p-8">
          <div className="mb-8 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-[#00796B]/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.2em] text-[#00796B]">
                <ClipboardPlus size={14} />
                Admin action
              </div>
              <h1 className="text-3xl font-semibold text-slate-900">
                User
              </h1>
              <p className="mt-2 max-w-3xl text-sm text-slate-600">
                Create a user without a password, assign a role, and trigger the
                activation flow so the user can set their password from the email link.
              </p>
            </div>

            <div className="flex flex-wrap gap-3">
              <button
                type="button"
                onClick={openCreateDrawer}
                className="inline-flex items-center gap-2 rounded-lg bg-[#00796B] px-4 py-2 text-sm font-semibold text-white transition hover:bg-[#00695C]"
              >
                <UserPlus size={16} />
                Add User
              </button>
            </div>
          </div>

          <section className="rounded-3xl border border-slate-200 p-6 shadow-sm">


            {usersLoading ? (
              <div className="flex items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-10 text-center text-sm font-medium text-slate-500">
                <LogoSpinner className="h-5 w-5" />
                Loading users...
              </div>
            ) : usersError ? (
              <div className="rounded-2xl bg-red-50 p-4 text-sm text-red-700">
                {usersError}
              </div>
            ) : users.length ? (
              <div className="overflow-hidden rounded-2xl border border-slate-200">
                <div className="max-h-[60vh] overflow-auto">
                  <table className="min-w-full divide-y divide-slate-200 text-left text-sm">
                    <thead className="sticky top-0 bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                      <tr>
                        <th className="px-4 py-3">User</th>
                        <th className="px-4 py-3">Username</th>
                        <th className="px-4 py-3">Email</th>
                        <th className="px-4 py-3">Role</th>
                        <th className="px-4 py-3">Status</th>
                        <th className="px-4 py-3 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {users.map((user, index) => (
                        <tr key={String(user.id ?? user.username ?? index)}>
                          <td className="px-4 py-3 font-medium text-slate-900">
                            {getUserName(user)}
                          </td>
                          <td className="px-4 py-3 text-slate-600">
                            {user.username || "-"}
                          </td>
                          <td className="px-4 py-3 text-slate-600">
                            {user.email || "-"}
                          </td>
                          <td className="px-4 py-3 text-slate-600">
                            {user.role_name || user.role || "-"}
                          </td>
                          <td className="px-4 py-3 text-slate-600">
                            {user.is_active === false ? "Inactive" : "Active"}
                          </td>
                          <td className="px-4 py-3 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                type="button"
                                onClick={() => openEditDrawer(user)}
                                className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 transition hover:border-[#00796B] hover:text-[#00796B]"
                              >
                                <Edit2 size={14} />
                                Edit
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setDeleteError(null);
                                  setConfirmingDelete(user);
                                }}
                                disabled={deletingId === user.id}
                                className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-red-600 transition hover:border-red-300 hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-50"
                              >
                                <Trash2 size={14} />
                                Delete
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-4 py-10 text-center text-sm font-medium text-slate-500">
                No users found.
              </div>
            )}
          </section>
      </SidebarLayout>

      <PageChatbot agentType="users" pageData={{ users }} />

      {isDrawerOpen ? (
        <div className="fixed inset-0 z-50">
          <button
            type="button"
            aria-label="Close user drawer"
            className="overlay-enter absolute inset-0 bg-black/40"
            onClick={() => setIsDrawerOpen(false)}
          />

          <aside className="drawer-enter absolute right-0 top-0 flex h-full w-full max-w-2xl flex-col overflow-hidden bg-white shadow-2xl">
            <div className="flex items-start justify-between border-b border-slate-200 px-6 py-5">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">
                  {editingUser ? "Edit User" : "Add User"}
                </h2>
                <p className="mt-1 text-sm text-slate-600">
                  {editingUser
                    ? "Update the selected user's details."
                    : "Create a new user and trigger the activation flow."}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setIsDrawerOpen(false)}
                className="rounded-full p-2 text-slate-500 transition hover:bg-slate-100 hover:text-slate-700"
              >
                <X size={20} />
              </button>
            </div>

            <div className="flex flex-1 flex-col overflow-hidden px-6 py-5">
              <div className="mb-4">
                <h3 className="text-base font-bold text-slate-900">
                  {editingUser ? "Edit form" : "Add form"}
                </h3>
                <p className="mt-1 text-sm text-slate-600">
                  Fill in the fields below to {editingUser ? "update" : "create"} a
                  user.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <label className="block">
                  <span className="text-sm font-semibold text-slate-700">
                    Username
                  </span>
                  <input
                    type="text"
                    value={username}
                    onChange={(event) => setUsername(event.target.value)}
                    placeholder="Enter username"
                    className="mt-2 h-11 w-full rounded-lg border border-slate-300 px-3 text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
                  />
                </label>

                <label className="block">
                  <span className="text-sm font-semibold text-slate-700">
                    Email
                  </span>
                  <input
                    type="email"
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                    placeholder="Enter user email"
                    className="mt-2 h-11 w-full rounded-lg border border-slate-300 px-3 text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
                  />
                </label>

                <label className="block">
                  <span className="text-sm font-semibold text-slate-700">
                    Role
                  </span>
                  <StyledSelect
                    className="mt-2"
                    value={role}
                    onChange={setRole}
                    disabled={rolesLoading}
                    placeholder={rolesLoading ? "Loading roles..." : "Select role"}
                    options={availableRoles.map((roleItem, index) => ({
                      value: String(roleItem.id ?? ""),
                      label: roleItem.name || String(roleItem.id ?? index),
                    }))}
                  />
                </label>

                {error ? (
                  <div className="rounded-lg bg-red-50 p-3 text-sm text-red-700">
                    {error}
                  </div>
                ) : null}

                {success ? (
                  <div className="rounded-lg bg-emerald-50 p-3 text-sm text-emerald-700">
                    {success}
                  </div>
                ) : null}

                <div className="flex gap-3 pt-1">
                  <button
                    type="submit"
                    disabled={loading}
                    className="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-lg bg-[#00796B] font-semibold text-white transition hover:bg-[#00695C] disabled:cursor-not-allowed disabled:bg-slate-400"
                  >
                    <UserPlus size={16} />
                    {loading
                      ? editingUser
                        ? "Saving..."
                        : "Creating user..."
                      : editingUser
                        ? "Save changes"
                        : "Create User"}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setIsDrawerOpen(false);
                      resetForm();
                    }}
                    className="inline-flex h-11 flex-1 items-center justify-center rounded-lg border border-slate-300 bg-white font-semibold text-slate-700 transition hover:border-[#00796B] hover:text-[#00796B]"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </aside>
        </div>
      ) : null}

      {confirmingDelete && (
        <div className="overlay-enter fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4">
          <div className="modal-enter w-full max-w-sm rounded-2xl bg-white p-6 shadow-2xl">
            <div className="mb-4 flex items-center gap-3">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-red-100 text-red-600">
                <AlertTriangle size={20} />
              </div>
              <h2 className="text-lg font-bold text-slate-900">Delete User</h2>
            </div>

            <p className="text-sm text-slate-600">
              Delete <span className="font-semibold text-slate-900">&quot;{getUserName(confirmingDelete)}&quot;</span>?
              This cannot be undone.
            </p>

            {deleteError ? (
              <div className="mt-3 rounded-lg bg-red-50 p-3 text-sm text-red-700">{deleteError}</div>
            ) : null}

            <div className="mt-6 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setConfirmingDelete(null)}
                disabled={deletingId === confirmingDelete.id}
                className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => void handleConfirmDelete()}
                disabled={deletingId === confirmingDelete.id}
                className="inline-flex items-center gap-2 rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {deletingId === confirmingDelete.id && <Loader2 size={14} className="animate-spin" />}
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
