import { useEffect, useRef, useState, type ChangeEvent, type FormEvent, type KeyboardEvent } from "react";
import { useNavigate } from "react-router-dom";
import { Bot, Check, ChevronDown, Send, Sparkles, User } from "lucide-react";
import SidebarLayout from "../components/SidebarLayout";
import ChatChart from "../components/ChatChart";
import { apiFetch } from "../utils/api";
import { API } from "../utils/api-endpoints";
import { logout } from "../utils/auth";

type ChatTable = {
  columns: string[];
  rows: unknown[][];
};

type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
  isError?: boolean;
  table?: ChatTable | null;
  chart?: object | null;
};

type ChatResponse = {
  answer: string;
  sql: string | null;
  table: ChatTable | null;
  chart: object | null;
};

type ChatErrorResponse = {
  detail?: string;
};

type DataAgentOption = {
  name: string;
  display_name: string;
};

const MAX_QUESTION_LENGTH = 2000;

function createMessageId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

export default function ChatAssistant() {
  const navigate = useNavigate();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [availableAgents, setAvailableAgents] = useState<DataAgentOption[]>([]);
  const [selectedAgent, setSelectedAgent] = useState("");
  const [isAgentMenuOpen, setIsAgentMenuOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const agentMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  useEffect(() => {
    if (!isAgentMenuOpen) return;
    const handleClickOutside = (event: MouseEvent) => {
      if (agentMenuRef.current && !agentMenuRef.current.contains(event.target as Node)) {
        setIsAgentMenuOpen(false);
      }
    };
    const handleEscape = (event: globalThis.KeyboardEvent) => {
      if (event.key === "Escape") setIsAgentMenuOpen(false);
    };
    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleEscape);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleEscape);
    };
  }, [isAgentMenuOpen]);

  useEffect(() => {
    const loadAgents = async () => {
      try {
        const resp = await apiFetch(API.chat.agents);
        if (!resp.ok) return;
        const data = (await resp.json()) as DataAgentOption[];
        setAvailableAgents(data);
      } catch {
        // Agent picker is optional — silently fall back to direct SQL generation.
      }
    };
    void loadAgents();
  }, []);

  const askQuestion = async (rawQuestion: string) => {
    const question = rawQuestion.trim();
    if (!question || question.length > MAX_QUESTION_LENGTH || isLoading) return;

    setMessages((prev) => [...prev, { id: createMessageId(), role: "user", content: question }]);
    setInput("");
    if (textareaRef.current) textareaRef.current.style.height = "auto";
    setIsLoading(true);

    const appendError = (content: string) => {
      setMessages((prev) => [...prev, { id: createMessageId(), role: "assistant", content, isError: true }]);
    };

    try {
      const resp = await apiFetch(API.chat.ask, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question, data_agent: selectedAgent || null }),
        timeout: 90_000, // LLM responses legitimately take longer than the 30s default.
      });

      if (resp.status === 401) {
        appendError("Your session has expired. Please log in again.");
        logout();
        navigate("/login");
        return;
      }

      if (!resp.ok) {
        if (resp.status === 404) {
          appendError("Couldn't load context for this dashboard.");
          return;
        }

        let detail = "Something went wrong. Please try again.";
        try {
          const data = (await resp.json()) as ChatErrorResponse;
          if (data?.detail) detail = data.detail;
        } catch {
          // Response body wasn't valid JSON; fall back to the generic message.
        }
        appendError(detail);
        return;
      }

      const data = (await resp.json()) as ChatResponse;
      setMessages((prev) => [
        ...prev,
        {
          id: createMessageId(),
          role: "assistant",
          content: data.answer,
          table: data.table ?? null,
          chart: data.chart ?? null,
        },
      ]);
    } catch {
      appendError("Couldn't reach the server. Please check your connection and try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    void askQuestion(input);
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      void askQuestion(input);
    }
  };

  const handleInputChange = (event: ChangeEvent<HTMLTextAreaElement>) => {
    setInput(event.target.value);
    const el = event.target;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 160)}px`;
  };

  const canSend = input.trim().length > 0 && input.trim().length <= MAX_QUESTION_LENGTH && !isLoading;

  const selectedAgentOption = availableAgents.find((agent) => agent.name === selectedAgent);
  const agentButtonLabel = selectedAgentOption ? selectedAgentOption.display_name : "No agent";

  const chooseAgent = (agentName: string) => {
    setSelectedAgent(agentName);
    setIsAgentMenuOpen(false);
  };

  return (
    <SidebarLayout active="chat-assistant" contentClassName="flex h-full flex-col overflow-hidden p-0">
      <div className="flex h-full flex-col">
        <div className="border-b border-slate-200 bg-white px-8 py-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#00796B]/10 text-[#00796B]">
              <Sparkles size={20} />
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-900">Chat Assistant</h1>
              <p className="text-xs text-slate-500">Ask questions about your data in BigQuery</p>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-8 py-6">
          {messages.length === 0 ? (
            <div className="mx-auto flex h-full max-w-2xl flex-col items-center justify-center text-center">
              <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#00796B]/10 text-[#00796B]">
                <Bot size={28} />
              </div>
              <h2 className="text-xl font-bold text-slate-900">How can I help you today?</h2>
              <p className="mt-2 max-w-md text-sm text-slate-500">
                Ask questions about your data in BigQuery. I can help you analyze data,
                summarize results, and find insights in natural language.
              </p>
            </div>
          ) : (
            <div className="mx-auto flex max-w-3xl flex-col gap-6">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex items-start gap-3 ${
                    message.role === "user" ? "flex-row-reverse" : "flex-row"
                  }`}
                >
                  <div
                    className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${
                      message.role === "user"
                        ? "bg-slate-700 text-white"
                        : "bg-[#00796B]/10 text-[#00796B]"
                    }`}
                  >
                    {message.role === "user" ? <User size={16} /> : <Bot size={16} />}
                  </div>

                  <div
                    className={`max-w-[75%] rounded-2xl px-4 py-3 text-sm leading-relaxed shadow-sm ${
                      message.role === "user"
                        ? "rounded-tr-sm bg-[#00796B] text-white"
                        : message.isError
                          ? "rounded-tl-sm border border-red-200 bg-red-50 text-red-700"
                          : "rounded-tl-sm border border-slate-200 bg-white text-slate-800"
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{message.content}</p>

                    {message.table ? (
                      <div className="mt-3 max-w-full overflow-x-auto rounded-lg border border-slate-200">
                        <table className="min-w-full text-left text-xs">
                          <thead className="bg-slate-50">
                            <tr>
                              {message.table.columns.map((col) => (
                                <th key={col} className="whitespace-nowrap px-3 py-2 font-semibold text-slate-700">
                                  {col}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {message.table.rows.map((row, rowIndex) => (
                              <tr key={rowIndex}>
                                {row.map((cell, cellIndex) => (
                                  <td key={cellIndex} className="whitespace-nowrap px-3 py-2 text-slate-700">
                                    {cell === null || cell === undefined ? "" : String(cell)}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    ) : null}

                    {message.chart ? (
                      <div className="mt-3">
                        <ChatChart spec={message.chart} />
                      </div>
                    ) : null}
                  </div>
                </div>
              ))}

              {isLoading && (
                <div className="flex items-start gap-3">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[#00796B]/10 text-[#00796B]">
                    <Bot size={16} />
                  </div>
                  <div className="flex items-center gap-1 rounded-2xl rounded-tl-sm border border-slate-200 bg-white px-4 py-3 shadow-sm">
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-slate-400 [animation-delay:-0.3s]" />
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-slate-400 [animation-delay:-0.15s]" />
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-slate-400" />
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        <div className="border-t border-slate-200 bg-white px-8 py-4">
          <form onSubmit={handleSubmit} className="mx-auto flex max-w-3xl items-end gap-3">
            {availableAgents.length > 0 && (
              <div ref={agentMenuRef} className="relative shrink-0">
                {isAgentMenuOpen && (
                  <div className="absolute bottom-full left-0 z-10 mb-2 w-72 overflow-hidden rounded-2xl border border-slate-200 bg-white py-1.5 shadow-lg">
                    <button
                      type="button"
                      onClick={() => chooseAgent("")}
                      className="flex w-full items-start justify-between gap-3 px-3 py-2 text-left transition hover:bg-slate-50"
                    >
                      <span>
                        <span className="block text-sm font-medium text-slate-900">No agent</span>
                        <span className="block text-xs text-slate-500">Direct SQL generation with Gemini</span>
                      </span>
                      {!selectedAgent && <Check size={16} className="mt-0.5 shrink-0 text-[#00796B]" />}
                    </button>

                    <div className="my-1 border-t border-slate-100" />

                    {availableAgents.map((agent) => (
                      <button
                        key={agent.name}
                        type="button"
                        onClick={() => chooseAgent(agent.name)}
                        className="flex w-full items-start justify-between gap-3 px-3 py-2 text-left transition hover:bg-slate-50"
                      >
                        <span>
                          <span className="block text-sm font-medium text-slate-900">{agent.display_name}</span>
                          <span className="block text-xs text-slate-500">BigQuery Data Agent</span>
                        </span>
                        {selectedAgent === agent.name && (
                          <Check size={16} className="mt-0.5 shrink-0 text-[#00796B]" />
                        )}
                      </button>
                    ))}
                  </div>
                )}

                <button
                  type="button"
                  onClick={() => setIsAgentMenuOpen((v) => !v)}
                  disabled={isLoading}
                  title="Data Agent"
                  className="flex h-11 items-center gap-1.5 rounded-2xl border border-slate-300 bg-white px-3 text-xs font-medium text-slate-700 outline-none transition hover:bg-slate-50 focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20 disabled:bg-slate-50"
                >
                  <span className="max-w-[8rem] truncate">{agentButtonLabel}</span>
                  <ChevronDown size={14} className="shrink-0 text-slate-400" />
                </button>
              </div>
            )}
            <textarea
              ref={textareaRef}
              value={input}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              placeholder="Message the assistant..."
              rows={1}
              disabled={isLoading}
              maxLength={MAX_QUESTION_LENGTH}
              className="max-h-40 flex-1 resize-none rounded-2xl border border-slate-300 px-4 py-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20 disabled:bg-slate-50"
            />
            <button
              type="submit"
              disabled={!canSend}
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#00796B] text-white transition hover:bg-[#00695C] disabled:cursor-not-allowed disabled:opacity-40"
              title="Send message"
            >
              <Send size={18} />
            </button>
          </form>
        </div>
      </div>
    </SidebarLayout>
  );
}
