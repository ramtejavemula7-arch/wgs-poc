import { useEffect, useState, type FormEvent } from "react";
import {
  ClipboardPlus,
  Edit2,
  Lock,
  Save,
  Shield,
  X,
} from "lucide-react";
import { apiFetch } from "../utils/api";
import { getCurrentRole } from "../utils/auth";
import SidebarLayout from "../components/SidebarLayout";
import PageChatbot from "../components/PageChatbot";
import LogoSpinner from "../components/LogoSpinner";
import { API } from "../utils/api-endpoints";

const ROLES_API = API.roles.list;

type AccessLevel = "none" | "read" | "edit";

type PermissionEntry = {
  module: string;
  access_level: AccessLevel;
};

type RoleRecord = {
  id?: string | number;
  name?: string;
  created_by?: string;
  created_at?: string;
  permissions?: PermissionEntry[];
  [key: string]: unknown;
};

const PERMISSION_MODULES: { key: string; label: string }[] = [
  { key: "dashboard", label: "Dashboard" },
  { key: "reports", label: "Reports" },
  { key: "transaction_search", label: "Transaction Search" },
  { key: "rest_endpoints", label: "API Endpoints" },
  { key: "admin", label: "Admin" },
  { key: "users", label: "Users" },
  { key: "roles", label: "Roles" },
];

/** The Admin/Users/Roles nav (AppSidebar.tsx) is gated on the literal "admin" role name, not on
 *  these permission entries — so setting them for any other role is a no-op. Only show them when
 *  editing the built-in Admin role itself. */
const ADMIN_ONLY_MODULE_KEYS = new Set(["admin", "users", "roles"]);

type PermissionsMatrix = Record<string, AccessLevel>;

function buildPermissionsMatrix(entries?: PermissionEntry[] | null): PermissionsMatrix {
  const byModule = new Map((entries ?? []).map((entry) => [entry.module, entry.access_level]));
  return PERMISSION_MODULES.reduce((acc, module) => {
    const value = byModule.get(module.key);
    acc[module.key] = value === "none" || value === "edit" ? value : "read";
    return acc;
  }, {} as PermissionsMatrix);
}

function permissionsMatrixToArray(matrix: PermissionsMatrix): PermissionEntry[] {
  return PERMISSION_MODULES.map((module) => ({
    module: module.key,
    access_level: matrix[module.key] ?? "read",
  }));
}

const normalizeRoles = (data: unknown): RoleRecord[] =>
  Array.isArray(data)
    ? (data as RoleRecord[])
    : data && typeof data === "object"
      ? Array.isArray((data as { results?: unknown }).results)
        ? ((data as { results: RoleRecord[] }).results ?? [])
        : Array.isArray((data as { roles?: unknown }).roles)
          ? ((data as { roles: RoleRecord[] }).roles ?? [])
          : [data as RoleRecord]
      : [];

function getRoleName(role: RoleRecord) {
  return role.name || String(role.id ?? "Unknown");
}

export default function AdminRolesCreate() {
  const [name, setName] = useState("");
  const [roles, setRoles] = useState<RoleRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [listLoading, setListLoading] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [listError, setListError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [editingRole, setEditingRole] = useState<RoleRecord | null>(null);

  const [permissionsMatrix, setPermissionsMatrix] = useState<PermissionsMatrix>(
    buildPermissionsMatrix()
  );
  const [permissionsSaving, setPermissionsSaving] = useState(false);
  const [permissionsError, setPermissionsError] = useState<string | null>(null);
  const [permissionsSuccess, setPermissionsSuccess] = useState<string | null>(null);

  const isAdmin = getCurrentRole() === "admin";
  const isEditingAdminRole = editingRole?.name?.trim().toLowerCase() === "admin";
  const visiblePermissionModules = isEditingAdminRole
    ? PERMISSION_MODULES
    : PERMISSION_MODULES.filter((module) => !ADMIN_ONLY_MODULE_KEYS.has(module.key));

  const resetForm = () => {
    setName("");
    setEditingRole(null);
    setPermissionsMatrix(buildPermissionsMatrix());
    setPermissionsError(null);
    setPermissionsSuccess(null);
  };

  const loadRoles = async () => {
    setListError(null);
    setListLoading(true);

    try {
      const response = await apiFetch(ROLES_API);
      if (!response.ok) {
        const text = await response.text();
        throw new Error(text || "Failed to load roles.");
      }

      const contentType = response.headers.get("content-type") || "";
      if (!contentType.includes("application/json")) {
        const text = await response.text();
        throw new Error(
          text.includes("<!doctype")
            ? "The roles API returned HTML instead of JSON."
            : text || "The roles API did not return JSON."
        );
      }

      const data = await response.json();
      setRoles(normalizeRoles(data));
    } catch (err) {
      setRoles([]);
      setListError(err instanceof Error ? err.message : "Failed to load roles.");
    } finally {
      setListLoading(false);
    }
  };

  useEffect(() => {
    loadRoles();
  }, []);

  const openCreateDrawer = () => {
    setError(null);
    setSuccess(null);
    resetForm();
    setIsDrawerOpen(true);
  };

  const openEditDrawer = (role: RoleRecord) => {
    setError(null);
    setSuccess(null);
    setEditingRole(role);
    setName(role.name || "");
    setPermissionsMatrix(buildPermissionsMatrix(role.permissions));
    setPermissionsError(null);
    setPermissionsSuccess(null);
    setIsDrawerOpen(true);
  };

  const setModuleAccess = (moduleKey: string, level: AccessLevel) => {
    setPermissionsMatrix((prev) => ({ ...prev, [moduleKey]: level }));
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    setSuccess(null);

    if (!name.trim()) {
      setError("Please enter the role name.");
      return;
    }

    setLoading(true);

    try {
      const isEditing = Boolean(editingRole?.id);
      const targetUrl = isEditing ? `${ROLES_API}${editingRole?.id}` : ROLES_API;

      const response = await apiFetch(targetUrl, {
        method: isEditing ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim(),
        }),
      });

      const body = await response.json().catch(() => null);

      if (!response.ok) {
        throw new Error(body?.message || "Unable to save role.");
      }

      setSuccess(body?.message || (isEditing ? "Role updated successfully." : "Role created successfully."));
      resetForm();
      setIsDrawerOpen(false);
      await loadRoles();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Role save failed.");
    } finally {
      setLoading(false);
    }
  };

  const handleSavePermissions = async () => {
    if (!isAdmin) {
      setPermissionsError("Admin privileges required.");
      return;
    }
    if (!editingRole?.id) return;

    setPermissionsError(null);
    setPermissionsSuccess(null);
    setPermissionsSaving(true);

    try {
      const response = await apiFetch(API.roles.permissions(editingRole.id), {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ permissions: permissionsMatrixToArray(permissionsMatrix) }),
      });

      if (response.status === 403) {
        setPermissionsError("Admin privileges required.");
        return;
      }

      if (response.status === 404) {
        setPermissionsError("This role no longer exists.");
        setIsDrawerOpen(false);
        resetForm();
        await loadRoles();
        return;
      }

      const body = await response.json().catch(() => null);

      if (!response.ok) {
        throw new Error(body?.message || "Unable to save permissions.");
      }

      const updatedRole: RoleRecord | null =
        body && typeof body === "object"
          ? ((body as { role?: RoleRecord }).role ?? (body as RoleRecord))
          : null;
      const updatedPermissions = Array.isArray(updatedRole?.permissions)
        ? (updatedRole!.permissions as PermissionEntry[])
        : permissionsMatrixToArray(permissionsMatrix);

      setPermissionsMatrix(buildPermissionsMatrix(updatedPermissions));
      setEditingRole((prev) => (prev ? { ...prev, permissions: updatedPermissions } : prev));
      setRoles((prev) =>
        prev.map((role) =>
          String(role.id) === String(editingRole.id) ? { ...role, permissions: updatedPermissions } : role
        )
      );
      setPermissionsSuccess("Permissions updated successfully.");
    } catch (err) {
      setPermissionsError(err instanceof Error ? err.message : "Unable to save permissions.");
    } finally {
      setPermissionsSaving(false);
    }
  };

  return (
    <>
      <SidebarLayout active="admin-roles" contentClassName="p-8">
          <div className="mb-8 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-[#00796B]/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.2em] text-[#00796B]">
                <ClipboardPlus size={14} />
                Admin action
              </div>
              <h1 className="text-3xl font-semibold text-slate-900">Roles</h1>
              <p className="mt-2 max-w-3xl text-sm text-slate-600">
                Create and manage role records from the `/roles/roles/` API.
              </p>
            </div>

            <div className="flex flex-wrap gap-3">
              <button
                type="button"
                onClick={openCreateDrawer}
                className="inline-flex items-center gap-2 rounded-lg bg-[#00796B] px-4 py-2 text-sm font-semibold text-white transition hover:bg-[#00695C]"
              >
                <Shield size={16} />
                Add Role
              </button>
            </div>
          </div>

          <section className="rounded-3xl border border-slate-200 p-6 shadow-sm">
            <div className="mb-5 flex items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-slate-900">Roles</h2>
                <p className="mt-1 text-sm text-slate-600">
                  Browse all roles and edit them from the drawer.
                </p>
              </div>

              <button
                type="button"
                onClick={loadRoles}
                className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 transition hover:border-[#00796B] hover:text-[#00796B]"
              >
                Refresh
              </button>
            </div>

            {listLoading ? (
              <div className="flex items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-10 text-center text-sm font-medium text-slate-500">
                <LogoSpinner className="h-5 w-5" />
                Loading roles...
              </div>
            ) : listError ? (
              <div className="rounded-2xl bg-red-50 p-4 text-sm text-red-700">
                {listError}
              </div>
            ) : roles.length ? (
              <div className="overflow-hidden rounded-2xl border border-slate-200">
                <div className="max-h-[60vh] overflow-auto">
                  <table className="min-w-full divide-y divide-slate-200 text-left text-sm">
                    <thead className="sticky top-0 bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                      <tr>
                        <th className="px-4 py-3">Role ID</th>
                        <th className="px-4 py-3">Created By</th>
                        <th className="px-4 py-3">Role</th>
                        <th className="px-4 py-3 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {roles.map((roleRecord, index) => (
                        <tr key={String(roleRecord.id ?? roleRecord.name ?? index)}>
                          <td className="px-4 py-3 font-medium text-slate-900">
                            {getRoleName(roleRecord)}
                          </td>
                          <td className="px-4 py-3 text-slate-600">
                            {roleRecord.created_by || "-"}
                          </td>
                          <td className="px-4 py-3 text-slate-600">
                            {roleRecord.id || "-"}
                          </td>
                          <td className="px-4 py-3 text-right">
                            <button
                              type="button"
                              onClick={() => openEditDrawer(roleRecord)}
                              className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 transition hover:border-[#00796B] hover:text-[#00796B]"
                            >
                              <Edit2 size={14} />
                              Edit
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-4 py-10 text-center text-sm font-medium text-slate-500">
                No roles found.
              </div>
            )}
          </section>

          {error ? (
            <div className="mt-4 rounded-lg bg-red-50 p-3 text-sm text-red-700">
              {error}
            </div>
          ) : null}
      </SidebarLayout>

      <PageChatbot agentType="roles" pageData={{ roles }} />

      {isDrawerOpen && (
        <div className="fixed inset-0 z-50">
          <button
            type="button"
            aria-label="Close role drawer"
            className="overlay-enter absolute inset-0 bg-black/40"
            onClick={() => setIsDrawerOpen(false)}
          />
          <aside className="drawer-enter absolute right-0 top-0 flex h-full w-full max-w-lg flex-col overflow-hidden bg-white shadow-2xl">
            <div className="flex items-start justify-between border-b border-slate-200 px-6 py-5">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">
                  {editingRole ? "Edit Role" : "Add Role"}
                </h2>
                <p className="mt-1 text-sm text-slate-600">
                  {editingRole ? "Update the selected role." : "Create a new role."}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsDrawerOpen(false)}
                className="rounded-full p-2 text-slate-500 transition hover:bg-slate-100 hover:text-slate-700"
              >
                <X size={20} />
              </button>
            </div>

            <div className="flex flex-1 flex-col overflow-auto px-6 py-5">
              <form onSubmit={handleSubmit} className="space-y-4">
                <label className="block">
                  <span className="text-sm font-semibold text-slate-700">Role Name</span>
                  <input
                    type="text"
                    value={name}
                    onChange={(event) => setName(event.target.value)}
                    placeholder="Enter role name"
                    className="mt-2 h-11 w-full rounded-lg border border-slate-300 px-3 text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
                  />
                </label>

                {error ? (
                  <div className="rounded-lg bg-red-50 p-3 text-sm text-red-700">
                    {error}
                  </div>
                ) : null}

                {success ? (
                  <div className="rounded-lg bg-emerald-50 p-3 text-sm text-emerald-700">
                    {success}
                  </div>
                ) : null}

                <div className="flex gap-3 pt-1">
                  <button
                    type="submit"
                    disabled={loading}
                    className="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-lg bg-[#00796B] font-semibold text-white transition hover:bg-[#00695C] disabled:cursor-not-allowed disabled:bg-slate-400"
                  >
                    <Shield size={16} />
                    {loading
                      ? editingRole
                        ? "Saving..."
                        : "Creating role..."
                      : editingRole
                        ? "Save changes"
                        : "Create Role"}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setIsDrawerOpen(false);
                      resetForm();
                    }}
                    className="inline-flex h-11 flex-1 items-center justify-center rounded-lg border border-slate-300 bg-white font-semibold text-slate-700 transition hover:border-[#00796B] hover:text-[#00796B]"
                  >
                    Cancel
                  </button>
                </div>
              </form>

              {editingRole?.id ? (
                <div className="mt-6 border-t border-slate-200 pt-5">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <h3 className="text-sm font-semibold text-slate-700">Access Permissions</h3>
                      <p className="mt-1 text-xs text-slate-500">
                        {isAdmin
                          ? "Set the access level this role has for each module."
                          : "Current access level this role has for each module."}
                      </p>
                    </div>
                    {!isAdmin && (
                      <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-slate-100 px-2 py-1 text-[11px] font-semibold text-slate-500">
                        <Lock size={12} />
                        Read only
                      </span>
                    )}
                  </div>

                  <div className="mt-3 space-y-2">
                    {visiblePermissionModules.map((module) => (
                      <div
                        key={module.key}
                        className="flex items-center justify-between gap-3 rounded-lg border border-slate-200 px-3 py-2"
                      >
                        <span className="text-sm font-medium text-slate-700">{module.label}</span>
                        {isAdmin ? (
                          <div className="flex gap-1 rounded-lg bg-slate-100 p-1">
                            {(["read", "edit"] as AccessLevel[]).map((level) => (
                              <button
                                key={level}
                                type="button"
                                onClick={() => setModuleAccess(module.key, level)}
                                className={`rounded-md px-3 py-1 text-xs font-semibold capitalize transition ${
                                  permissionsMatrix[module.key] === level
                                    ? "bg-[#00796B] text-white"
                                    : "text-slate-600 hover:bg-white"
                                }`}
                              >
                                {level}
                              </button>
                            ))}
                          </div>
                        ) : (
                          <span className="rounded-md bg-slate-100 px-3 py-1 text-xs font-semibold capitalize text-slate-600">
                            {permissionsMatrix[module.key] ?? "read"}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>

                  {permissionsError ? (
                    <div className="mt-3 rounded-lg bg-red-50 p-3 text-sm text-red-700">
                      {permissionsError}
                    </div>
                  ) : null}

                  {permissionsSuccess ? (
                    <div className="mt-3 rounded-lg bg-emerald-50 p-3 text-sm text-emerald-700">
                      {permissionsSuccess}
                    </div>
                  ) : null}

                  {isAdmin ? (
                    <button
                      type="button"
                      onClick={handleSavePermissions}
                      disabled={permissionsSaving}
                      className="mt-4 inline-flex h-11 w-full items-center justify-center gap-2 rounded-lg border border-[#00796B] font-semibold text-[#00796B] transition hover:bg-[#00796B]/10 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <Save size={16} />
                      {permissionsSaving ? "Saving permissions..." : "Save permissions"}
                    </button>
                  ) : null}
                </div>
              ) : null}
            </div>
          </aside>
        </div>
      )}
    </>
  );
}
