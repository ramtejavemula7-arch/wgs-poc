import { useCallback, useEffect, useState, type FormEvent, type KeyboardEvent } from "react";
import { Link, useSearchParams } from "react-router-dom";
import {
  ArrowLeft,
  CalendarClock,
  Edit2,
  Trash2,
  X,
} from "lucide-react";
import { apiFetch } from "../utils/api";
import { API } from "../utils/api-endpoints";
import SidebarLayout from "../components/SidebarLayout";
import StyledSelect from "../components/StyledSelect";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

type Frequency = "once" | "daily" | "weekly";
type DayOfWeek = "mon" | "tue" | "wed" | "thu" | "fri" | "sat" | "sun";

const FREQUENCIES: Frequency[] = ["once", "daily", "weekly"];

const DAYS_OF_WEEK: { value: DayOfWeek; label: string }[] = [
  { value: "mon", label: "Mon" },
  { value: "tue", label: "Tue" },
  { value: "wed", label: "Wed" },
  { value: "thu", label: "Thu" },
  { value: "fri", label: "Fri" },
  { value: "sat", label: "Sat" },
  { value: "sun", label: "Sun" },
];

const DAY_LABEL_BY_VALUE: Record<string, string> = Object.fromEntries(
  DAYS_OF_WEEK.map((d) => [d.value, d.label])
);

// Date.getDay()/setDate() week model (0 = Sunday) vs. this app's Mon-first DayOfWeek values.
const JS_DAY_BY_VALUE: Record<DayOfWeek, number> = {
  sun: 0,
  mon: 1,
  tue: 2,
  wed: 3,
  thu: 4,
  fri: 5,
  sat: 6,
};

type ScheduledReportItem = {
  id?: string | number;
  template_id?: string | number;
  template_name?: string;
  recipients?: string[];
  hour?: number;
  minute?: number;
  is_active?: boolean;
  frequency?: Frequency;
  day_of_week?: string | null;
  run_date?: string | null;
  last_sent_at?: string | null;
  last_error?: string | null;
  [key: string]: unknown;
};

type TemplateOption = {
  id: string | number;
  name?: string;
  template_name?: string;
};

const normalizeScheduledReports = (data: unknown): ScheduledReportItem[] =>
  Array.isArray(data)
    ? (data as ScheduledReportItem[])
    : data && typeof data === "object"
      ? Array.isArray((data as { results?: unknown }).results)
        ? ((data as { results: ScheduledReportItem[] }).results ?? [])
        : Array.isArray((data as { scheduled_reports?: unknown }).scheduled_reports)
          ? ((data as { scheduled_reports: ScheduledReportItem[] }).scheduled_reports ?? [])
          : [data as ScheduledReportItem]
      : [];

function getTemplateLabel(template: TemplateOption) {
  return template.name || template.template_name || `Template ${template.id}`;
}

function resolveReportTemplateName(report: ScheduledReportItem, templates: TemplateOption[]) {
  const match = templates.find((template) => String(template.id) === String(report.template_id));
  if (match) return getTemplateLabel(match);
  return report.template_name || `Template ${report.template_id ?? "-"}`;
}

function pad2(value: number) {
  return String(value).padStart(2, "0");
}

function formatTimeInput(hour?: number, minute?: number) {
  if (typeof hour !== "number" || typeof minute !== "number") return "";
  return `${pad2(hour)}:${pad2(minute)}`;
}

function formatTimeDisplay(hour?: number, minute?: number) {
  if (typeof hour !== "number" || typeof minute !== "number") return "-";
  return `${pad2(hour)}:${pad2(minute)}`;
}

function parseTimeInput(value: string): { hour: number; minute: number } | null {
  const match = /^(\d{1,2}):(\d{1,2})$/.exec(value);
  if (!match) return null;
  const hour = Number(match[1]);
  const minute = Number(match[2]);
  if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
  return { hour, minute };
}

function formatLastSent(value?: string | null) {
  if (!value) return "Never";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString(undefined, {
    year: "numeric",
    month: "numeric",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
}

function formatScheduleDetail(report: ScheduledReportItem) {
  const time = formatTimeDisplay(report.hour, report.minute);
  const frequency = report.frequency ?? "daily";

  if (frequency === "weekly") {
    const day = (report.day_of_week && DAY_LABEL_BY_VALUE[report.day_of_week]) || report.day_of_week || "-";
    return `Weekly on ${day} at ${time}`;
  }
  if (frequency === "once") {
    return `Once on ${report.run_date || "-"} at ${time}`;
  }
  return `Daily at ${time}`;
}

/** Next time this schedule is expected to fire, as an epoch ms timestamp — or null if it isn't
 * due again (inactive, or a "once" schedule that already sent). Times are treated in the
 * browser's local timezone, matching how the Time field is entered/displayed — same assumption
 * the rest of this page already makes, not a new one introduced here. Used only to decide when
 * to opportunistically refresh the list, so being off by the backend's actual scheduler timezone
 * just means the refresh lands a bit early/late, not that anything is skipped. */
function computeNextFireTime(report: ScheduledReportItem, now: Date): number | null {
  if (report.is_active === false) return null;
  if (typeof report.hour !== "number" || typeof report.minute !== "number") return null;

  const frequency = report.frequency ?? "daily";

  if (frequency === "once") {
    if (report.last_sent_at || !report.run_date) return null;
    const [year, month, day] = report.run_date.split("-").map(Number);
    if (!year || !month || !day) return null;
    return new Date(year, month - 1, day, report.hour, report.minute, 0, 0).getTime();
  }

  if (frequency === "weekly") {
    const targetDay = report.day_of_week ? JS_DAY_BY_VALUE[report.day_of_week as DayOfWeek] : undefined;
    if (targetDay === undefined) return null;
    const next = new Date(now);
    next.setHours(report.hour, report.minute, 0, 0);
    let daysUntil = (targetDay - next.getDay() + 7) % 7;
    if (daysUntil === 0 && next.getTime() <= now.getTime()) daysUntil = 7;
    next.setDate(next.getDate() + daysUntil);
    return next.getTime();
  }

  // daily
  const next = new Date(now);
  next.setHours(report.hour, report.minute, 0, 0);
  if (next.getTime() <= now.getTime()) next.setDate(next.getDate() + 1);
  return next.getTime();
}

function ToggleSwitch({
  checked,
  onChange,
  disabled,
}: {
  checked: boolean;
  onChange: (next: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition ${
        checked ? "bg-[#00796B]" : "bg-slate-300"
      } ${disabled ? "cursor-not-allowed opacity-60" : ""}`}
    >
      <span
        className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition ${
          checked ? "translate-x-6" : "translate-x-1"
        }`}
      />
    </button>
  );
}

export default function ScheduledReports() {
  const [searchParams] = useSearchParams();
  const [reports, setReports] = useState<ScheduledReportItem[]>([]);
  const [listLoading, setListLoading] = useState(false);
  const [listError, setListError] = useState<string | null>(null);

  const [templates, setTemplates] = useState<TemplateOption[]>([]);

  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [editingReport, setEditingReport] = useState<ScheduledReportItem | null>(null);

  const [templateId, setTemplateId] = useState("");
  const [recipients, setRecipients] = useState<string[]>([]);
  const [recipientInput, setRecipientInput] = useState("");
  const [recipientError, setRecipientError] = useState<string | null>(null);
  const [time, setTime] = useState("");
  const [frequency, setFrequency] = useState<Frequency>("daily");
  const [dayOfWeek, setDayOfWeek] = useState("");
  const [runDate, setRunDate] = useState("");
  const [isActive, setIsActive] = useState(true);

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const [togglingId, setTogglingId] = useState<string | number | null>(null);
  const [deletingId, setDeletingId] = useState<string | number | null>(null);

  const loadReports = useCallback(async () => {
    setListError(null);
    setListLoading(true);

    try {
      const resp = await apiFetch(API.scheduledReports.list);
      if (!resp.ok) {
        const text = await resp.text();
        throw new Error(text || "Unable to load scheduled reports.");
      }
      const data = await resp.json();
      setReports(normalizeScheduledReports(data));
    } catch (err) {
      setReports([]);
      setListError(err instanceof Error ? err.message : "Unable to load scheduled reports.");
    } finally {
      setListLoading(false);
    }
  }, []);

  const loadTemplates = useCallback(async () => {
    try {
      const resp = await apiFetch(API.templates.list);
      if (!resp.ok) return;
      const data = await resp.json();
      setTemplates(Array.isArray(data) ? data : []);
    } catch {
      setTemplates([]);
    }
  }, []);

  useEffect(() => {
    void loadReports();
    void loadTemplates();
  }, [loadReports, loadTemplates]);

  // Instead of polling on a fixed heartbeat, schedule exactly one refresh for just after the
  // soonest schedule is due to fire (capped at 24h out, since setTimeout delays beyond ~24.8
  // days silently misbehave) — recomputed every time `reports` changes, so it re-schedules
  // for the next-soonest run right after each refresh. A slow fallback interval covers any
  // list with nothing currently due (or a next-fire estimate thrown off by a timezone
  // mismatch with the backend's scheduler), and focus/visibility listeners catch up
  // immediately when the tab was backgrounded and its timers got throttled by the browser.
  useEffect(() => {
    const FALLBACK_INTERVAL_MS = 60_000;
    const FIRE_BUFFER_MS = 5_000; // give the backend a moment to actually commit last_sent_at
    const MAX_TIMER_MS = 24 * 60 * 60 * 1000;

    const refresh = () => {
      if (!isDrawerOpen) void loadReports();
    };
    const handleVisibility = () => {
      if (document.visibilityState === "visible") refresh();
    };

    const now = Date.now();
    const nextFireTimes = reports
      .map((report) => computeNextFireTime(report, new Date(now)))
      .filter((time): time is number => time !== null);
    const soonestFire = nextFireTimes.length ? Math.min(...nextFireTimes) : null;

    const targetDelay =
      soonestFire !== null
        ? Math.min(Math.max(soonestFire - now + FIRE_BUFFER_MS, FIRE_BUFFER_MS), MAX_TIMER_MS)
        : null;

    const targetTimer = targetDelay !== null ? setTimeout(refresh, targetDelay) : null;
    const fallbackInterval = setInterval(refresh, FALLBACK_INTERVAL_MS);
    window.addEventListener("focus", refresh);
    document.addEventListener("visibilitychange", handleVisibility);

    return () => {
      if (targetTimer) clearTimeout(targetTimer);
      clearInterval(fallbackInterval);
      window.removeEventListener("focus", refresh);
      document.removeEventListener("visibilitychange", handleVisibility);
    };
  }, [isDrawerOpen, loadReports, reports]);

  const resetForm = () => {
    setEditingReport(null);
    setTemplateId("");
    setRecipients([]);
    setRecipientInput("");
    setRecipientError(null);
    setTime("");
    setFrequency("daily");
    setDayOfWeek("");
    setRunDate("");
    setIsActive(true);
  };

  const openCreateDrawer = () => {
    setError(null);
    setSuccess(null);
    resetForm();
    setIsDrawerOpen(true);
  };

  useEffect(() => {
    const presetTemplateId = searchParams.get("template_id");
    if (!presetTemplateId) return;
    openCreateDrawer();
    setTemplateId(presetTemplateId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  const openEditDrawer = (report: ScheduledReportItem) => {
    setError(null);
    setSuccess(null);
    setEditingReport(report);
    setTemplateId(report.template_id != null ? String(report.template_id) : "");
    setRecipients(Array.isArray(report.recipients) ? report.recipients : []);
    setRecipientInput("");
    setRecipientError(null);
    setTime(formatTimeInput(report.hour, report.minute));
    setFrequency(report.frequency === "once" || report.frequency === "weekly" ? report.frequency : "daily");
    setDayOfWeek(report.day_of_week ?? "");
    setRunDate(report.run_date ?? "");
    setIsActive(report.is_active !== false);
    setIsDrawerOpen(true);
  };

  const addRecipient = (raw: string) => {
    const value = raw.trim().replace(/,+$/, "");
    if (!value) return;
    if (!EMAIL_RE.test(value)) {
      setRecipientError(`"${value}" is not a valid email address.`);
      return;
    }
    if (recipients.includes(value)) {
      setRecipientInput("");
      return;
    }
    setRecipientError(null);
    setRecipients((prev) => [...prev, value]);
    setRecipientInput("");
  };

  const removeRecipient = (email: string) => {
    setRecipients((prev) => prev.filter((r) => r !== email));
  };

  const handleRecipientKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Enter" || event.key === "," || event.key === "Tab") {
      if (recipientInput.trim()) {
        event.preventDefault();
        addRecipient(recipientInput);
      }
      return;
    }
    if (event.key === "Backspace" && !recipientInput && recipients.length) {
      setRecipients((prev) => prev.slice(0, -1));
    }
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    setSuccess(null);

    if (!templateId) {
      setError("Please select a template.");
      return;
    }
    if (!recipients.length) {
      setError("Please add at least one recipient.");
      return;
    }
    const parsedTime = parseTimeInput(time);
    if (!parsedTime) {
      setError("Please choose a valid send time.");
      return;
    }
    if (frequency === "weekly" && !dayOfWeek) {
      setError("Please select a day of week.");
      return;
    }
    if (frequency === "once" && !runDate) {
      setError("Please choose a date.");
      return;
    }

    setSaving(true);

    try {
      const isEditing = Boolean(editingReport?.id);
      const targetUrl = isEditing
        ? API.scheduledReports.detail(editingReport!.id!)
        : API.scheduledReports.create;

      const resp = await apiFetch(targetUrl, {
        method: isEditing ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          template_id: Number(templateId),
          recipients,
          is_active: isActive,
          hour: parsedTime.hour,
          minute: parsedTime.minute,
          frequency,
          day_of_week: frequency === "weekly" ? dayOfWeek : null,
          run_date: frequency === "once" ? runDate : null,
        }),
      });

      const body = await resp.json().catch(() => null);

      if (!resp.ok) {
        throw new Error(body?.message || "Unable to save the scheduled report.");
      }

      setSuccess(
        body?.message ||
          (isEditing ? "Scheduled report updated successfully." : "Scheduled report created successfully.")
      );
      resetForm();
      setIsDrawerOpen(false);
      await loadReports();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to save the scheduled report.");
    } finally {
      setSaving(false);
    }
  };

  const handleToggleActive = async (report: ScheduledReportItem, next: boolean) => {
    if (report.id == null) return;
    setListError(null);
    setTogglingId(report.id);

    try {
      const resp = await apiFetch(API.scheduledReports.detail(report.id), {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ is_active: next }),
      });

      if (!resp.ok) {
        const text = await resp.text();
        throw new Error(text || "Unable to update the schedule.");
      }

      setReports((prev) =>
        prev.map((item) => (item.id === report.id ? { ...item, is_active: next } : item))
      );
    } catch (err) {
      setListError(err instanceof Error ? err.message : "Unable to update the schedule.");
    } finally {
      setTogglingId(null);
    }
  };

  const handleDelete = async (report: ScheduledReportItem) => {
    if (report.id == null) return;
    const label = resolveReportTemplateName(report, templates);
    if (!window.confirm(`Delete the scheduled report for "${label}"? This cannot be undone.`)) {
      return;
    }

    setListError(null);
    setDeletingId(report.id);

    try {
      const resp = await apiFetch(API.scheduledReports.detail(report.id), { method: "DELETE" });
      if (!resp.ok) {
        const text = await resp.text();
        throw new Error(text || "Unable to delete the scheduled report.");
      }
      setReports((prev) => prev.filter((item) => item.id !== report.id));
    } catch (err) {
      setListError(err instanceof Error ? err.message : "Unable to delete the scheduled report.");
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <>
      <SidebarLayout active="templates" contentClassName="p-8">
        <div className="mb-8 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <Link
              to="/templates"
              className="mb-3 inline-flex items-center gap-1 text-sm font-semibold text-slate-500 transition hover:text-[#00796B]"
            >
              <ArrowLeft size={14} />
              Back to Templates
            </Link>
            <h1 className="text-3xl font-semibold text-slate-900">Scheduled Reports</h1>
            <p className="mt-2 max-w-3xl text-sm text-slate-600">
              Automate recurring report deliveries by email.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              onClick={openCreateDrawer}
              className="inline-flex items-center gap-2 rounded-lg bg-[#00796B] px-4 py-2 text-sm font-semibold text-white transition hover:bg-[#00695C]"
            >
              <CalendarClock size={16} />
              New Schedule
            </button>
          </div>
        </div>

        <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="mb-5 flex items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-bold text-slate-900">Schedules</h2>
              <p className="mt-1 text-sm text-slate-600">
                Reports run unattended in the background.
              </p>
            </div>

            <button
              type="button"
              onClick={loadReports}
              className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 transition hover:border-[#00796B] hover:text-[#00796B]"
            >
              Refresh
            </button>
          </div>

          {listLoading ? (
            <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-10 text-center text-sm font-medium text-slate-500">
              Loading scheduled reports...
            </div>
          ) : listError ? (
            <div className="rounded-2xl bg-red-50 p-4 text-sm text-red-700">{listError}</div>
          ) : reports.length ? (
            <div className="overflow-hidden rounded-2xl border border-slate-200">
              <div className="max-h-[60vh] overflow-auto">
                <table className="min-w-full divide-y divide-slate-200 text-left text-sm">
                  <thead className="sticky top-0 bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                    <tr>
                      <th className="px-4 py-3">Template</th>
                      <th className="px-4 py-3">Recipients</th>
                      <th className="px-4 py-3">Schedule</th>
                      <th className="px-4 py-3">Active</th>
                      <th className="px-4 py-3">Last Sent</th>
                      <th className="px-4 py-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 bg-white">
                    {reports.map((report, index) => {
                      const isCompletedOnce =
                        (report.frequency ?? "daily") === "once" && Boolean(report.last_sent_at);
                      return (
                      <tr key={String(report.id ?? index)} className={isCompletedOnce ? "opacity-60" : undefined}>
                        <td className="px-4 py-3 font-medium text-slate-900">
                          {resolveReportTemplateName(report, templates)}
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex max-w-xs flex-wrap gap-1">
                            {(report.recipients ?? []).map((email) => (
                              <span
                                key={email}
                                className="rounded-full bg-slate-100 px-2 py-0.5 text-xs text-slate-600"
                              >
                                {email}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td className="px-4 py-3 text-slate-600">
                          {formatScheduleDetail(report)}
                        </td>
                        <td className="px-4 py-3">
                          {isCompletedOnce ? (
                            <span className="inline-flex items-center rounded-full bg-slate-100 px-2 py-1 text-xs font-semibold text-slate-500">
                              Completed
                            </span>
                          ) : (
                            <ToggleSwitch
                              checked={report.is_active !== false}
                              disabled={togglingId === report.id}
                              onChange={(next) => handleToggleActive(report, next)}
                            />
                          )}
                        </td>
                        <td className="px-4 py-3 text-slate-600">{formatLastSent(report.last_sent_at)}</td>
                        <td className="px-4 py-3">
                          <div className="flex justify-end gap-2">
                            <button
                              type="button"
                              onClick={() => openEditDrawer(report)}
                              className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 transition hover:border-[#00796B] hover:text-[#00796B]"
                            >
                              <Edit2 size={14} />
                              Edit
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDelete(report)}
                              disabled={deletingId === report.id}
                              className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-red-600 transition hover:border-red-400 hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-50"
                            >
                              <Trash2 size={14} />
                              {deletingId === report.id ? "Deleting..." : "Delete"}
                            </button>
                          </div>
                        </td>
                      </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-4 py-10 text-center text-sm font-medium text-slate-500">
              No scheduled reports found.
            </div>
          )}
        </section>
      </SidebarLayout>

      {isDrawerOpen && (
        <div className="fixed inset-0 z-50">
          <button
            type="button"
            aria-label="Close schedule drawer"
            className="overlay-enter absolute inset-0 bg-black/40"
            onClick={() => setIsDrawerOpen(false)}
          />
          <aside className="drawer-enter absolute right-0 top-0 flex h-full w-full max-w-lg flex-col overflow-hidden bg-white shadow-2xl">
            <div className="flex items-start justify-between border-b border-slate-200 px-6 py-5">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">
                  {editingReport ? "Edit Schedule" : "New Schedule"}
                </h2>
                <p className="mt-1 text-sm text-slate-600">
                  {editingReport ? "Update this recurring report." : "Set up a new recurring report."}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsDrawerOpen(false)}
                className="rounded-full p-2 text-slate-500 transition hover:bg-slate-100 hover:text-slate-700"
              >
                <X size={20} />
              </button>
            </div>

            <div className="flex flex-1 flex-col overflow-auto px-6 py-5">
              <form onSubmit={handleSubmit} className="space-y-4">
                <label className="block">
                  <span className="text-sm font-semibold text-slate-700">Template</span>
                  <StyledSelect
                    className="mt-2"
                    value={templateId}
                    onChange={setTemplateId}
                    placeholder="Select a template"
                    options={templates.map((template) => ({
                      value: String(template.id),
                      label: getTemplateLabel(template),
                    }))}
                  />
                </label>

                <label className="block">
                  <span className="text-sm font-semibold text-slate-700">Recipients</span>
                  <div className="mt-2 flex flex-wrap items-center gap-2 rounded-lg border border-slate-300 px-3 py-2 focus-within:border-[#00796B] focus-within:ring-2 focus-within:ring-[#00796B]/20">
                    {recipients.map((email) => (
                      <span
                        key={email}
                        className="inline-flex items-center gap-1 rounded-full bg-[#00796B]/10 px-2 py-1 text-xs font-medium text-[#00796B]"
                      >
                        {email}
                        <button
                          type="button"
                          onClick={() => removeRecipient(email)}
                          aria-label={`Remove ${email}`}
                          className="rounded-full p-0.5 hover:bg-[#00796B]/20"
                        >
                          <X size={12} />
                        </button>
                      </span>
                    ))}
                    <input
                      type="text"
                      value={recipientInput}
                      onChange={(event) => {
                        setRecipientInput(event.target.value);
                        setRecipientError(null);
                      }}
                      onKeyDown={handleRecipientKeyDown}
                      onBlur={() => recipientInput.trim() && addRecipient(recipientInput)}
                      placeholder={recipients.length ? "" : "Add an email and press Enter"}
                      className="h-8 flex-1 min-w-[140px] border-none text-sm text-slate-900 outline-none placeholder:text-slate-400"
                    />
                  </div>
                  {recipientError ? (
                    <p className="mt-1 text-xs text-red-600">{recipientError}</p>
                  ) : null}
                </label>

                <label className="block">
                  <span className="text-sm font-semibold text-slate-700">Frequency</span>
                  <div className="mt-2 flex gap-1 rounded-lg bg-slate-100 p-1">
                    {FREQUENCIES.map((option) => (
                      <button
                        key={option}
                        type="button"
                        onClick={() => setFrequency(option)}
                        className={`flex-1 rounded-md px-3 py-2 text-xs font-semibold capitalize transition ${
                          frequency === option
                            ? "bg-[#00796B] text-white"
                            : "text-slate-600 hover:bg-white"
                        }`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                </label>

                {frequency === "weekly" ? (
                  <label className="block">
                    <span className="text-sm font-semibold text-slate-700">Day of week</span>
                    <StyledSelect
                      className="mt-2"
                      value={dayOfWeek}
                      onChange={setDayOfWeek}
                      placeholder="Select a day"
                      options={DAYS_OF_WEEK.map((day) => ({ value: day.value, label: day.label }))}
                    />
                  </label>
                ) : null}

                {frequency === "once" ? (
                  <label className="block">
                    <span className="text-sm font-semibold text-slate-700">Date</span>
                    <input
                      type="date"
                      value={runDate}
                      onChange={(event) => setRunDate(event.target.value)}
                      className="mt-2 h-11 w-full rounded-lg border border-slate-300 px-3 text-slate-900 outline-none transition focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
                    />
                  </label>
                ) : null}

                <label className="block">
                  <span className="text-sm font-semibold text-slate-700">Time</span>
                  <input
                    type="time"
                    value={time}
                    onChange={(event) => setTime(event.target.value)}
                    className="mt-2 h-11 w-full rounded-lg border border-slate-300 px-3 text-slate-900 outline-none transition focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
                  />
                </label>

                <div className="flex items-center justify-between rounded-lg border border-slate-200 px-3 py-3">
                  <span className="text-sm font-semibold text-slate-700">Active</span>
                  <ToggleSwitch checked={isActive} onChange={setIsActive} />
                </div>

                {error ? (
                  <div className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{error}</div>
                ) : null}

                {success ? (
                  <div className="rounded-lg bg-emerald-50 p-3 text-sm text-emerald-700">{success}</div>
                ) : null}

                <div className="flex gap-3 pt-1">
                  <button
                    type="submit"
                    disabled={saving}
                    className="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-lg bg-[#00796B] font-semibold text-white transition hover:bg-[#00695C] disabled:cursor-not-allowed disabled:bg-slate-400"
                  >
                    <CalendarClock size={16} />
                    {saving
                      ? editingReport
                        ? "Saving..."
                        : "Creating..."
                      : editingReport
                        ? "Save changes"
                        : "Create Schedule"}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setIsDrawerOpen(false);
                      resetForm();
                    }}
                    className="inline-flex h-11 flex-1 items-center justify-center rounded-lg border border-slate-300 bg-white font-semibold text-slate-700 transition hover:border-[#00796B] hover:text-[#00796B]"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </aside>
        </div>
      )}
    </>
  );
}
