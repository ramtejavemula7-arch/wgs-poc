import type { FormEvent } from "react";
import { useCallback, useEffect, useRef, useState } from "react";
import { embedDashboard } from "@superset-ui/embedded-sdk";
import { ArrowLeft, ChevronDown, FileDown, Globe, LayoutDashboard, Loader2, Maximize2 } from "lucide-react";
import { apiFetch } from "../utils/api";
import { consumeDashboardPrefetch } from "../utils/dashboardCache";
import SidebarLayout from "../components/SidebarLayout";
import PageChatbot from "../components/PageChatbot";
import LogoSpinner from "../components/LogoSpinner";
import {
  getCurrentRole,
  getCurrentUserKey,
  rememberDashboardOwner,
  getDashboardOwnerMap,
} from "../utils/auth";
import { useExport } from "../utils/useExport";
import { useModuleAccess } from "../utils/permissions";

import { API } from "../utils/api-endpoints";
const SUPERSET_DOMAIN = import.meta.env.VITE_SUPERSET_DOMAIN as string;
const BACKEND_EMBED_API = API.superset.embed;

type SupersetEmbedResponse = {
  id?: number;
  superset_dashboard_id?: number;
  title?: string;
  dashboard_title?: string;
  dashboard_uuid?: string;
  embed_url?: string;
  guest_token?: string;
  created_by?: string;
  owner?: string;
  owner_username?: string;
  owner_email?: string;
  created_by_username?: string;
  created_by_email?: string;
  created_by_user_id?: string;
};

const normalizeDashboards = (
  data: SupersetEmbedResponse | SupersetEmbedResponse[]
) => (Array.isArray(data) ? data : data ? [data] : []);

type SupersetDashboardListItem = {
  id: number;
  dashboard_title?: string;
  uuid?: string;
  [key: string]: unknown;
};

const normalizeSupersetDashboardList = (data: unknown): SupersetDashboardListItem[] => {
  if (Array.isArray(data)) return data as SupersetDashboardListItem[];
  if (data && typeof data === "object" && Array.isArray((data as { result?: unknown }).result)) {
    return (data as { result: SupersetDashboardListItem[] }).result;
  }
  return [];
};

function getDashboardOwner(dashboard: SupersetEmbedResponse) {
  return (
    dashboard.created_by ||
    dashboard.owner ||
    dashboard.owner_username ||
    dashboard.owner_email ||
    dashboard.created_by_username ||
    dashboard.created_by_email ||
    dashboard.created_by_user_id ||
    ""
  );
}

export default function Dashboard() {
  const [dashboardUuid, setDashboardUuid] = useState("");
  const [dashboardId, setDashboardId] = useState("");
  const [dashboards, setDashboards] = useState<SupersetEmbedResponse[]>([]);
  const [isLoadingDashboards, setIsLoadingDashboards] = useState(true);
  const [selectedDashboard, setSelectedDashboard] = useState<SupersetEmbedResponse | null>(null);
  const [dashboardChartData, setDashboardChartData] = useState<{
    title: string;
    charts: { title: string; headers: string[]; rows: unknown[][] }[];
  } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [dashboardTitle, setDashboardTitle] = useState("");
  const [exportDropdownOpen, setExportDropdownOpen] = useState(false);
  const exportDropdownRef = useRef<HTMLDivElement>(null);
  const { exportState, triggerExport, dismissError } = useExport();

  const [isBrowseModalOpen, setIsBrowseModalOpen] = useState(false);
  const [supersetDashboards, setSupersetDashboards] = useState<SupersetDashboardListItem[]>([]);
  const [browseLoading, setBrowseLoading] = useState(false);
  const [browseError, setBrowseError] = useState<string | null>(null);
  const [embeddingId, setEmbeddingId] = useState<number | null>(null);
  const currentRole = getCurrentRole();
  const currentUserKey = getCurrentUserKey();
  const isAdmin = currentRole === "admin";
  const { canEdit: canEditDashboards } = useModuleAccess("dashboard");

  const loadSavedDashboards = useCallback(async () => {
    setError(null);

    const resp = await (consumeDashboardPrefetch() ?? apiFetch(BACKEND_EMBED_API));

    if (!resp.ok) {
      const text = await resp.text();
      throw new Error(text || "Failed to fetch saved dashboards.");
    }

    const data = await resp.json();
    const dashboardList = normalizeDashboards(data)
      .filter((dashboard) => dashboard.dashboard_uuid && dashboard.guest_token)
      .filter((dashboard) => {
        if (isAdmin) return true;

        // Read fresh every call (not memoized/closed-over) so a dashboard registered
        // moments ago — via rememberDashboardOwner, right before this same reload — is
        // already reflected, and so this callback's identity stays stable across renders
        // (getDashboardOwnerMap() parses localStorage fresh each call, so capturing its
        // result as a dependency would give loadSavedDashboards a new identity every
        // render, retriggering the load effect in an infinite loop).
        const dashboardOwnerMap = getDashboardOwnerMap();
        const backendOwner = getDashboardOwner(dashboard);
        const localOwner =
          dashboard.dashboard_uuid && dashboardOwnerMap[dashboard.dashboard_uuid];

        return (
          Boolean(currentUserKey) &&
          (backendOwner === currentUserKey || localOwner === currentUserKey)
        );
      });

    setDashboards(dashboardList);
  }, [currentUserKey, isAdmin]);

  useEffect(() => {
    setIsLoadingDashboards(true);
    loadSavedDashboards()
      .catch((err) => {
        setError(err instanceof Error ? err.message : "Failed to reload dashboards.");
        setDashboards([]);
      })
      .finally(() => setIsLoadingDashboards(false));
  }, [loadSavedDashboards]);

  const loadSupersetDashboards = useCallback(async () => {
    setBrowseError(null);
    setBrowseLoading(true);

    try {
      const resp = await apiFetch(API.superset.allDashboards);
      if (!resp.ok) {
        const text = await resp.text();
        throw new Error(text || "Failed to fetch Superset dashboards.");
      }
      const data = await resp.json();
      setSupersetDashboards(normalizeSupersetDashboardList(data));
    } catch (err) {
      setSupersetDashboards([]);
      setBrowseError(
        err instanceof Error ? err.message : "Failed to fetch Superset dashboards."
      );
    } finally {
      setBrowseLoading(false);
    }
  }, []);

  const openBrowseModal = () => {
    setBrowseError(null);
    setIsBrowseModalOpen(true);
    void loadSupersetDashboards();
  };

  const handleEmbedFromSuperset = async (item: SupersetDashboardListItem) => {
    if (!item.uuid) {
      setBrowseError(`Dashboard ${item.id} has no UUID in Superset and cannot be embedded.`);
      return;
    }

    setBrowseError(null);
    setEmbeddingId(item.id);

    try {
      const resp = await apiFetch(BACKEND_EMBED_API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          dashboard_uuid: item.uuid,
          title: item.dashboard_title || `Dashboard ${item.id}`,
          superset_dashboard_id: item.id,
        }),
      });

      if (!resp.ok) {
        const text = await resp.text();
        throw new Error(text || "Failed to embed dashboard.");
      }

      await loadSavedDashboards();
    } catch (err) {
      setBrowseError(err instanceof Error ? err.message : "Failed to embed dashboard.");
    } finally {
      setEmbeddingId(null);
    }
  };

  useEffect(() => {
    if (!selectedDashboard?.dashboard_uuid || !selectedDashboard.guest_token) {
      return;
    }

    const mountPoint = document.getElementById("superset-full-container");
    if (!mountPoint) return;

    mountPoint.innerHTML = "";

    embedDashboard({
      id: selectedDashboard.dashboard_uuid,
      supersetDomain: SUPERSET_DOMAIN,
      mountPoint,
      fetchGuestToken: async () => selectedDashboard.guest_token as string,
      dashboardUiConfig: {
        hideTitle: true,
        hideChartControls: true,
        hideTab: true,
      },
    }).then(() => {
      const iframe = mountPoint.querySelector("iframe");

      if (iframe) {
        iframe.style.width = "100%";
        iframe.style.height = "100%";
        iframe.style.border = "0";
      }
    });
  }, [selectedDashboard]);

  useEffect(() => {
    if (!selectedDashboard?.dashboard_uuid) {
      setDashboardChartData(null);
      return;
    }

    let cancelled = false;
    setDashboardChartData(null);

    apiFetch(API.superset.dashboardData(selectedDashboard.dashboard_uuid))
      .then(async (resp) => {
        if (!resp.ok || cancelled) return;
        const data = await resp.json();
        if (!cancelled) setDashboardChartData(data);
      })
      .catch(() => {
        // Chat assistant falls back to dashboard metadata only — not fatal to the page.
      });

    return () => {
      cancelled = true;
    };
  }, [selectedDashboard]);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (exportDropdownRef.current && !exportDropdownRef.current.contains(e.target as Node)) {
        setExportDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!dashboardUuid.trim()) {
      setError("Please enter the Superset dashboard UUID.");
      return;
    }
    if (!dashboardTitle.trim()) {
      setError("Please enter the dashboard title.");
      return;
    }
    if (!dashboardId.trim() || isNaN(Number(dashboardId.trim()))) {
      setError("Please enter a valid numeric Superset Dashboard ID.");
      return;
    }

    try {
      setError(null);
      setIsModalOpen(false);

      const resp = await apiFetch(BACKEND_EMBED_API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          dashboard_uuid: dashboardUuid.trim(),
          title: dashboardTitle.trim(),
          superset_dashboard_id: Number(dashboardId.trim()),
        }),
      });

      if (!resp.ok) {
        const text = await resp.text();
        setError(text || "Failed to save dashboard.");
        setIsModalOpen(true);
        return;
      }

      if (!isAdmin) {
        rememberDashboardOwner(dashboardUuid.trim(), currentUserKey);
      }

      setDashboardUuid("");
      setDashboardTitle("");
      setDashboardId("");
      await loadSavedDashboards();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Network error while loading dashboard."
      );
      setIsModalOpen(true);
    }
  };

  return (
    <>
      <SidebarLayout active="dashboard" contentClassName="p-8">
        {selectedDashboard ? (
          <>
            <div className="mb-6 flex items-center justify-between gap-3 print:hidden">
              <button
                type="button"
                onClick={() => setSelectedDashboard(null)}
                className="flex items-center gap-2 rounded-lg bg-slate-200 px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-300"
              >
                <ArrowLeft size={18} />
                Back
              </button>

              <div className="flex items-center gap-3">
                {/* Export dropdown */}
                <div className="relative" ref={exportDropdownRef}>
                  <button
                    type="button"
                    disabled={exportState.status === "pending" || exportState.status === "downloading"}
                    onClick={() => setExportDropdownOpen((o) => !o)}
                    className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 transition hover:border-[#00796B] hover:text-[#00796B] disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {exportState.status === "pending" || exportState.status === "downloading" ? (
                      <Loader2 size={15} className="animate-spin" />
                    ) : (
                      <FileDown size={15} />
                    )}
                    {exportState.status === "pending"
                      ? "Generating..."
                      : exportState.status === "downloading"
                        ? "Downloading..."
                        : "Export"}
                    <ChevronDown size={14} />
                  </button>

                  {exportDropdownOpen && (
                    <div className="absolute right-0 top-full z-20 mt-1 w-36 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-lg">
                      <button
                        type="button"
                        onClick={() => {
                          setExportDropdownOpen(false);
                          void triggerExport("dashboard", selectedDashboard.dashboard_uuid!, "pdf");
                        }}
                        className="flex w-full items-center gap-2 px-4 py-3 text-sm text-slate-700 hover:bg-slate-50"
                      >
                        PDF
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setExportDropdownOpen(false);
                          void triggerExport("dashboard", selectedDashboard.dashboard_uuid!, "excel");
                        }}
                        className="flex w-full items-center gap-2 px-4 py-3 text-sm text-slate-700 hover:bg-slate-50"
                      >
                        Excel
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setExportDropdownOpen(false);
                          void triggerExport("dashboard", String(selectedDashboard.superset_dashboard_id), "visual-image");
                        }}
                        className="flex w-full items-center gap-2 px-4 py-3 text-sm text-slate-700 hover:bg-slate-50"
                      >
                        Visuals
                      </button>
                    </div>
                  )}
                </div>

                <button
                  onClick={() => setIsModalOpen(true)}
                  disabled={!canEditDashboards}
                  title={canEditDashboards ? undefined : "Read-only access — you cannot add dashboards."}
                  className="rounded-lg bg-[#00796B] px-4 py-2 text-sm font-semibold text-white transition hover:bg-[#00695C] disabled:cursor-not-allowed disabled:bg-slate-300"
                >
                  + Add Dashboard
                </button>
              </div>
            </div>

            {exportState.status === "error" && exportState.error && (
              <div className="mb-4 flex items-center justify-between rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700 print:hidden">
                <span>{exportState.error}</span>
                <button type="button" onClick={dismissError} className="ml-4 font-semibold hover:text-red-900">✕</button>
              </div>
            )}

            <div className="h-[calc(100vh-120px)] overflow-hidden rounded-2xl border border-slate-200 print:h-auto print:w-[1650px] print:overflow-visible print:border-0">
              <div id="superset-full-container" className="h-full w-full print:h-[3800px]" />
            </div>
          </>
        ) : (
          <>
            <div className="mb-8 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h1 className="text-3xl font-semibold text-slate-900">
                  {isAdmin ? "All Dashboards" : "My Dashboards"}
                </h1>
                <p className="mt-2 text-sm text-slate-600">
                  {isAdmin
                    ? "Admins can view every dashboard in the system."
                    : "You can view only the dashboards created by your account."}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                {isAdmin && (
                  <button
                    type="button"
                    onClick={openBrowseModal}
                    className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 transition hover:border-[#00796B] hover:text-[#00796B]"
                  >
                    <Globe size={16} />
                    Browse Superset
                  </button>
                )}

                <button
                  onClick={() => setIsModalOpen(true)}
                  disabled={!canEditDashboards}
                  title={canEditDashboards ? undefined : "Read-only access — you cannot add dashboards."}
                  className="rounded-lg bg-[#00796B] px-4 py-2 text-sm font-semibold text-white transition hover:bg-[#00695C] disabled:cursor-not-allowed disabled:bg-slate-300"
                >
                  + Add Dashboard
                </button>
              </div>
            </div>

            {error ? (
              <div className="mb-6 rounded-lg bg-red-50 p-3 text-sm text-red-700">{error}</div>
            ) : null}

            {isLoadingDashboards ? (
              <div className="flex h-[70vh] flex-col items-center justify-center gap-4 rounded-3xl border border-dashed border-slate-300 bg-slate-50">
                <LogoSpinner className="h-10 w-10" thickness={3} />
                <p className="text-sm font-medium text-slate-500">Loading dashboards...</p>
              </div>
            ) : dashboards.length ? (
              <div className="grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-3">
                {dashboards.map((dashboard, index) => (
                  <button
                    type="button"
                    key={dashboard.id ?? dashboard.dashboard_uuid ?? index}
                    onClick={() => setSelectedDashboard(dashboard)}
                    className="group flex h-48 flex-col justify-between rounded-2xl border border-slate-200 bg-white p-5 text-left shadow-sm transition hover:-translate-y-1 hover:border-[#00796B] hover:shadow-lg"
                  >
                    <div>
                      <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl bg-[#00796B]/10 text-[#00796B]">
                        <LayoutDashboard size={22} />
                      </div>

                      <h3 className="text-lg font-bold text-slate-900">
                        {dashboard.title ||
                          dashboard.dashboard_title ||
                          `Dashboard ${dashboard.id ?? index + 1}`}
                      </h3>

                      <p className="mt-2 line-clamp-2 break-all text-xs text-slate-500">
                        {dashboard.dashboard_uuid}
                      </p>
                    </div>

                    <div className="flex items-center justify-between text-sm font-semibold text-[#00796B]">
                      <span>Open dashboard</span>
                      <Maximize2 size={18} />
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="flex h-[70vh] items-center justify-center rounded-3xl border border-dashed border-slate-300 bg-slate-50 text-sm font-medium text-slate-500">
                {isAdmin
                  ? "No dashboard loaded. Click Add Dashboard to load one."
                  : "No dashboards available for your account yet."}
              </div>
            )}
          </>
        )}
      </SidebarLayout>

      <PageChatbot
        agentType="dashboard"
        pageData={{
          dashboards,
          selectedDashboard,
          ...(dashboardChartData ? { chartData: dashboardChartData } : {}),
        }}
      />

      {isModalOpen && (
        <div className="overlay-enter fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4">
          <div className="modal-enter w-full max-w-lg rounded-2xl bg-white p-8 shadow-2xl">
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-slate-900">Add Dashboard</h2>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-2xl text-slate-400 hover:text-slate-600"
              >
                ×
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <label className="block">
                <span className="text-sm font-semibold text-slate-700">Dashboard Title</span>
                <input
                  type="text"
                  value={dashboardTitle}
                  onChange={(event) => setDashboardTitle(event.target.value)}
                  placeholder="Enter dashboard title"
                  className="mt-2 h-11 w-full rounded-lg border border-slate-300 px-3 text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
                />
              </label>
              <label className="block">
                <span className="text-sm font-semibold text-slate-700">Superset Dashboard UUID</span>
                <input
                  type="text"
                  value={dashboardUuid}
                  onChange={(event) => setDashboardUuid(event.target.value)}
                  placeholder="Paste embedded dashboard UUID"
                  className="mt-2 h-11 w-full rounded-lg border border-slate-300 px-3 text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
                />
              </label>
              <label className="block">
                <span className="text-sm font-semibold text-slate-700">Superset Dashboard ID</span>
                <input
                  type="number"
                  value={dashboardId}
                  onChange={(event) => setDashboardId(event.target.value)}
                  placeholder="e.g. 2"
                  className="mt-2 h-11 w-full rounded-lg border border-slate-300 px-3 text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
                />
                <p className="mt-1 text-xs text-slate-400">Find this in the Superset URL: /superset/dashboard/2/</p>
              </label>

              <div className="flex gap-3">
                <button
                  type="submit"
                  className="flex-1 rounded-lg bg-[#00796B] py-2 font-semibold text-white transition hover:bg-[#00695C]"
                >
                  Load Dashboard
                </button>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 rounded-lg border border-slate-300 bg-slate-50 py-2 font-semibold text-slate-700 transition hover:bg-slate-100"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isBrowseModalOpen && (
        <div className="overlay-enter fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4">
          <div className="modal-enter flex max-h-[80vh] w-full max-w-2xl flex-col rounded-2xl bg-white p-8 shadow-2xl">
            <div className="mb-6 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-slate-900">Browse Superset Dashboards</h2>
                <p className="mt-1 text-sm text-slate-600">
                  Every dashboard available in Superset. Embed any of them into this app.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsBrowseModalOpen(false)}
                className="text-2xl text-slate-400 hover:text-slate-600"
              >
                ×
              </button>
            </div>

            {browseError ? (
              <div className="mb-4 rounded-lg bg-red-50 p-3 text-sm text-red-700">{browseError}</div>
            ) : null}

            <div className="flex-1 overflow-auto rounded-xl border border-slate-200">
              {browseLoading ? (
                <div className="flex items-center justify-center gap-2 px-4 py-10 text-sm font-medium text-slate-500">
                  <LogoSpinner className="h-4 w-4" />
                  Loading Superset dashboards...
                </div>
              ) : supersetDashboards.length ? (
                <ul className="divide-y divide-slate-100">
                  {supersetDashboards.map((item) => {
                    const alreadyEmbedded = dashboards.some(
                      (d) => d.dashboard_uuid && d.dashboard_uuid === item.uuid
                    );
                    return (
                      <li key={item.id} className="flex items-center justify-between gap-4 px-4 py-3">
                        <div className="min-w-0">
                          <p className="truncate text-sm font-semibold text-slate-900">
                            {item.dashboard_title || `Dashboard ${item.id}`}
                          </p>
                          <p className="truncate text-xs text-slate-500">
                            ID: {item.id}
                            {item.uuid ? ` · UUID: ${item.uuid}` : ""}
                          </p>
                        </div>
                        {alreadyEmbedded ? (
                          <span className="inline-flex shrink-0 items-center rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-500">
                            Embedded
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleEmbedFromSuperset(item)}
                            disabled={embeddingId === item.id}
                            className="inline-flex shrink-0 items-center gap-2 rounded-lg bg-[#00796B] px-3 py-2 text-xs font-semibold text-white transition hover:bg-[#00695C] disabled:cursor-not-allowed disabled:bg-slate-300"
                          >
                            {embeddingId === item.id ? (
                              <Loader2 size={13} className="animate-spin" />
                            ) : null}
                            {embeddingId === item.id ? "Embedding..." : "Embed"}
                          </button>
                        )}
                      </li>
                    );
                  })}
                </ul>
              ) : (
                <div className="px-4 py-10 text-center text-sm font-medium text-slate-500">
                  No dashboards found in Superset.
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
