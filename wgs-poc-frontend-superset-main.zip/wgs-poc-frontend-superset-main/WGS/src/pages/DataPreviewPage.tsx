import { useParams } from "react-router-dom";
import SidebarLayout from "../components/SidebarLayout";
import PageChatbot from "../components/PageChatbot";
import DataPreviewTable from "../components/DataPreviewTable";

export default function DataPreviewPage() {
  const { id } = useParams<{ id: string }>();

  if (!id) return null;

  return (
    <>
      <SidebarLayout active="api-endpoints">
        <div className="mb-8">
          <h1 className="text-3xl font-semibold text-slate-900">Data Preview</h1>
          <p className="mt-2 text-sm text-slate-600">Live data retrieved from this registered endpoint.</p>
        </div>
        <DataPreviewTable endpointId={id} />
      </SidebarLayout>

      <PageChatbot agentType="rest_endpoints" pageData={{ endpointId: id }} />
    </>
  );
}
