import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { apiFetch } from "../utils/api";
import { API } from "../utils/api-endpoints";
import SidebarLayout from "../components/SidebarLayout";
import PageChatbot from "../components/PageChatbot";
import LogoSpinner from "../components/LogoSpinner";
import CollapsibleSection from "../components/restEndpoints/CollapsibleSection";
import BasicInfoSection from "../components/restEndpoints/BasicInfoSection";
import AuthenticationSection from "../components/restEndpoints/AuthenticationSection";
import TestConnectionSection from "../components/restEndpoints/TestConnectionSection";
import ResponseMappingSection from "../components/restEndpoints/ResponseMappingSection";
import SaveConfigurationBar from "../components/restEndpoints/SaveConfigurationBar";
import { discoverFields, discoverRows, prettifyFieldName } from "../utils/flattenResponse";
import { loadClientMappingConfig, saveClientMappingConfig } from "../utils/clientSideMappingStore";
import {
  buildRequestBody,
  createDefaultAuthConfig,
  createDefaultEndpointConfig,
  deriveFilterConditionsFromMapping,
  parseEndpointResponse,
  type AuthType,
  type MappedField,
  type RestEndpointApiResponse,
  type RestEndpointConfig,
  type TestConnectionResult,
} from "../utils/restEndpointTypes";

function mergeResponseMapping(existing: MappedField[], discovered: string[]): MappedField[] {
  const existingByPath = new Map(existing.map((m) => [m.fieldPath, m]));
  const merged: MappedField[] = discovered.map(
    (field) =>
      existingByPath.get(field) ?? {
        fieldPath: field,
        alias: prettifyFieldName(field),
        selected: true,
        filterType: "text",
      }
  );
  existing.forEach((m) => {
    if (!discovered.includes(m.fieldPath)) merged.push(m);
  });
  return merged;
}

export default function RestEndpointRegistration() {
  const { id } = useParams<{ id?: string }>();
  const navigate = useNavigate();
  const isEditing = Boolean(id);

  const [config, setConfig] = useState<RestEndpointConfig>(createDefaultEndpointConfig());
  const [loading, setLoading] = useState(isEditing);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasSucceededTestThisSession, setHasSucceededTestThisSession] = useState(false);
  const [hasAttemptedSave, setHasAttemptedSave] = useState(false);

  useEffect(() => {
    if (!id) return;
    let cancelled = false;
    setLoading(true);

    (async () => {
      try {
        const resp = await apiFetch(API.restEndpoints.detail(id));
        if (!resp.ok) {
          const text = await resp.text();
          throw new Error(text || "Unable to load the endpoint.");
        }
        const data = (await resp.json()) as RestEndpointApiResponse;
        const parsedConfig = parseEndpointResponse(data);
        const stored = loadClientMappingConfig(data.id);

        if (!cancelled) {
          if (stored) {
            setConfig({ ...parsedConfig, responseMapping: stored.responseMapping, filters: stored.filters });
          } else {
            setConfig(parsedConfig);
          }
        }
      } catch (err) {
        if (!cancelled) setError(err instanceof Error ? err.message : "Unable to load the endpoint.");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [id]);

  const handleAuthTypeChange = (type: AuthType) => {
    setConfig((prev) => ({ ...prev, authType: type, authConfig: createDefaultAuthConfig(type), secretValue: "" }));
  };

  const handleTestSucceeded = (result: TestConnectionResult) => {
    setHasSucceededTestThisSession(true);

    let parsed: unknown;
    try {
      parsed = JSON.parse(result.rawResponse);
    } catch {
      return;
    }

    const { rows } = discoverRows(parsed);
    const fields = discoverFields(rows);
    setConfig((prev) => {
      const responseMapping = mergeResponseMapping(prev.responseMapping, fields);
      return {
        ...prev,
        responseMapping,
        filters: {
          ...prev.filters,
          conditions: deriveFilterConditionsFromMapping(responseMapping, prev.filters.conditions),
        },
      };
    });
  };

  const handleResponseMappingChange = (responseMapping: MappedField[]) => {
    setConfig((prev) => ({
      ...prev,
      responseMapping,
      filters: {
        ...prev.filters,
        conditions: deriveFilterConditionsFromMapping(responseMapping, prev.filters.conditions),
      },
    }));
  };

  const validationErrors = useMemo(() => {
    const errors: string[] = [];
    if (!config.name.trim()) errors.push("Endpoint Name is required.");
    if (!config.baseUrl.trim()) errors.push("A valid Endpoint URL is required.");
    return errors;
  }, [config.name, config.baseUrl]);

  const fieldErrors = {
    name: !config.name.trim() ? "Endpoint Name is required." : undefined,
    baseUrl: !config.baseUrl.trim() ? "Enter a valid, complete URL (including https://)." : undefined,
  };

  const handleSave = async () => {
    setSaving(true);
    setError(null);

    try {
      const payload = buildRequestBody(config);

      const resp = isEditing
        ? await apiFetch(API.restEndpoints.update(id!), {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          })
        : await apiFetch(API.restEndpoints.create, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          });

      const body = await resp.json().catch(() => null);

      if (!resp.ok) {
        throw new Error(body?.message || "Unable to save the endpoint.");
      }

      const savedId = isEditing ? id : body?.id;
      if (savedId != null) {
        saveClientMappingConfig(savedId, { responseMapping: config.responseMapping, filters: config.filters });
      }

      navigate("/api-endpoints");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to save the endpoint.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <SidebarLayout active="api-endpoints">
        <div className="flex min-h-[320px] items-center justify-center text-sm font-medium text-slate-500">
          <LogoSpinner className="mr-2 h-5 w-5" /> Loading endpoint...
        </div>
      </SidebarLayout>
    );
  }

  return (
    <>
      <SidebarLayout active="api-endpoints">
        <div className="mb-8">
          <h1 className="text-3xl font-semibold text-slate-900">{isEditing ? "Edit Endpoint" : "Register Endpoint"}</h1>
          <p className="mt-2 text-sm text-slate-600">
            Configure a REST API endpoint, its authentication, response mapping, and default filters.
          </p>
        </div>

        {error && <div className="mb-6 rounded-2xl bg-red-50 p-4 text-sm text-red-700">{error}</div>}

        <div className="space-y-6">
          <CollapsibleSection title="Basic Endpoint Information" subtitle="Name, location, and request shape.">
            <BasicInfoSection
              value={config}
              onChange={(next) => setConfig((prev) => ({ ...prev, ...next }))}
              errors={hasAttemptedSave ? fieldErrors : undefined}
            />
          </CollapsibleSection>

          <CollapsibleSection title="Authentication" subtitle="How requests to this endpoint are authenticated.">
            <AuthenticationSection
              authType={config.authType}
              authConfig={config.authConfig}
              onAuthTypeChange={handleAuthTypeChange}
              onConfigChange={(authConfig) => setConfig((prev) => ({ ...prev, authConfig }))}
              secretValue={config.secretValue}
              onSecretValueChange={(secretValue) => setConfig((prev) => ({ ...prev, secretValue }))}
              hasSecret={config.hasSecret}
            />
          </CollapsibleSection>

          <CollapsibleSection title="Test Connection" subtitle="Verify connectivity before mapping the response.">
            <TestConnectionSection config={config} onTestSucceeded={handleTestSucceeded} />
          </CollapsibleSection>

          <CollapsibleSection
            title="Response Mapping"
            subtitle="Select which fields to show and give them a filter type. Selected fields become searchable columns above the table. Saved in this browser on Save Configuration — the backend doesn't store this yet."
            locked={!hasSucceededTestThisSession && config.responseMapping.length === 0}
            lockedMessage="Run a successful Test Connection first."
          >
            <ResponseMappingSection mapping={config.responseMapping} onChange={handleResponseMappingChange} />
          </CollapsibleSection>

          <SaveConfigurationBar
            validationErrors={validationErrors}
            showValidationErrors={hasAttemptedSave}
            hasSucceededTest={hasSucceededTestThisSession}
            saving={saving}
            onSave={handleSave}
            onInvalidAttempt={() => setHasAttemptedSave(true)}
          />
        </div>
      </SidebarLayout>

      <PageChatbot agentType="rest_endpoints" pageData={{ endpointId: id ?? null }} />
    </>
  );
}
