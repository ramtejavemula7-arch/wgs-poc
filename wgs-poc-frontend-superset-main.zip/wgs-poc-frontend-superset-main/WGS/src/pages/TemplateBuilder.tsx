import { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  CloudUpload,
  Loader2,
  Save,
  Upload,
} from "lucide-react";
import { apiFetch } from "../utils/api";
import { API, resolveAssetUrl } from "../utils/api-endpoints";
import SidebarLayout from "../components/SidebarLayout";
import LogoSpinner from "../components/LogoSpinner";
import StyledSelect from "../components/StyledSelect";
import ReportPreviewHeader from "../components/ReportPreviewHeader";
import FilterBuilder from "../components/filters/FilterBuilder";
import TemplateTypeStep, { REPORT_TITLES, type TemplateType } from "../components/metrics/TemplateTypeStep";
import MetricsBuilder from "../components/metrics/MetricsBuilder";
import HeatmapBuilder from "../components/metrics/HeatmapBuilder";
import HeatmapPreviewTable from "../components/metrics/HeatmapPreviewTable";
import MatrixPreviewTable from "../components/metrics/MatrixPreviewTable";
import type { FieldOption } from "../components/metrics/DimensionPicker";
import GroupByStep from "../components/grouped/GroupByStep";
import GroupedPreviewTable from "../components/grouped/GroupedPreviewTable";
import { detectFieldType, formatStructuredFilterSummary, type StructuredFilter } from "../utils/filterFieldConfig";
import { CURRENCY_OPTIONS, formatCurrencyValue, type CurrencyCode } from "../utils/currencyFormat";
import { DEFAULT_METRICS_CONFIG, type MetricsReportConfig } from "../utils/metricsPresets";
import { dimensionFieldLabel, prettifyFieldLabel } from "../utils/metricsFieldClassification";
import { useMatrixQuery } from "../utils/useMatrixQuery";
import { useGroupedQuery } from "../utils/useGroupedQuery";

function generateMockValue(columnName: string, rowIndex: number): string {
  const lower = columnName.toLowerCase();
  const pick = <T,>(arr: T[]) => arr[rowIndex % arr.length] as T;
  if (lower.includes("date") || lower.includes("time"))
    return pick(["2024-01-15", "2024-02-20", "2024-03-10", "2024-04-05", "2024-05-18"]);
  if (lower.includes("amount") || lower.includes("price") || lower.includes("sales") || lower.includes("profit"))
    return pick(["1,250.00", "3,480.50", "780.25", "5,320.75", "2,145.00"]);
  if (lower.includes("name") || lower.includes("customer") || lower.includes("company"))
    return pick(["Alpha Corp", "Beta Ltd", "Gamma Inc", "Delta Co", "Epsilon LLC"]);
  if (lower.includes("id") || lower.includes("order"))
    return `ORD-${10001 + rowIndex}`;
  if (lower.includes("city") || lower.includes("state") || lower.includes("region") || lower.includes("country"))
    return pick(["New York", "Los Angeles", "Chicago", "Houston", "Phoenix"]);
  if (lower.includes("status") || lower.includes("mode") || lower.includes("category") || lower.includes("type"))
    return pick(["Standard Class", "Second Class", "First Class", "Same Day", "Standard Class"]);
  if (lower.includes("qty") || lower.includes("quantity") || lower.includes("count"))
    return pick(["12", "5", "28", "3", "17"]);
  return `Value ${rowIndex + 1}`;
}

type SupersetDataset = {
  id: string | number;
  table_name?: string;
  schema?: string;
  database_name?: string;
};

type SupersetDatasetColumn = {
  id?: string | number;
  column_name?: string;
  type?: string;
  description?: string;
};

const TRANSACTION_STEPS = ["dataset", "template-type", "columns", "filters", "logo", "name", "save"] as const;
const METRICS_STEPS = ["dataset", "template-type", "metrics", "logo", "name", "save"] as const;
const GROUPED_STEPS = ["dataset", "template-type", "columns", "group-by", "filters", "logo", "name", "save"] as const;

const STEP_LABELS: Record<string, string> = {
  dataset: "Pick dataset",
  "template-type": "Choose template type",
  columns: "Select columns",
  "group-by": "Group by",
  filters: "Filter your data",
  metrics: "Build matrix report",
  logo: "Upload logo",
  name: "Enter name",
  save: "Save template",
};

const STEP_DESCRIPTIONS: Record<string, string> = {
  dataset: "Choose the dataset to start building your template.",
  "template-type": "Choose whether this template produces a detailed transaction report, a Power BI-style Matrix report, or a Grouped report.",
  columns: "Select the columns that should appear in the template.",
  "group-by": "Pick which of your selected columns to group rows by, in order. Detail rows stay row-level — nothing is aggregated.",
  filters: "Filter the data your template should include. This step is optional — skip it to include everything.",
  metrics: "Configure Rows, Columns, and Values to build your Matrix. No SQL required.",
  logo: "Upload a logo and choose where it should appear.",
  name: "Give your template a name for future use.",
  save: "Review and save your new template.",
};

const STEP_GRID_COLS: Record<number, string> = {
  6: "xl:grid-cols-6",
  7: "xl:grid-cols-7",
  8: "xl:grid-cols-8",
};

export default function TemplateBuilder() {
  const [currentStep, setCurrentStep] = useState(1);
  const [templateType, setTemplateType] = useState<TemplateType | null>(null);
  const [datasets, setDatasets] = useState<SupersetDataset[]>([]);
  const [datasetsLoading, setDatasetsLoading] = useState(false);
  const [selectedDataset, setSelectedDataset] = useState<SupersetDataset | null>(null);
  const [datasetColumns, setDatasetColumns] = useState<SupersetDatasetColumn[]>([]);
  const [columnsLoading, setColumnsLoading] = useState(false);
  const [selectedColumns, setSelectedColumns] = useState<string[]>([]);
  const [totalColumns, setTotalColumns] = useState<string[]>([]);
  const [columnFormats, setColumnFormats] = useState<Record<string, CurrencyCode>>({});
  const [groupDimensions, setGroupDimensions] = useState<string[]>([]);
  const [filters, setFilters] = useState<StructuredFilter[]>([]);
  const [metricsConfig, setMetricsConfig] = useState<MetricsReportConfig>(DEFAULT_METRICS_CONFIG);
  const [, setUploadedLogo] = useState<File | null>(null);
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [templateName, setTemplateName] = useState("");
  const [templateColor] = useState("#00796B");
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const navigate = useNavigate();

  const isMatrixLikeTemplate = templateType === "metrics" || templateType === "heatmap";
  const stepKeys = isMatrixLikeTemplate ? METRICS_STEPS : templateType === "grouped" ? GROUPED_STEPS : TRANSACTION_STEPS;
  const stepItems = stepKeys.map((key) => STEP_LABELS[key]);
  const stepDescriptions = stepKeys.map((key) => STEP_DESCRIPTIONS[key]);
  const currentStepKey = stepKeys[currentStep - 1];

  const canAdvanceFromDataset = selectedDataset !== null;
  const canAdvanceFromTemplateType = templateType !== null;
  const canAdvanceFromFilters = true;
  const canAdvanceFromColumns = selectedColumns.length > 0;
  const canAdvanceFromGroupBy = groupDimensions.length > 0;
  const canAdvanceFromMetrics = metricsConfig.dimensions.length > 0 && metricsConfig.metrics.length > 0;
  const canAdvanceFromLogo = !!logoUrl;

  const canSaveTransaction =
    templateName.trim().length > 0 && !!selectedDataset && selectedColumns.length > 0 && !!logoUrl;
  const canSaveMetrics =
    templateName.trim().length > 0 &&
    !!selectedDataset &&
    metricsConfig.dimensions.length > 0 &&
    metricsConfig.metrics.length > 0 &&
    !!logoUrl;
  const canSaveGrouped =
    templateName.trim().length > 0 &&
    !!selectedDataset &&
    selectedColumns.length > 0 &&
    groupDimensions.length > 0 &&
    !!logoUrl;
  const canSave = isMatrixLikeTemplate ? canSaveMetrics : templateType === "grouped" ? canSaveGrouped : canSaveTransaction;

  const currentDatasetName = useMemo(
    () => selectedDataset?.table_name || selectedDataset?.schema || String(selectedDataset?.id),
    [selectedDataset]
  );

  const selectedDatasetColumns = useMemo(
    () =>
      datasetColumns.filter((col, index) => {
        const key = String(col.id ?? col.column_name ?? `column-${index}`);
        return selectedColumns.includes(key);
      }),
    [datasetColumns, selectedColumns]
  );

  const previewColumnNames = useMemo(
    () => selectedDatasetColumns.map((col) => col.column_name || String(col.id ?? "Column")),
    [selectedDatasetColumns]
  );

  const previewColumnFormats = useMemo(() => {
    const map: Record<string, CurrencyCode> = {};
    datasetColumns.forEach((col, index) => {
      const key = String(col.id ?? col.column_name ?? `column-${index}`);
      const name = col.column_name || String(col.id ?? key);
      const format = columnFormats[key];
      if (format) map[name] = format;
    });
    return map;
  }, [datasetColumns, columnFormats]);

  const metricsDimensionLabels = useMemo(
    () =>
      Object.fromEntries(
        [...metricsConfig.dimensions, ...(metricsConfig.columnField ? [metricsConfig.columnField] : [])].map(
          (key) => [key, dimensionFieldLabel(key)]
        )
      ),
    [metricsConfig.dimensions, metricsConfig.columnField]
  );

  // Same key derivation as the "columns" step, so group-by fields line up with `selectedColumns`.
  const columnLabelByKey = useMemo(() => {
    const map: Record<string, string> = {};
    datasetColumns.forEach((col, index) => {
      const key = String(col.id ?? col.column_name ?? `column-${index}`);
      map[key] = col.column_name || String(col.id ?? key);
    });
    return map;
  }, [datasetColumns]);

  const groupableFieldOptions: FieldOption[] = useMemo(
    () => selectedColumns.map((key) => ({ columnName: key, label: prettifyFieldLabel(columnLabelByKey[key] ?? key) })),
    [selectedColumns, columnLabelByKey]
  );

  const {
    rows: groupedRows,
    rowSpans: groupedRowSpans,
    grandTotal: groupedGrandTotal,
    loading: groupedLoading,
    error: groupedPreviewError,
  } = useGroupedQuery(
    templateType === "grouped" ? (selectedDataset?.id ?? null) : null,
    selectedColumns,
    groupDimensions,
    totalColumns,
    filters
  );

  const {
    roots: matrixRoots,
    grandTotal: matrixGrandTotal,
    columnValues: matrixColumnValues,
    loading: matrixLoading,
    error: matrixError,
    warning: matrixWarning,
  } = useMatrixQuery(isMatrixLikeTemplate ? (selectedDataset?.id ?? null) : null, metricsConfig);

  const metricsColumnFieldLabel = metricsConfig.columnField
    ? metricsDimensionLabels[metricsConfig.columnField] ?? metricsConfig.columnField
    : "";

  const loadDatasets = useCallback(async () => {
    setError(null);
    setDatasetsLoading(true);

    try {
      const resp = await apiFetch(API.superset.datasets);
      if (!resp.ok) {
        const text = await resp.text();
        throw new Error(text || "Unable to load datasets.");
      }
      const data = await resp.json();
      setDatasets(Array.isArray(data) ? data : []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to load datasets.");
    } finally {
      setDatasetsLoading(false);
    }
  }, []);

  const loadDatasetColumns = useCallback(async (datasetId: string | number) => {
    setError(null);
    setColumnsLoading(true);
    setDatasetColumns([]);
    setSelectedColumns([]);
    setColumnFormats({});

    try {
      const resp = await apiFetch(API.superset.datasetColumns(datasetId));
      if (!resp.ok) {
        const text = await resp.text();
        throw new Error(text || "Unable to load columns.");
      }
      const data = await resp.json();
      setDatasetColumns(Array.isArray(data) ? data : []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to load columns.");
    } finally {
      setColumnsLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadDatasets();
  }, [loadDatasets]);

  useEffect(() => {
    setFilters([]);
    setMetricsConfig(DEFAULT_METRICS_CONFIG);
    setGroupDimensions([]);
    if (!selectedDataset) {
      setDatasetColumns([]);
      setSelectedColumns([]);
      return;
    }

    void loadDatasetColumns(selectedDataset.id);
  }, [selectedDataset, loadDatasetColumns]);

  const handleSelectDataset = (dataset: SupersetDataset) => {
    setSelectedDataset(dataset);
    setCurrentStep(2);
  };

  const handleSelectTemplateType = (type: TemplateType) => {
    setTemplateType(type);
    setGroupDimensions([]);
    setMetricsConfig(DEFAULT_METRICS_CONFIG);
    if (type === "metrics" || type === "heatmap") {
      setSelectedColumns([]);
      setTotalColumns([]);
      setFilters([]);
    }
    setCurrentStep(3);
  };

  const handleColumnToggle = (columnId: string) => {
    setSelectedColumns((current) =>
      current.includes(columnId) ? current.filter((value) => value !== columnId) : [...current, columnId]
    );
    setTotalColumns((current) => current.filter((value) => value !== columnId));
    setFilters((current) => current.filter((f) => f.field !== columnId));
    setGroupDimensions((current) => current.filter((value) => value !== columnId));
    setColumnFormats((current) => {
      if (!(columnId in current)) return current;
      const next = { ...current };
      delete next[columnId];
      return next;
    });
  };

  const handleTotalColumnToggle = (columnId: string, included: boolean) => {
    setTotalColumns((current) => {
      if (included) {
        return current.includes(columnId) ? current : [...current, columnId];
      }
      return current.filter((value) => value !== columnId);
    });
  };

  const handleColumnFormatChange = (columnId: string, format: CurrencyCode) => {
    setColumnFormats((current) => {
      if (format === "NONE") {
        if (!(columnId in current)) return current;
        const next = { ...current };
        delete next[columnId];
        return next;
      }
      return { ...current, [columnId]: format };
    });
  };

  // Group columns must be a prefix of `columns`, in the order picked — reordering or adding a
  // group-by field re-derives the column order rather than storing it separately.
  const handleGroupDimensionsChange = (nextDimensions: string[]) => {
    setGroupDimensions(nextDimensions);
    setSelectedColumns((current) => {
      const rest = current.filter((columnKey) => !nextDimensions.includes(columnKey));
      return [...nextDimensions, ...rest];
    });
  };

  const MAX_LOGO_SIZE_MB = 5;
  const ALLOWED_LOGO_TYPES = ["image/png", "image/jpeg"];

  const handleLogoUpload = async (file: File) => {
    setError(null);
    if (!ALLOWED_LOGO_TYPES.includes(file.type)) {
      setError("Only PNG or JPG logos are allowed. SVG and other formats are not supported.");
      return;
    }
    if (file.size > MAX_LOGO_SIZE_MB * 1024 * 1024) {
      setError(`Logo must be under ${MAX_LOGO_SIZE_MB} MB.`);
      return;
    }
    setUploadedLogo(file);

    const formData = new FormData();
    formData.append("file", file);

    try {
      const resp = await apiFetch(API.templates.uploadLogo, {
        method: "POST",
        body: formData,
      });

      if (!resp.ok) {
        const text = await resp.text();
        throw new Error(text || "Logo upload failed.");
      }

      const data = await resp.json();
      setLogoUrl(resolveAssetUrl(data.logo_url || data.url || ""));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Logo upload failed.");
    }
  };

  const handleSaveTemplate = async () => {
    if (!canSave || !selectedDataset) return;

    setError(null);
    setSaving(true);

    try {
      const basePayload = {
        name: templateName.trim(),
        dataset_id: selectedDataset.id,
        template_type: templateType ?? "transaction",
        logo_url: logoUrl,
        logo_position: "left",
        template_color: templateColor,
      };

      const typePayload =
        isMatrixLikeTemplate
          ? {
              dimensions: metricsConfig.dimensions,
              column_field: metricsConfig.columnField,
              metrics: metricsConfig.metrics.map((m) => ({
                field: m.field,
                aggregation: m.aggregation,
                label: m.label,
                format: m.format,
              })),
              sort: metricsConfig.sortField
                ? { field: metricsConfig.sortField, direction: metricsConfig.sortDirection }
                : null,
              column_sort_direction: metricsConfig.columnSortDirection,
              filters: metricsConfig.filters,
            }
          : templateType === "grouped"
            ? {
                columns: selectedColumns,
                dimensions: groupDimensions,
                total_columns: selectedColumns.filter((columnKey) => totalColumns.includes(columnKey)),
                column_formats: columnFormats,
                filters,
              }
            : {
                columns: selectedColumns,
                total_columns: selectedColumns.filter((columnKey) => totalColumns.includes(columnKey)),
                column_formats: columnFormats,
                filters,
              };

      const resp = await apiFetch(API.templates.create, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...basePayload, ...typePayload }),
      });

      if (!resp.ok) {
        const text = await resp.text();
        let message = text || "Failed to save template.";
        try {
          const parsed = JSON.parse(text);
          if (parsed?.detail) {
            message = Array.isArray(parsed.detail)
              ? parsed.detail.map((d: { msg?: string }) => d.msg ?? JSON.stringify(d)).join(" ")
              : String(parsed.detail);
          }
        } catch {
          // Not JSON — use the raw response text as-is.
        }

        if (resp.status === 422 && templateType === "grouped") {
          // This is a builder-state issue (dimensions must prefix columns), not a server fault —
          // send the user back to the step where they can actually fix it.
          setCurrentStep(GROUPED_STEPS.indexOf("group-by") + 1);
        }
        setError(message);
        return;
      }

      navigate("/templates");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save template.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <SidebarLayout active="templates">
          <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-3xl font-semibold text-slate-900">Template Builder</h1>
              <p className="mt-2 text-sm text-slate-600">Work through the steps to create a new template.</p>
            </div>
            <div className="flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => setCurrentStep(1)}
                className="rounded-lg bg-[#00796B] px-4 py-2 text-sm font-semibold text-white transition hover:bg-[#00695C]"
              >
                Start over
              </button>
            </div>
          </div>

          <div className={`mb-8 grid gap-4 ${STEP_GRID_COLS[stepItems.length] ?? "xl:grid-cols-6"}`}>
            {stepItems.map((label, index) => {
              const step = index + 1;
              const isActive = currentStep === step;
              const isComplete = currentStep > step;

              return (
                <div key={`${label}-${step}`} className={`rounded-3xl border p-4 text-sm ${isActive ? "border-[#00796B] bg-[#effffa]" : "border-slate-200 bg-white"}`}>
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="font-semibold text-slate-900">Step {step}</p>
                      <p className="mt-2 text-slate-600">{label}</p>
                    </div>
                    <div className={`h-9 w-9 flex items-center justify-center rounded-full text-white ${isActive || isComplete ? "bg-[#00796B]" : "bg-slate-300 text-slate-700"}`}>
                      {isComplete ? "✓" : step}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-slate-900">Step {currentStep}: {stepItems[currentStep - 1]}</h2>
              <p className="mt-2 text-sm text-slate-600">{stepDescriptions[currentStep - 1]}</p>
            </div>

            {error ? (
              <div className="mb-6 rounded-2xl bg-red-50 p-4 text-sm text-red-700">{error}</div>
            ) : null}

            {currentStepKey === "dataset" && (
              <div className="space-y-6">
                {datasetsLoading ? (
                  <div className="flex min-h-[280px] items-center justify-center rounded-3xl border border-slate-200 bg-slate-50 text-sm font-medium text-slate-500">
                    <LogoSpinner className="mr-2 h-5 w-5" /> Loading datasets...
                  </div>
                ) : datasets.length ? (
                  <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
                    {datasets.map((dataset) => (
                      <button
                        key={dataset.id}
                        type="button"
                        onClick={() => handleSelectDataset(dataset)}
                        className={`group rounded-3xl border p-5 text-left transition ${selectedDataset?.id === dataset.id ? "border-[#00796B] bg-[#effffa]" : "border-slate-200 bg-white hover:border-[#00796B]/80"}`}
                      >
                        <div className="flex items-center justify-between gap-3">
                          <div>
                            <p className="font-semibold text-slate-900">{dataset.table_name || String(dataset.id)}</p>
                            <p className="mt-2 text-sm text-slate-500">{dataset.schema || dataset.database_name || "No schema available"}</p>
                          </div>
                          <Upload className="text-[#00796B]" />
                        </div>
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="rounded-3xl border border-dashed border-slate-300 bg-slate-50 p-12 text-center text-sm font-medium text-slate-500">
                    No datasets available.
                  </div>
                )}
              </div>
            )}

            {currentStepKey === "template-type" && (
              <div className="space-y-6">
                <div className="rounded-3xl bg-slate-50 p-6">
                  <p className="text-sm text-slate-500">Selected dataset</p>
                  <p className="mt-2 text-lg font-semibold text-slate-900">{currentDatasetName}</p>
                </div>
                <TemplateTypeStep value={templateType} onSelect={handleSelectTemplateType} />
              </div>
            )}

            {currentStepKey === "columns" && (
              <div className="space-y-6">
                <div className="rounded-3xl bg-slate-50 p-6">
                  <p className="text-sm text-slate-500">Selected dataset</p>
                  <p className="mt-2 text-lg font-semibold text-slate-900">{currentDatasetName}</p>
                </div>
                {columnsLoading ? (
                  <div className="flex min-h-[240px] items-center justify-center rounded-3xl border border-slate-200 bg-slate-50 text-sm font-medium text-slate-500">
                    <LogoSpinner className="mr-2 h-5 w-5" /> Loading columns...
                  </div>
                ) : datasetColumns.length ? (
                  <div className="grid gap-3">
                    {datasetColumns.map((column, index) => {
                      const columnKey = String(column.id ?? column.column_name ?? `column-${index}`);
                      const checked = selectedColumns.includes(columnKey);
                      const isNumeric = detectFieldType(column.type) === "numeric";
                      return (
                        <div
                          key={columnKey}
                          className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-4 transition hover:border-[#00796B]/80"
                        >
                          <label className="flex flex-1 cursor-pointer items-center gap-3">
                            <input
                              type="checkbox"
                              checked={checked}
                              onChange={() => handleColumnToggle(columnKey)}
                              className="h-4 w-4 rounded border-slate-300 text-[#00796B] focus:ring-[#00796B]"
                            />
                            <div className="min-w-0">
                              <p className="font-semibold text-slate-900">{column.column_name || String(column.id ?? columnKey)}</p>
                              <p className="mt-1 text-sm text-slate-500">{column.type || column.description || "No metadata available."}</p>
                            </div>
                          </label>
                          {checked && isNumeric && (
                            <label className="flex shrink-0 cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                              Format
                              <StyledSelect
                                className="w-32"
                                buttonClassName="h-9 px-2"
                                value={columnFormats[columnKey] ?? "NONE"}
                                onChange={(next) => handleColumnFormatChange(columnKey, next as CurrencyCode)}
                                options={CURRENCY_OPTIONS.map((option) => ({ value: option.value, label: option.label }))}
                              />
                            </label>
                          )}
                          {checked && isNumeric && (
                            <label className="flex shrink-0 cursor-pointer items-center gap-2 text-sm font-medium text-slate-700">
                              <input
                                type="checkbox"
                                checked={totalColumns.includes(columnKey)}
                                onChange={(event) => handleTotalColumnToggle(columnKey, event.target.checked)}
                                title="Show this column's sum in the Total row of exports"
                                className="h-4 w-4 rounded border-slate-300 text-[#00796B] focus:ring-[#00796B]"
                              />
                              Include in Total
                            </label>
                          )}
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="rounded-3xl border border-dashed border-slate-300 bg-slate-50 p-12 text-center text-sm font-medium text-slate-500">
                    No columns found for this dataset.
                  </div>
                )}
              </div>
            )}

            {currentStepKey === "group-by" && (
              <div className="space-y-6">
                <div className="rounded-3xl bg-slate-50 p-6">
                  <p className="text-sm text-slate-500">Selected dataset</p>
                  <p className="mt-2 text-lg font-semibold text-slate-900">{currentDatasetName}</p>
                </div>
                <GroupByStep
                  fields={groupableFieldOptions}
                  selected={groupDimensions}
                  onChange={handleGroupDimensionsChange}
                />
                <div>
                  <p className="mb-2 text-sm font-semibold text-slate-700">Live preview</p>
                  <GroupedPreviewTable
                    columns={selectedColumns}
                    dimensions={groupDimensions}
                    totalColumns={totalColumns}
                    rows={groupedRows}
                    rowSpans={groupedRowSpans}
                    grandTotal={groupedGrandTotal}
                    loading={groupedLoading}
                    error={groupedPreviewError}
                    columnFormats={columnFormats}
                  />
                </div>
              </div>
            )}

            {currentStepKey === "filters" && (
              <div className="space-y-6">
                <div className="rounded-3xl bg-slate-50 p-6">
                  <p className="text-sm text-slate-500">Selected dataset</p>
                  <p className="mt-2 text-lg font-semibold text-slate-900">{currentDatasetName}</p>
                </div>
                <FilterBuilder
                  datasetId={selectedDataset?.id ?? null}
                  columns={selectedDatasetColumns}
                  columnsLoading={columnsLoading}
                  filters={filters}
                  onChange={setFilters}
                  columnFormats={previewColumnFormats}
                />
              </div>
            )}

            {currentStepKey === "metrics" && (
              <div className="space-y-6">
                <div className="rounded-3xl bg-slate-50 p-6">
                  <p className="text-sm text-slate-500">Selected dataset</p>
                  <p className="mt-2 text-lg font-semibold text-slate-900">{currentDatasetName}</p>
                </div>
                {templateType === "heatmap" ? (
                  <HeatmapBuilder
                    datasetId={selectedDataset?.id ?? null}
                    columns={datasetColumns}
                    columnsLoading={columnsLoading}
                    value={metricsConfig}
                    onChange={setMetricsConfig}
                    matrixRoots={matrixRoots}
                    matrixGrandTotal={matrixGrandTotal}
                    matrixColumnValues={matrixColumnValues}
                    matrixLoading={matrixLoading}
                    matrixError={matrixError}
                    matrixWarning={matrixWarning}
                  />
                ) : (
                  <MetricsBuilder
                    datasetId={selectedDataset?.id ?? null}
                    columns={datasetColumns}
                    columnsLoading={columnsLoading}
                    value={metricsConfig}
                    onChange={setMetricsConfig}
                    matrixRoots={matrixRoots}
                    matrixGrandTotal={matrixGrandTotal}
                    matrixColumnValues={matrixColumnValues}
                    matrixLoading={matrixLoading}
                    matrixError={matrixError}
                    matrixWarning={matrixWarning}
                  />
                )}
              </div>
            )}

            {currentStepKey === "logo" && (
              <div className="space-y-6">
                <label className="block">
                  <span className="text-sm font-semibold text-slate-700">Upload logo</span>
                  <div className="mt-3 flex items-center gap-4 rounded-3xl border border-slate-200 bg-slate-50 p-4">
                    <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-white border border-slate-200">
                      {logoUrl ? (
                        <img src={logoUrl} alt="Logo preview" className="h-full w-full object-contain" />
                      ) : (
                        <CloudUpload className="h-8 w-8 text-slate-400" />
                      )}
                    </div>
                    <div className="flex-1">
                      <input
                        type="file"
                        accept="image/png,image/jpeg"
                        onChange={(event) => {
                          const file = event.target.files?.[0];
                          if (file) void handleLogoUpload(file);
                          event.target.value = "";
                        }}
                        className="block w-full text-sm text-slate-600"
                      />
                      <p className="mt-2 text-sm text-slate-500">PNG or JPG only. SVG is not supported.</p>
                    </div>
                  </div>
                </label>
              </div>
            )}

            {currentStepKey === "name" && (
              <div className="space-y-6">
                <label className="block">
                  <span className="text-sm font-semibold text-slate-700">Template name</span>
                  <input
                    type="text"
                    value={templateName}
                    onChange={(event) => setTemplateName(event.target.value)}
                    placeholder="Enter a descriptive template name"
                    className="mt-2 h-12 w-full rounded-2xl border border-slate-300 px-4 text-slate-900 outline-none transition focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
                  />
                </label>
              </div>
            )}

            {currentStepKey === "save" && isMatrixLikeTemplate && (
              <div className="space-y-6">
                <div>
                  <p className="mb-3 text-sm font-semibold text-slate-700">Template Preview</p>
                  <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                    <ReportPreviewHeader
                      reportTitle={REPORT_TITLES[templateType ?? "transaction"]}
                      templateName={templateName}
                      logoUrl={logoUrl}
                      showMetadata={false}
                    />
                    <div className="p-4">
                      {templateType === "heatmap" ? (
                        <HeatmapPreviewTable
                          rowFields={metricsConfig.dimensions}
                          rowFieldLabels={metricsDimensionLabels}
                          columnField={metricsConfig.columnField}
                          columnFieldLabel={metricsColumnFieldLabel}
                          columnValues={matrixColumnValues}
                          metrics={metricsConfig.metrics}
                          roots={matrixRoots}
                          grandTotal={matrixGrandTotal}
                          loading={matrixLoading}
                          error={matrixError}
                          warning={matrixWarning}
                        />
                      ) : (
                        <MatrixPreviewTable
                          rowFields={metricsConfig.dimensions}
                          rowFieldLabels={metricsDimensionLabels}
                          columnField={metricsConfig.columnField}
                          columnFieldLabel={metricsColumnFieldLabel}
                          columnValues={matrixColumnValues}
                          metrics={metricsConfig.metrics}
                          roots={matrixRoots}
                          grandTotal={matrixGrandTotal}
                          loading={matrixLoading}
                          error={matrixError}
                          warning={matrixWarning}
                        />
                      )}
                    </div>
                  </div>
                  <p className="mt-2 text-xs text-slate-400">
                    Preview shows the aggregation shape. Actual data will be computed on export.
                  </p>
                </div>

                <div className="rounded-3xl border border-slate-200 bg-slate-50 p-6">
                  <p className="text-sm text-slate-500">Review your selections before saving.</p>
                  <div className="mt-4 grid gap-4 sm:grid-cols-2">
                    <div className="rounded-3xl bg-white p-4 shadow-sm">
                      <p className="text-sm text-slate-500">Dataset</p>
                      <p className="mt-2 font-semibold text-slate-900">{currentDatasetName}</p>
                    </div>
                    <div className="rounded-3xl bg-white p-4 shadow-sm">
                      <p className="text-sm text-slate-500">Rows</p>
                      <p className="mt-2 font-semibold text-slate-900">
                        {metricsConfig.dimensions.length ? metricsConfig.dimensions.length : 0} selected
                      </p>
                    </div>
                    <div className="rounded-3xl bg-white p-4 shadow-sm">
                      <p className="text-sm text-slate-500">Columns</p>
                      <p className="mt-2 font-semibold text-slate-900">
                        {metricsColumnFieldLabel || "None"}
                      </p>
                    </div>
                    <div className="rounded-3xl bg-white p-4 shadow-sm">
                      <p className="text-sm text-slate-500">Values</p>
                      <p className="mt-2 font-semibold text-slate-900">
                        {metricsConfig.metrics.length ? metricsConfig.metrics.length : 0} selected
                      </p>
                    </div>
                    <div className="rounded-3xl bg-white p-4 shadow-sm">
                      <p className="text-sm text-slate-500">Filters</p>
                      {metricsConfig.filters.length ? (
                        <ul className="mt-2 space-y-1">
                          {metricsConfig.filters.map((f) => (
                            <li key={f.field} className="text-sm font-semibold text-slate-900">
                              {formatStructuredFilterSummary(f)}
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="mt-2 font-semibold text-slate-900">None</p>
                      )}
                    </div>
                    <div className="rounded-3xl bg-white p-4 shadow-sm">
                      <p className="text-sm text-slate-500">Sort</p>
                      <p className="mt-2 font-semibold text-slate-900">
                        {metricsConfig.sortField ? `${metricsConfig.sortField} (${metricsConfig.sortDirection})` : "None"}
                      </p>
                    </div>
                    <div className="rounded-3xl bg-white p-4 shadow-sm">
                      <p className="text-sm text-slate-500">Template name</p>
                      <p className="mt-2 font-semibold text-slate-900">{templateName || "Not set"}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {currentStepKey === "save" && templateType === "grouped" && (
              <div className="space-y-6">
                <div>
                  <p className="mb-3 text-sm font-semibold text-slate-700">Template Preview</p>
                  <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                    <ReportPreviewHeader
                      reportTitle={REPORT_TITLES.grouped}
                      templateName={templateName}
                      logoUrl={logoUrl}
                      showMetadata={true}
                    />
                    <div className="p-4">
                      <GroupedPreviewTable
                        columns={selectedColumns}
                        dimensions={groupDimensions}
                        totalColumns={totalColumns}
                        rows={groupedRows}
                        rowSpans={groupedRowSpans}
                        grandTotal={groupedGrandTotal}
                        loading={groupedLoading}
                        error={groupedPreviewError}
                        columnFormats={columnFormats}
                      />
                    </div>
                  </div>
                  <p className="mt-2 text-xs text-slate-400">
                    Preview shows the grouped layout. Actual data will be fetched on export.
                  </p>
                </div>

                <div className="rounded-3xl border border-slate-200 bg-slate-50 p-6">
                  <p className="text-sm text-slate-500">Review your selections before saving.</p>
                  <div className="mt-4 grid gap-4 sm:grid-cols-2">
                    <div className="rounded-3xl bg-white p-4 shadow-sm">
                      <p className="text-sm text-slate-500">Dataset</p>
                      <p className="mt-2 font-semibold text-slate-900">{currentDatasetName}</p>
                    </div>
                    <div className="rounded-3xl bg-white p-4 shadow-sm">
                      <p className="text-sm text-slate-500">Columns</p>
                      <p className="mt-2 font-semibold text-slate-900">{selectedColumns.length} selected</p>
                    </div>
                    <div className="rounded-3xl bg-white p-4 shadow-sm">
                      <p className="text-sm text-slate-500">Group by</p>
                      <p className="mt-2 font-semibold text-slate-900">
                        {groupDimensions.length
                          ? groupDimensions.map((d) => prettifyFieldLabel(columnLabelByKey[d] ?? d)).join(" → ")
                          : "None"}
                      </p>
                    </div>
                    <div className="rounded-3xl bg-white p-4 shadow-sm">
                      <p className="text-sm text-slate-500">Filters</p>
                      {filters.length ? (
                        <ul className="mt-2 space-y-1">
                          {filters.map((f) => (
                            <li key={f.field} className="text-sm font-semibold text-slate-900">
                              {formatStructuredFilterSummary(f)}
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="mt-2 font-semibold text-slate-900">None</p>
                      )}
                    </div>
                    <div className="rounded-3xl bg-white p-4 shadow-sm">
                      <p className="text-sm text-slate-500">Grand Total row</p>
                      <p className="mt-2 font-semibold text-slate-900">
                        {totalColumns.length ? `${totalColumns.length} column(s) included` : "None"}
                      </p>
                    </div>
                    <div className="rounded-3xl bg-white p-4 shadow-sm">
                      <p className="text-sm text-slate-500">Template name</p>
                      <p className="mt-2 font-semibold text-slate-900">{templateName || "Not set"}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {currentStepKey === "save" && !isMatrixLikeTemplate && templateType !== "grouped" && (
              <div className="space-y-6">
                {/* Visual preview */}
                <div>
                  <p className="mb-3 text-sm font-semibold text-slate-700">Template Preview</p>
                  <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                    <ReportPreviewHeader
                      reportTitle={REPORT_TITLES[templateType ?? "transaction"]}
                      templateName={templateName}
                      logoUrl={logoUrl}
                      showMetadata={true}
                    />
                    {/* Sample data table */}
                    {previewColumnNames.length > 0 ? (
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                              {previewColumnNames.map((name) => (
                                <th key={name} className="whitespace-nowrap px-4 py-3 text-left">
                                  {name}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {Array.from({ length: 5 }, (_, rowIdx) => (
                              <tr key={rowIdx} className={rowIdx % 2 === 0 ? "bg-white" : "bg-slate-50"}>
                                {previewColumnNames.map((name) => {
                                  const mockValue = generateMockValue(name, rowIdx);
                                  const format = previewColumnFormats[name];
                                  const numeric = format ? Number(mockValue.replace(/,/g, "")) : NaN;
                                  const display =
                                    format && Number.isFinite(numeric)
                                      ? formatCurrencyValue(numeric, format) ?? mockValue
                                      : mockValue;
                                  return (
                                    <td key={name} className="whitespace-nowrap px-4 py-3 text-slate-700">
                                      {display}
                                    </td>
                                  );
                                })}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    ) : (
                      <p className="p-6 text-sm text-slate-400">No columns selected.</p>
                    )}
                  </div>
                  <p className="mt-2 text-xs text-slate-400">
                    Preview uses sample data. Actual data will be fetched on export.
                  </p>
                </div>

                {/* Summary */}
                <div className="rounded-3xl border border-slate-200 bg-slate-50 p-6">
                  <p className="text-sm text-slate-500">Review your selections before saving.</p>
                  <div className="mt-4 grid gap-4 sm:grid-cols-2">
                    <div className="rounded-3xl bg-white p-4 shadow-sm">
                      <p className="text-sm text-slate-500">Dataset</p>
                      <p className="mt-2 font-semibold text-slate-900">{currentDatasetName}</p>
                    </div>
                    <div className="rounded-3xl bg-white p-4 shadow-sm">
                      <p className="text-sm text-slate-500">Columns</p>
                      <p className="mt-2 font-semibold text-slate-900">{selectedColumns.length} selected</p>
                    </div>
                    <div className="rounded-3xl bg-white p-4 shadow-sm">
                      <p className="text-sm text-slate-500">Filters</p>
                      {filters.length ? (
                        <ul className="mt-2 space-y-1">
                          {filters.map((f) => (
                            <li key={f.field} className="text-sm font-semibold text-slate-900">
                              {formatStructuredFilterSummary(f)}
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="mt-2 font-semibold text-slate-900">None</p>
                      )}
                    </div>
                    <div className="rounded-3xl bg-white p-4 shadow-sm">
                      <p className="text-sm text-slate-500">Total row</p>
                      <p className="mt-2 font-semibold text-slate-900">
                        {totalColumns.length ? `${totalColumns.length} column(s) included` : "None"}
                      </p>
                    </div>
                    <div className="rounded-3xl bg-white p-4 shadow-sm">
                      <p className="text-sm text-slate-500">Template name</p>
                      <p className="mt-2 font-semibold text-slate-900">{templateName || "Not set"}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex gap-3">
                {currentStep > 1 && (
                  <button
                    type="button"
                    onClick={() => setCurrentStep((current) => Math.max(1, current - 1))}
                    className="rounded-lg border border-slate-300 bg-white px-4 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-100"
                  >
                    Previous
                  </button>
                )}
                {currentStep < stepKeys.length && (
                  <button
                    type="button"
                    disabled={
                      currentStepKey === "dataset"
                        ? !canAdvanceFromDataset
                        : currentStepKey === "template-type"
                          ? !canAdvanceFromTemplateType
                          : currentStepKey === "columns"
                            ? !canAdvanceFromColumns
                            : currentStepKey === "group-by"
                              ? !canAdvanceFromGroupBy
                              : currentStepKey === "filters"
                                ? !canAdvanceFromFilters
                                : currentStepKey === "metrics"
                                  ? !canAdvanceFromMetrics
                                  : currentStepKey === "logo"
                                    ? !canAdvanceFromLogo
                                    : false
                    }
                    onClick={() => setCurrentStep((current) => Math.min(stepKeys.length, current + 1))}
                    className="rounded-lg bg-[#00796B] px-4 py-3 text-sm font-semibold text-white transition hover:bg-[#00695C] disabled:cursor-not-allowed disabled:bg-slate-300"
                  >
                    Next
                  </button>
                )}
              </div>
              {currentStepKey === "save" && (
                <button
                  type="button"
                  onClick={handleSaveTemplate}
                  disabled={!canSave || saving}
                  className="inline-flex items-center gap-2 rounded-lg bg-[#00796B] px-5 py-3 text-sm font-semibold text-white transition hover:bg-[#00695C] disabled:cursor-not-allowed disabled:bg-slate-300"
                >
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save size={16} />}
                  Save template
                </button>
              )}
            </div>
          </div>
    </SidebarLayout>
  );
}
