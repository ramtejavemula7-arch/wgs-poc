import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { CalendarClock, Download, Filter, Loader2 } from "lucide-react";
import { apiFetch } from "../utils/api";
import { API, resolveAssetUrl } from "../utils/api-endpoints";
import SidebarLayout from "../components/SidebarLayout";
import LogoSpinner from "../components/LogoSpinner";
import StyledSelect from "../components/StyledSelect";
import PageChatbot from "../components/PageChatbot";
import ReportPreviewHeader from "../components/ReportPreviewHeader";
import { REPORT_TITLES, type TemplateType } from "../components/metrics/TemplateTypeStep";
import MatrixPreviewTable from "../components/metrics/MatrixPreviewTable";
import HeatmapPreviewTable from "../components/metrics/HeatmapPreviewTable";
import GroupedPreviewTable from "../components/grouped/GroupedPreviewTable";
import type { StructuredFilter } from "../utils/filterFieldConfig";
import { formatCurrencyValue, type CurrencyCode } from "../utils/currencyFormat";
import { dimensionFieldLabel } from "../utils/metricsFieldClassification";
import type { MetricSelection } from "../utils/metricsAggregation";
import { DEFAULT_METRICS_CONFIG, type MetricsReportConfig } from "../utils/metricsPresets";
import { useMatrixQuery } from "../utils/useMatrixQuery";
import { useGroupedQuery } from "../utils/useGroupedQuery";

const FILTER_DEBOUNCE_MS = 300;

type TemplateDetail = {
  id: string | number;
  name?: string;
  template_name?: string;
  dataset_id?: string | number;
  dataset_name?: string;
  columns?: Array<string>;
  total_columns?: string[];
  column_formats?: Record<string, CurrencyCode>;
  filters?: StructuredFilter[];
  template_type?: TemplateType;
  dimensions?: string[];
  column_field?: string | null;
  metrics?: MetricSelection[];
  sort?: { field: string; direction: "asc" | "desc" } | null;
  column_sort_direction?: "asc" | "desc";
  logo_url?: string;
  template_color?: string;
};

type ColumnFilter = {
  col: string;
  op: string;
  val: unknown;
};

type QueryResponse = {
  columns?: Array<string>;
  rows?: Array<Record<string, unknown>>;
  total?: number;
};

export default function TemplateView() {
  const { id } = useParams<{ id: string }>();
  const [template, setTemplate] = useState<TemplateDetail | null>(null);
  const [columns, setColumns] = useState<Array<string>>([]);
  const [rows, setRows] = useState<Array<Record<string, unknown>>>([]);
  const [totalRecords, setTotalRecords] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [queryLoading, setQueryLoading] = useState(false);
  const [exporting, setExporting] = useState<"pdf" | "excel" | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [sortBy, setSortBy] = useState<string | null>(null);
  const [sortDesc, setSortDesc] = useState(false);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const [filters, setFilters] = useState<Array<ColumnFilter>>([]);
  const [searchInputs, setSearchInputs] = useState<Record<string, string>>({});
  const [openFilterColumn, setOpenFilterColumn] = useState<string | null>(null);
  const filterTimers = useRef<Record<string, ReturnType<typeof setTimeout>>>({});

  const loadTemplate = useCallback(async () => {
    if (!id) return;
    setError(null);
    setLoading(true);
    try {
      const resp = await apiFetch(API.templates.detail(id));
      if (!resp.ok) {
        const text = await resp.text();
        throw new Error(text || "Unable to load template.");
      }
      const data = await resp.json();
      setTemplate(data);
      setSortBy(data.columns?.[0] || null);
      if (Array.isArray(data.filters) && data.filters.length) {
        setFilters(
          (data.filters as StructuredFilter[]).map((f) => ({ col: f.field, op: f.operator, val: f.value }))
        );
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to load template.");
    } finally {
      setLoading(false);
    }
  }, [id]);

  const loadQueryData = useCallback(async () => {
    if (
      template?.template_type === "metrics" ||
      template?.template_type === "heatmap" ||
      template?.template_type === "grouped"
    )
      return;
    if (!template?.dataset_id || !template.columns?.length) return;
    setError(null);
    setQueryLoading(true);

    try {
      const payload: Record<string, unknown> = {
        columns: template.columns,
        filters,
        sort_desc: sortDesc,
        row_limit: pageSize,
        row_offset: (page - 1) * pageSize,
      };
      if (sortBy) payload.sort_by = sortBy;

      const resp = await apiFetch(API.superset.datasetQuery(template.dataset_id), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!resp.ok) {
        const text = await resp.text();
        throw new Error(text || "Unable to load data.");
      }

      const result = (await resp.json()) as QueryResponse;
      const fetchedRows = Array.isArray(result.rows) ? result.rows : [];

      setColumns(Array.isArray(result.columns) && result.columns.length ? result.columns : template.columns ?? []);
      setRows(fetchedRows);

      if (typeof result.total === "number") {
        setTotalRecords(result.total);
      } else if (fetchedRows.length < pageSize) {
        // Short page — this is the last page, so the exact total is now known.
        setTotalRecords((page - 1) * pageSize + fetchedRows.length);
      } else if (page === 1) {
        // No total from the API — seed an estimate so pagination controls still render.
        setTotalRecords((page + 1) * pageSize);
      } else {
        // Full page beyond page 1 — grow the estimate to cover at least one more page.
        setTotalRecords((prev) => {
          const minimumTotal = (page + 1) * pageSize;
          return prev !== null && prev > minimumTotal ? prev : minimumTotal;
        });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to load query data.");
    } finally {
      setQueryLoading(false);
    }
  }, [filters, page, pageSize, sortBy, sortDesc, template]);

  useEffect(() => { void loadTemplate(); }, [loadTemplate]);
  useEffect(() => { void loadQueryData(); }, [loadQueryData]);

  useEffect(() => {
    if (!openFilterColumn) return;
    const closeFilter = () => setOpenFilterColumn(null);
    document.addEventListener("click", closeFilter);
    return () => document.removeEventListener("click", closeFilter);
  }, [openFilterColumn]);

  useEffect(() => {
    const timers = filterTimers.current;
    return () => {
      Object.values(timers).forEach(clearTimeout);
    };
  }, []);

  const formatCellValue = (value: unknown, key: string): string => {
    if (value === null || value === undefined) return "-";

    const currency = template?.column_formats?.[key];
    if (currency) {
      const formatted = formatCurrencyValue(value, currency);
      if (formatted !== null) return formatted;
    }

    if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
      return String(value);
    }
    if (Array.isArray(value)) {
      return value.map((item) => (typeof item === "object" ? JSON.stringify(item) : String(item))).join(", ");
    }
    if (typeof value === "object") {
      const obj = value as Record<string, unknown>;
      const keys = Object.keys(obj);
      if (keys.length === 1) return formatCellValue(obj[keys[0]], key);
      if (keys.length > 1 && keys.includes(key)) return formatCellValue(obj[key], key);
      return JSON.stringify(obj);
    }
    return String(value);
  };

  const handleColumnHeaderClick = (header: string) => {
    setSortDesc((prev) => (sortBy === header ? !prev : false));
    setSortBy(header);
    setPage(1);
  };

  const toggleColumnFilter = (header: string) => {
    setOpenFilterColumn((current) => (current === header ? null : header));
  };

  const handleColumnFilterChange = (header: string, value: string) => {
    setSearchInputs((prev) => ({ ...prev, [header]: value }));

    if (filterTimers.current[header]) {
      clearTimeout(filterTimers.current[header]);
    }

    filterTimers.current[header] = setTimeout(() => {
      setPage(1);
      setFilters((prev) => {
        const rest = prev.filter((f) => f.col !== header);
        const trimmed = value.trim();
        return trimmed ? [...rest, { col: header, op: "LIKE", val: `%${trimmed}%` }] : rest;
      });
    }, FILTER_DEBOUNCE_MS);
  };

  const tableHeaders = useMemo(() => columns, [columns]);
  const isFiltering = filters.length > 0;

  const pageCount = totalRecords !== null ? Math.max(1, Math.ceil(totalRecords / pageSize)) : null;
  const showFrom = rows.length === 0 ? 0 : (page - 1) * pageSize + 1;
  const showTo = (page - 1) * pageSize + rows.length;
  const hasNextPage = pageCount !== null ? page < pageCount : rows.length === pageSize;

  const logoSrc = resolveAssetUrl(template?.logo_url) || null;

  // "heatmap" reuses the exact same matrix pivot engine/preview as "metrics" — only the
  // exported cell shading differs, which is applied server-side.
  const isMetricsTemplate = template?.template_type === "metrics" || template?.template_type === "heatmap";
  const isGroupedTemplate = template?.template_type === "grouped";

  const metricsConfig: MetricsReportConfig = useMemo(() => {
    if (!isMetricsTemplate) return DEFAULT_METRICS_CONFIG;
    return {
      dimensions: template?.dimensions ?? [],
      columnField: template?.column_field ?? null,
      metrics: template?.metrics ?? [],
      filters: template?.filters ?? [],
      sortField: template?.sort?.field ?? null,
      sortDirection: template?.sort?.direction ?? "asc",
      columnSortDirection: template?.column_sort_direction ?? "asc",
    };
  }, [isMetricsTemplate, template]);

  const metricsDimensionLabels = useMemo(
    () => Object.fromEntries(metricsConfig.dimensions.map((dim) => [dim, dimensionFieldLabel(dim)])),
    [metricsConfig.dimensions]
  );

  const metricsColumnFieldLabel = metricsConfig.columnField ? dimensionFieldLabel(metricsConfig.columnField) : "";

  const {
    roots: matrixRoots,
    grandTotal: matrixGrandTotal,
    columnValues: matrixColumnValues,
    loading: matrixLoading,
    error: matrixError,
    warning: matrixWarning,
  } = useMatrixQuery(isMetricsTemplate ? (template?.dataset_id ?? null) : null, metricsConfig);

  // Memoized so a template with no dimensions/total_columns/filters doesn't hand useGroupedQuery
  // a fresh `[]` reference every render — that made its effect's dependency array change on every
  // render, re-triggering the fetch in an infinite loop that starved React of a chance to commit
  // any other update (including a route change) until a hard refresh.
  const groupedColumns = useMemo(() => template?.columns ?? [], [template?.columns]);
  const groupedDimensions = useMemo(() => template?.dimensions ?? [], [template?.dimensions]);
  const groupedTotalColumns = useMemo(() => template?.total_columns ?? [], [template?.total_columns]);
  const groupedFilters = useMemo(() => template?.filters ?? [], [template?.filters]);

  const {
    rows: groupedRows,
    rowSpans: groupedRowSpans,
    grandTotal: groupedGrandTotal,
    loading: groupedLoading,
    error: groupedError,
  } = useGroupedQuery(
    isGroupedTemplate ? (template?.dataset_id ?? null) : null,
    groupedColumns,
    groupedDimensions,
    groupedTotalColumns,
    groupedFilters
  );

  const getExportFilename = (format: "pdf" | "excel") => {
    const extension = format === "excel" ? "xlsx" : "pdf";
    const safeName = (template?.name || template?.template_name)?.trim().replace(/[\\/:*?"<>|]+/g, "_");
    return `${safeName || `template-${id}`}.${extension}`;
  };

  const downloadBlob = (blob: Blob, filename: string) => {
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
  };

  const handleDownload = async (format: "pdf" | "excel") => {
    if (!id) return;
    setError(null);
    setExporting(format);
    try {
      const resp = await apiFetch(API.templates.export(id, format), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
        timeout: 300_000,
      });
      if (!resp.ok) {
        const text = await resp.text();
        throw new Error(text || `${format.toUpperCase()} export failed.`);
      }
      const blob = await resp.blob();
      downloadBlob(blob, getExportFilename(format));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Download failed.");
    } finally {
      setExporting(null);
    }
  };

  const getPageNumbers = (count: number, currentPage: number): (number | "...")[] => {
    if (count <= 7) return Array.from({ length: count }, (_, i) => i + 1);
    const pages: (number | "...")[] = [1];
    if (currentPage > 3) pages.push("...");
    const start = Math.max(2, currentPage - 1);
    const end = Math.min(count - 1, currentPage + 1);
    for (let i = start; i <= end; i++) pages.push(i);
    if (currentPage < count - 2) pages.push("...");
    pages.push(count);
    return pages;
  };

  return (
    <>
    <SidebarLayout active="templates">
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-slate-900">
            {template?.name || template?.template_name || "Template details"}
          </h1>
          <p className="mt-2 text-sm text-slate-600">
            {template?.dataset_name ? `Dataset: ${template.dataset_name}` : ""}
          </p>
        </div>
        <div className="flex flex-wrap gap-3">
          <Link
            to={`/templates/scheduled-reports?template_id=${id}`}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-slate-50 px-4 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-100"
          >
            <CalendarClock size={16} /> Schedule
          </Link>
          <button
            type="button"
            onClick={() => handleDownload("pdf")}
            disabled={exporting !== null}
            className="inline-flex items-center gap-2 rounded-lg bg-[#00796B] px-4 py-3 text-sm font-semibold text-white transition hover:bg-[#00695C] disabled:cursor-not-allowed disabled:opacity-60"
          >
            {exporting === "pdf" ? <Loader2 size={16} className="animate-spin" /> : <Download size={16} />} PDF
          </button>
          <button
            type="button"
            onClick={() => handleDownload("excel")}
            disabled={exporting !== null}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-slate-50 px-4 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {exporting === "excel" ? <Loader2 size={16} className="animate-spin" /> : <Download size={16} />} Excel
          </button>
        </div>
      </div>

      {error ? (
        <div className="mb-6 rounded-2xl bg-red-50 p-4 text-sm text-red-700">{error}</div>
      ) : null}

      {loading ? (
        <div className="flex min-h-[320px] items-center justify-center rounded-3xl border border-slate-200 bg-slate-50 text-sm font-medium text-slate-500">
          <LogoSpinner className="mr-2 h-5 w-5" /> Loading template...
        </div>
      ) : (
        <div className="rounded-3xl border border-slate-200 bg-white shadow-sm">
          <ReportPreviewHeader
            reportTitle={REPORT_TITLES[template?.template_type ?? "transaction"]}
            templateName={template?.name || template?.template_name || ""}
            logoUrl={logoSrc}
            showMetadata={!isMetricsTemplate}
          />

          {isMetricsTemplate ? (
            <>
              <div className="p-4">
                {template?.template_type === "heatmap" ? (
                  <HeatmapPreviewTable
                    rowFields={metricsConfig.dimensions}
                    rowFieldLabels={metricsDimensionLabels}
                    columnField={metricsConfig.columnField}
                    columnFieldLabel={metricsColumnFieldLabel}
                    columnValues={matrixColumnValues}
                    metrics={metricsConfig.metrics}
                    roots={matrixRoots}
                    grandTotal={matrixGrandTotal}
                    loading={matrixLoading}
                    error={matrixError}
                    warning={matrixWarning}
                  />
                ) : (
                  <MatrixPreviewTable
                    rowFields={metricsConfig.dimensions}
                    rowFieldLabels={metricsDimensionLabels}
                    columnField={metricsConfig.columnField}
                    columnFieldLabel={metricsColumnFieldLabel}
                    columnValues={matrixColumnValues}
                    metrics={metricsConfig.metrics}
                    roots={matrixRoots}
                    grandTotal={matrixGrandTotal}
                    loading={matrixLoading}
                    error={matrixError}
                    warning={matrixWarning}
                  />
                )}
              </div>
            </>
          ) : isGroupedTemplate ? (
            <div className="p-4">
              <GroupedPreviewTable
                columns={template?.columns ?? []}
                dimensions={template?.dimensions ?? []}
                totalColumns={template?.total_columns ?? []}
                rows={groupedRows}
                rowSpans={groupedRowSpans}
                grandTotal={groupedGrandTotal}
                loading={groupedLoading}
                error={groupedError}
                columnFormats={template?.column_formats}
              />
            </div>
          ) : queryLoading ? (
            <div className="flex min-h-[260px] items-center justify-center text-sm font-medium text-slate-500">
              <LogoSpinner className="mr-2 h-5 w-5" /> Loading data...
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-slate-200 text-left text-sm">
                  <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                    <tr>
                      {tableHeaders.map((header) => (
                        <th
                          key={header}
                          className="relative select-none whitespace-nowrap px-4 py-3"
                        >
                          <span className="flex items-center gap-1.5">
                            <span
                              onClick={() => handleColumnHeaderClick(header)}
                              className="flex cursor-pointer items-center gap-1.5 rounded px-1 py-0.5 hover:bg-slate-200"
                            >
                              {header}
                              <span className="flex flex-col gap-[1px] text-[10px] leading-none">
                                <span className={sortBy === header && !sortDesc ? "opacity-100" : "opacity-30"}>▲</span>
                                <span className={sortBy === header && sortDesc ? "opacity-100" : "opacity-30"}>▼</span>
                              </span>
                            </span>
                            <button
                              type="button"
                              onClick={(event) => {
                                event.stopPropagation();
                                toggleColumnFilter(header);
                              }}
                              title={`Filter ${header}`}
                              className={`rounded p-1 transition hover:bg-slate-200 ${
                                filters.some((f) => f.col === header) ? "text-[#00796B]" : "text-slate-400"
                              }`}
                            >
                              <Filter size={13} />
                            </button>
                          </span>

                          {openFilterColumn === header && (
                            <div
                              onClick={(event) => event.stopPropagation()}
                              className="absolute left-0 top-full z-20 mt-1 w-48 rounded-lg border border-slate-200 bg-white p-2 font-normal normal-case text-slate-900 shadow-lg"
                            >
                              <input
                                autoFocus
                                type="text"
                                value={searchInputs[header] ?? ""}
                                onChange={(event) => handleColumnFilterChange(header, event.target.value)}
                                placeholder={`Search ${header}`}
                                className="h-9 w-full rounded-md border border-slate-300 px-2 text-sm text-slate-900 outline-none focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
                              />
                            </div>
                          )}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {rows.length ? (
                      rows.map((row, rowIndex) => (
                        <tr key={rowIndex} className="hover:bg-slate-50">
                          {tableHeaders.map((header) => (
                            <td key={header} className="whitespace-nowrap px-4 py-3 text-slate-600">
                              {formatCellValue(row[header], header)}
                            </td>
                          ))}
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={tableHeaders.length || 1} className="px-4 py-10 text-center text-slate-500">
                          {isFiltering ? "No rows match the current filters." : "No data available for this query."}
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 px-6 py-3 text-sm text-slate-600">
                <span>
                  {rows.length === 0
                    ? "No records"
                    : totalRecords !== null
                      ? `Showing ${showFrom}–${showTo} of ${totalRecords} records`
                      : `Showing ${showFrom}–${showTo} records`}
                </span>
                <div className="flex items-center gap-1">
                  <StyledSelect
                    className="mr-2 w-28"
                    buttonClassName="h-9 px-2"
                    value={String(pageSize)}
                    onChange={(next) => { setPageSize(Number(next)); setPage(1); }}
                    options={[10, 20, 50].map((s) => ({ value: String(s), label: `${s} / page` }))}
                  />

                  <button
                    type="button"
                    disabled={page <= 1}
                    onClick={() => setPage((p) => p - 1)}
                    className="rounded-lg border border-slate-300 px-3 py-1.5 font-medium transition hover:border-[#00796B] hover:text-[#00796B] disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    Prev
                  </button>

                  {pageCount !== null ? (
                    getPageNumbers(pageCount, page).map((p, i) =>
                      p === "..." ? (
                        <span key={`ellipsis-${i}`} className="px-2 py-1.5 text-slate-400">…</span>
                      ) : (
                        <button
                          key={p}
                          type="button"
                          onClick={() => setPage(p)}
                          className={`min-w-[36px] rounded-lg border px-3 py-1.5 font-medium transition ${
                            p === page
                              ? "border-[#00796B] bg-[#00796B] text-white"
                              : "border-slate-300 hover:border-[#00796B] hover:text-[#00796B]"
                          }`}
                        >
                          {p}
                        </button>
                      )
                    )
                  ) : (
                    <span className="min-w-[36px] px-3 py-1.5 text-center font-medium">{page}</span>
                  )}

                  <button
                    type="button"
                    disabled={!hasNextPage}
                    onClick={() => setPage((p) => p + 1)}
                    className="rounded-lg border border-slate-300 px-3 py-1.5 font-medium transition hover:border-[#00796B] hover:text-[#00796B] disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    Next
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      )}
    </SidebarLayout>

    <PageChatbot
      agentType="reports"
      pageData={
        isMetricsTemplate
          ? {
              dimensions: metricsConfig.dimensions,
              columnField: metricsConfig.columnField,
              columnValues: matrixColumnValues,
              metrics: metricsConfig.metrics,
              rows: matrixRoots,
              grandTotal: matrixGrandTotal,
            }
          : isGroupedTemplate
            ? {
                columns: template?.columns ?? [],
                dimensions: template?.dimensions ?? [],
                rows: groupedRows,
                grandTotal: groupedGrandTotal,
              }
            : { columns: tableHeaders, rows, totalRecords, filters }
      }
    />
    </>
  );
}
