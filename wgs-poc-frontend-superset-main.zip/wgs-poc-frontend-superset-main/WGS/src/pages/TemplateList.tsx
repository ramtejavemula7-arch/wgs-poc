import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { CalendarClock, FileText, PlusCircle } from "lucide-react";
import { apiFetch } from "../utils/api";
import { API } from "../utils/api-endpoints";
import SidebarLayout from "../components/SidebarLayout";
import PageChatbot from "../components/PageChatbot";
import LogoSpinner from "../components/LogoSpinner";
import { useModuleAccess } from "../utils/permissions";

type TemplateItem = {
  id: string | number;
  name?: string;
  template_name?: string;
  dataset_id?: string | number;
  dataset_name?: string;
  logo_url?: string;
  created_at?: string;
};

export default function TemplateList() {
  const [templates, setTemplates] = useState<TemplateItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { canEdit: canCreateTemplates } = useModuleAccess("reports");

  const loadTemplates = useCallback(async () => {
    setError(null);
    setLoading(true);

    try {
      const resp = await apiFetch(API.templates.list);
      if (!resp.ok) {
        const text = await resp.text();
        throw new Error(text || "Unable to load templates.");
      }
      const data = await resp.json();
      setTemplates(Array.isArray(data) ? data : []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to load templates.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadTemplates();
  }, [loadTemplates]);

  return (
    <>
    <SidebarLayout active="templates">
          <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-3xl font-semibold text-slate-900">Templates</h1>
              <p className="mt-2 text-sm text-slate-600">Browse and manage your saved templates.</p>
            </div>
            <div className="flex flex-wrap gap-3">
              <Link
                to="/templates/scheduled-reports"
                className="rounded-lg border border-slate-300 bg-white px-4 py-3 text-sm font-semibold text-slate-700 transition hover:border-[#00796B] hover:text-[#00796B]"
              >
                <CalendarClock size={18} className="mr-2 inline" /> Scheduled Reports
              </Link>
              {canCreateTemplates ? (
                <Link
                  to="/templates/builder"
                  className="rounded-lg bg-[#00796B] px-4 py-3 text-sm font-semibold text-white transition hover:bg-[#00695C]"
                >
                  <PlusCircle size={18} className="mr-2 inline" /> New template
                </Link>
              ) : (
                <button
                  type="button"
                  disabled
                  title="Read-only access — you cannot create templates."
                  className="cursor-not-allowed rounded-lg bg-slate-300 px-4 py-3 text-sm font-semibold text-white"
                >
                  <PlusCircle size={18} className="mr-2 inline" /> New template
                </button>
              )}
            </div>
          </div>

          {error ? (
            <div className="mb-6 rounded-2xl bg-red-50 p-4 text-sm text-red-700">{error}</div>
          ) : null}

          {loading ? (
            <div className="flex min-h-[320px] items-center justify-center rounded-3xl border border-slate-200 bg-slate-50 text-sm font-medium text-slate-500">
              <LogoSpinner className="mr-2 h-5 w-5" /> Loading templates...
            </div>
          ) : templates.length ? (
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4">
              {templates.map((template) => (
                <div key={template.id} className="rounded-3xl border border-slate-200 p-5 shadow-sm transition hover:-translate-y-1 hover:border-[#00796B] hover:shadow-lg">
                  <div className="mb-4 flex items-center justify-between gap-3">
                    <div>
                      <p className="text-lg font-semibold text-slate-900">{template.name || template.template_name || `Template ${template.id}`}</p>
                      {template.dataset_name && (
                        <p className="mt-1 text-sm text-slate-500">{template.dataset_name}</p>
                      )}
                    </div>
                    <FileText className="text-[#00796B]" />
                  </div>
                  {template.created_at && (
                    <p className="text-sm text-slate-500">{new Date(template.created_at).toLocaleDateString()}</p>
                  )}
                  <div className="mt-6">
                    <Link
                      to={`/templates/${template.id}`}
                      className="rounded-lg bg-[#00796B] px-4 py-2 text-sm font-semibold text-white transition hover:bg-[#00695C]"
                    >
                      View
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex min-h-[320px] items-center justify-center rounded-3xl border border-dashed border-slate-300 bg-slate-50 p-12 text-center text-sm font-medium text-slate-500">
              No templates have been created yet.
            </div>
          )}
    </SidebarLayout>

    <PageChatbot agentType="reports" pageData={{ templates }} />
    </>
  );
}
