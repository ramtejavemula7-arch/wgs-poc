import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useNavigate } from "react-router-dom";
import { ShieldCheck } from "lucide-react";
import { prefetchDashboards } from "../utils/dashboardCache";
import { apiFetch } from "../utils/api";
import { API } from "../utils/api-endpoints";
import wgslogo from "../assets/wgswhitelogo.svg";

const loginSchema = z.object({
  email: z.string().email("Enter a valid email address."),
  password: z.string().min(8, "Password must be at least 8 characters."),
});

type LoginFormData = z.infer<typeof loginSchema>;

export default function Login() {
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const onSubmit = async (data: LoginFormData) => {
    setError(null);
    setSuccess(null);
    setIsSubmitting(true);

    try {
      const response = await apiFetch(API.auth.login, {
        auth: false,
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      const body = await response.json().catch(() => null);

      if (!response.ok) {
        const message = body?.message || "Unable to login. Please check your credentials.";
        throw new Error(message);
      }

      if (body?.access_token) {
        localStorage.setItem("access_token", body.access_token);
      }

      setSuccess("Login successful.");
      prefetchDashboards(); // fire embed API in background before navigation
      navigate("/dashboard");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <main className="flex min-h-screen items-center justify-center bg-white bg-[radial-gradient(1500px_800px_at_15%_0%,rgba(70,190,170,0.22),transparent_75%),radial-gradient(1300px_900px_at_100%_100%,rgba(250,204,21,0.16),transparent_75%),radial-gradient(1000px_700px_at_0%_100%,rgba(70,190,170,0.14),transparent_75%)] px-4">
      <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#00796B]">
            <img src={wgslogo} alt="" className="h-6 w-10 object-contain" />
          </div>
          <div>
            <p className="text-lg font-semibold text-slate-900">Worldline</p>
            <p className="text-sm text-slate-500">Superset dashboards &amp; reports</p>
          </div>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="mt-8 space-y-5">
          <label className="block">
            <span className="text-sm font-semibold text-slate-700">Email address</span>
            <input
              type="email"
              {...register("email")}
              placeholder="Enter your email"
              className="mt-2 h-11 w-full rounded-lg border border-slate-300 px-3 text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
            />
            {errors.email ? (
              <p className="mt-2 text-sm text-red-600">{errors.email.message}</p>
            ) : null}
          </label>

          <label className="block">
            <span className="text-sm font-semibold text-slate-700">Password</span>
            <input
              type="password"
              {...register("password")}
              placeholder="Enter your password"
              className="mt-2 h-11 w-full rounded-lg border border-slate-300 px-3 text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
            />
            {errors.password ? (
              <p className="mt-2 text-sm text-red-600">{errors.password.message}</p>
            ) : null}
          </label>

          {error ? (
            <div className="rounded-md bg-red-50 p-3 text-sm text-red-700">{error}</div>
          ) : null}

          {success ? (
            <div className="rounded-md bg-emerald-50 p-3 text-sm text-emerald-700">{success}</div>
          ) : null}

          <button
            type="submit"
            disabled={isSubmitting}
            className="h-11 w-full rounded-lg bg-[#00796B] font-semibold text-white shadow-sm transition hover:-translate-y-0.5 hover:bg-[#00554A] hover:shadow-md focus:outline-none focus:ring-2 focus:ring-[#00796B] focus:ring-offset-2 disabled:translate-y-0 disabled:cursor-not-allowed disabled:bg-slate-400 disabled:shadow-none"
          >
            {isSubmitting ? "Signing in..." : "Sign in"}
          </button>
        </form>

        <p className="mt-6 flex items-center justify-center gap-1.5 text-center text-xs text-slate-400">
          <ShieldCheck size={14} />
          Protected by enterprise-grade security
        </p>
      </div>
    </main>
  );
}
