import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { AlertTriangle, Edit2, Eye, Loader2, Plug, PlusCircle, PlugZap, Power, Trash2, X } from "lucide-react";
import { apiFetch } from "../utils/api";
import { API } from "../utils/api-endpoints";
import SidebarLayout from "../components/SidebarLayout";
import PageChatbot from "../components/PageChatbot";
import DataTable, { type DataTableColumn } from "../components/DataTable";
import QuickTestDrawer from "../components/restEndpoints/QuickTestDrawer";
import { useModuleAccess } from "../utils/permissions";
import { AUTH_TYPE_LABELS, type EndpointStatus, type RestEndpointSummary } from "../utils/restEndpointTypes";

const rowActionClass =
  "flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-slate-600 transition hover:border-[#00796B] hover:text-[#00796B] disabled:cursor-not-allowed disabled:opacity-40";
const rowActionDangerClass =
  "flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-slate-600 transition hover:border-red-400 hover:bg-red-50 hover:text-red-600 disabled:cursor-not-allowed disabled:opacity-40";

export default function RestEndpointList() {
  const { canEdit } = useModuleAccess("rest_endpoints");
  const [endpoints, setEndpoints] = useState<RestEndpointSummary[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [testingEndpoint, setTestingEndpoint] = useState<RestEndpointSummary | null>(null);
  const [viewingEndpoint, setViewingEndpoint] = useState<RestEndpointSummary | null>(null);
  const [confirmingDelete, setConfirmingDelete] = useState<RestEndpointSummary | null>(null);
  const [togglingId, setTogglingId] = useState<number | null>(null);
  const [deletingId, setDeletingId] = useState<number | null>(null);

  const loadEndpoints = useCallback(async () => {
    setError(null);
    setLoading(true);
    try {
      const resp = await apiFetch(API.restEndpoints.list);
      if (!resp.ok) {
        const text = await resp.text();
        throw new Error(text || "Unable to load endpoints.");
      }
      const data = await resp.json();
      setEndpoints(Array.isArray(data) ? data : []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to load endpoints.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadEndpoints();
  }, [loadEndpoints]);

  const handleToggleStatus = async (endpoint: RestEndpointSummary) => {
    const nextStatus: EndpointStatus = endpoint.status === "enabled" ? "disabled" : "enabled";
    setTogglingId(endpoint.id);
    try {
      const resp = await apiFetch(API.restEndpoints.setEnabled(endpoint.id), {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: nextStatus }),
      });
      if (!resp.ok) {
        const text = await resp.text();
        throw new Error(text || "Unable to update the endpoint status.");
      }
      setEndpoints((prev) => prev.map((e) => (e.id === endpoint.id ? { ...e, status: nextStatus } : e)));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to update the endpoint status.");
    } finally {
      setTogglingId(null);
    }
  };

  const handleConfirmDelete = async () => {
    if (!confirmingDelete) return;
    const endpoint = confirmingDelete;
    setDeletingId(endpoint.id);
    try {
      const resp = await apiFetch(API.restEndpoints.delete(endpoint.id), { method: "DELETE" });
      if (!resp.ok) {
        const text = await resp.text();
        throw new Error(text || "Unable to delete the endpoint.");
      }
      setEndpoints((prev) => prev.filter((e) => e.id !== endpoint.id));
      setConfirmingDelete(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to delete the endpoint.");
      setConfirmingDelete(null);
    } finally {
      setDeletingId(null);
    }
  };

  const columns: DataTableColumn<RestEndpointSummary>[] = [
    { key: "name", header: "Endpoint Name", sortable: true, filterable: true },
    { key: "base_url", header: "Base URL", sortable: true },
    { key: "http_method", header: "HTTP Method", sortable: true },
    {
      key: "auth_type",
      header: "Authentication Type",
      sortable: true,
      render: (row) => AUTH_TYPE_LABELS[row.auth_type],
    },
    {
      key: "status",
      header: "Status",
      sortable: true,
      render: (row) => (
        <span
          className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold ${
            row.status === "enabled" ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"
          }`}
        >
          {row.status === "enabled" ? "Enabled" : "Disabled"}
        </span>
      ),
    },
    {
      key: "updated_at",
      header: "Last Modified",
      sortable: true,
      render: (row) => (row.updated_at ? new Date(row.updated_at).toLocaleString() : "-"),
    },
    {
      key: "actions",
      header: "Actions",
      render: (row) => (
        <div className="flex items-center gap-1.5">
          <button type="button" onClick={() => setViewingEndpoint(row)} title="View Details" className={rowActionClass}>
            <Eye size={14} />
          </button>
          <button type="button" onClick={() => setTestingEndpoint(row)} title="Test" className={rowActionClass}>
            <PlugZap size={14} />
          </button>
          <Link
            to={`/api-endpoints/${row.id}/edit`}
            title="Edit"
            aria-disabled={!canEdit}
            onClick={(event) => !canEdit && event.preventDefault()}
            className={`${rowActionClass} ${!canEdit ? "pointer-events-none opacity-40" : ""}`}
          >
            <Edit2 size={14} />
          </Link>
          <button
            type="button"
            onClick={() => handleToggleStatus(row)}
            disabled={!canEdit || togglingId === row.id}
            title={row.status === "enabled" ? "Disable" : "Enable"}
            className={rowActionClass}
          >
            <Power size={14} />
          </button>
          <button
            type="button"
            onClick={() => setConfirmingDelete(row)}
            disabled={!canEdit || deletingId === row.id}
            title="Delete"
            className={rowActionDangerClass}
          >
            <Trash2 size={14} />
          </button>
        </div>
      ),
    },
  ];

  return (
    <>
      <SidebarLayout active="api-endpoints">
        <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-semibold text-slate-900">API Endpoints</h1>
            <p className="mt-2 text-sm text-slate-600">Register, configure, test, and manage REST API endpoints.</p>
          </div>
          {canEdit ? (
            <Link
              to="/api-endpoints/new"
              className="rounded-lg bg-[#00796B] px-4 py-3 text-sm font-semibold text-white transition hover:bg-[#00695C]"
            >
              <PlusCircle size={18} className="mr-2 inline" /> Register Endpoint
            </Link>
          ) : (
            <button
              type="button"
              disabled
              title="Read-only access. You cannot register endpoints."
              className="cursor-not-allowed rounded-lg bg-slate-300 px-4 py-3 text-sm font-semibold text-white"
            >
              <PlusCircle size={18} className="mr-2 inline" /> Register Endpoint
            </button>
          )}
        </div>

        {error && <div className="mb-6 rounded-2xl bg-red-50 p-4 text-sm text-red-700">{error}</div>}

        <DataTable
          columns={columns}
          rows={endpoints}
          loading={loading}
          getRowKey={(row) => row.id}
          searchable
          searchPlaceholder="Search by name"
          emptyMessage="No endpoints have been registered yet."
        />
      </SidebarLayout>

      <PageChatbot agentType="rest_endpoints" pageData={{ endpoints }} />

      {testingEndpoint && (
        <QuickTestDrawer
          endpointId={testingEndpoint.id}
          endpointName={testingEndpoint.name}
          open={Boolean(testingEndpoint)}
          onClose={() => setTestingEndpoint(null)}
        />
      )}

      {viewingEndpoint && (
        <div className="overlay-enter fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4">
          <div className="modal-enter w-full max-w-lg rounded-2xl bg-white p-8 shadow-2xl">
            <div className="mb-6 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#00796B]/10 text-[#00796B]">
                  <Plug size={20} />
                </div>
                <h2 className="text-xl font-bold text-slate-900">{viewingEndpoint.name}</h2>
              </div>
              <button
                type="button"
                onClick={() => setViewingEndpoint(null)}
                className="text-2xl text-slate-400 hover:text-slate-600"
              >
                <X size={20} />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-slate-500">Base URL</p>
                <p className="mt-1 break-all font-semibold text-slate-900">{viewingEndpoint.base_url}</p>
              </div>
              <div>
                <p className="text-slate-500">HTTP Method</p>
                <p className="mt-1 font-semibold text-slate-900">{viewingEndpoint.http_method}</p>
              </div>
              <div>
                <p className="text-slate-500">Authentication Type</p>
                <p className="mt-1 font-semibold text-slate-900">{AUTH_TYPE_LABELS[viewingEndpoint.auth_type]}</p>
              </div>
              <div>
                <p className="text-slate-500">Status</p>
                <p className="mt-1 font-semibold text-slate-900">
                  {viewingEndpoint.status === "enabled" ? "Enabled" : "Disabled"}
                </p>
              </div>
              <div>
                <p className="text-slate-500">Last Modified</p>
                <p className="mt-1 font-semibold text-slate-900">
                  {viewingEndpoint.updated_at ? new Date(viewingEndpoint.updated_at).toLocaleString() : "-"}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {confirmingDelete && (
        <div className="overlay-enter fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4">
          <div className="modal-enter w-full max-w-sm rounded-2xl bg-white p-6 shadow-2xl">
            <div className="mb-4 flex items-center gap-3">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-red-100 text-red-600">
                <AlertTriangle size={20} />
              </div>
              <h2 className="text-lg font-bold text-slate-900">Delete Endpoint</h2>
            </div>

            <p className="text-sm text-slate-600">
              Delete <span className="font-semibold text-slate-900">&quot;{confirmingDelete.name}&quot;</span>? This
              cannot be undone.
            </p>

            <div className="mt-6 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setConfirmingDelete(null)}
                disabled={deletingId === confirmingDelete.id}
                className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => void handleConfirmDelete()}
                disabled={deletingId === confirmingDelete.id}
                className="inline-flex items-center gap-2 rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {deletingId === confirmingDelete.id && <Loader2 size={14} className="animate-spin" />}
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
