import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Search } from "lucide-react";
import { apiFetch } from "../utils/api";
import { API } from "../utils/api-endpoints";
import SidebarLayout from "../components/SidebarLayout";
import LogoSpinner from "../components/LogoSpinner";
import PageChatbot from "../components/PageChatbot";
import DataPreviewTable from "../components/DataPreviewTable";
import StyledSelect from "../components/StyledSelect";
import { useModuleAccess } from "../utils/permissions";
import type { RestEndpointSummary } from "../utils/restEndpointTypes";

const SELECTED_ENDPOINT_STORAGE_KEY = "transactionSearch.endpointId";

export default function TransactionLookup() {
  const { canEdit } = useModuleAccess("rest_endpoints");
  const [endpoints, setEndpoints] = useState<RestEndpointSummary[]>([]);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    (async () => {
      try {
        const resp = await apiFetch(API.restEndpoints.list);
        if (!resp.ok) {
          const text = await resp.text();
          throw new Error(text || "Unable to load registered endpoints.");
        }
        const data = await resp.json();
        const list: RestEndpointSummary[] = Array.isArray(data) ? data : [];
        if (cancelled) return;

        setEndpoints(list);

        const storedId = Number(localStorage.getItem(SELECTED_ENDPOINT_STORAGE_KEY));
        const stored = list.find((e) => e.id === storedId);
        const fallback = list.find((e) => e.status === "enabled") ?? list[0] ?? null;
        setSelectedId((stored ?? fallback)?.id ?? null);
      } catch (err) {
        if (!cancelled) setError(err instanceof Error ? err.message : "Unable to load registered endpoints.");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, []);

  const handleSelectEndpoint = (id: number) => {
    setSelectedId(id);
    localStorage.setItem(SELECTED_ENDPOINT_STORAGE_KEY, String(id));
  };

  if (loading) {
    return (
      <SidebarLayout active="transactions" contentClassName="p-8">
        <div className="flex min-h-[320px] items-center justify-center text-sm font-medium text-slate-500">
          <LogoSpinner className="mr-2 h-5 w-5" /> Loading Transaction Search...
        </div>
      </SidebarLayout>
    );
  }

  return (
    <>
      <SidebarLayout active="transactions" contentClassName="p-8">
        <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h1 className="text-3xl font-semibold text-slate-900">Transaction Search</h1>
            <p className="mt-2 text-sm text-slate-600">
              Search and review transaction records from the connected data source.
            </p>
          </div>

          {endpoints.length > 0 && (
            <label className="block sm:w-72">
              <span className="text-sm font-semibold text-slate-700">Data Source</span>
              <StyledSelect
                className="mt-2"
                value={String(selectedId ?? "")}
                onChange={(value) => handleSelectEndpoint(Number(value))}
                options={endpoints.map((endpoint) => ({
                  value: String(endpoint.id),
                  label: `${endpoint.name}${endpoint.status === "disabled" ? " (disabled)" : ""}`,
                }))}
              />
            </label>
          )}
        </div>

        {error && <div className="mb-6 rounded-2xl bg-red-50 p-4 text-sm text-red-700">{error}</div>}

        {selectedId ? (
          <DataPreviewTable endpointId={selectedId} showExportCsv={false} />
        ) : (
          <div className="flex min-h-[320px] flex-col items-center justify-center rounded-3xl border border-dashed border-slate-300 bg-white p-12 text-center">
            <Search size={36} className="text-slate-300" />
            <h3 className="mt-4 text-lg font-bold text-slate-900">No endpoint available</h3>
            <p className="mt-2 max-w-md text-sm text-slate-600">
              No REST endpoint has been registered yet. Register one to use it as a Transaction
              Search data source.
            </p>
            {canEdit && (
              <Link
                to="/api-endpoints/new"
                className="mt-6 rounded-lg bg-[#00796B] px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-[#00695C]"
              >
                Register an Endpoint
              </Link>
            )}
          </div>
        )}
      </SidebarLayout>

      <PageChatbot agentType="transactions" pageData={{ endpointId: selectedId }} />
    </>
  );
}
