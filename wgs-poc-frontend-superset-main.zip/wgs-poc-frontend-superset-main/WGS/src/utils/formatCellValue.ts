/**
 * Generic cell-value formatter for arbitrary REST response data, extracted
 * from TemplateView.tsx's original formatCellValue (its currency-lookup
 * behavior is specific to saved report templates and stays local there).
 */
export function formatCellValue(value: unknown): string {
  if (value === null || value === undefined) return "-";

  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
    return String(value);
  }

  if (Array.isArray(value)) {
    return value
      .map((item) => (typeof item === "object" && item !== null ? JSON.stringify(item) : String(item)))
      .join(", ");
  }

  if (typeof value === "object") {
    const obj = value as Record<string, unknown>;
    const keys = Object.keys(obj);
    if (keys.length === 1) return formatCellValue(obj[keys[0]]);
    return JSON.stringify(obj);
  }

  return String(value);
}
