import { jwtDecode } from "jwt-decode";
import { clearPermissionsCache } from "./permissions";

type JwtPayload = {
  sub?: string;
  role?: string;
  username?: string;
  email?: string;
  exp?: number;
};

const TOKEN_KEY = "access_token";
const DASHBOARD_OWNER_MAP_KEY = "dashboardOwners";
const CLOCK_SKEW_SECONDS = 30;

export function getStoredAccessToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function getJwtPayload(): JwtPayload | null {
  const token = getStoredAccessToken();
  if (!token) return null;

  try {
    return jwtDecode<JwtPayload>(token);
  } catch {
    return null;
  }
}

export function getCurrentRole(): string {
  return getJwtPayload()?.role?.toLowerCase() ?? "";
}

export function getCurrentUserKey(): string {
  const payload = getJwtPayload();
  return payload?.sub ?? payload?.username ?? payload?.email ?? "";
}

type OwnerMap = Record<string, string>;

export function getDashboardOwnerMap(): OwnerMap {
  try {
    return JSON.parse(localStorage.getItem(DASHBOARD_OWNER_MAP_KEY) ?? "{}") as OwnerMap;
  } catch {
    return {};
  }
}

export function isAuthenticated(): boolean {
  const token = getStoredAccessToken();
  if (!token) return false;

  const payload = getJwtPayload();
  if (!payload) return false;

  if (payload.exp && Date.now() / 1000 > payload.exp - CLOCK_SKEW_SECONDS) {
    logout();
    return false;
  }

  return true;
}

export function logout(): void {
  localStorage.removeItem(TOKEN_KEY);
  // Clear any legacy keys from older sessions
  localStorage.removeItem("accessToken");
  localStorage.removeItem("authToken");
  localStorage.removeItem("role");
  localStorage.removeItem("user_id");
  clearPermissionsCache();
}

export function rememberDashboardOwner(dashboardUuid: string, ownerKey: string) {
  if (!dashboardUuid || !ownerKey) return;

  const map = getDashboardOwnerMap();
  map[dashboardUuid] = ownerKey;
  localStorage.setItem(DASHBOARD_OWNER_MAP_KEY, JSON.stringify(map));
}
