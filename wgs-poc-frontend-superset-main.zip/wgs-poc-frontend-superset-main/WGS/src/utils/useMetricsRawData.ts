import { useEffect, useState } from "react";
import { apiFetch } from "./api";
import { API } from "./api-endpoints";
import type { SchemaColumn } from "./filterFieldConfig";

const RAW_ROW_CAP = 20_000;

/**
 * Fetches raw rows for every classified dimension/metric column, once per dataset, via the existing
 * datasetQuery endpoint. Aggregation itself happens client-side (see metricsAggregation.ts) so the
 * Metrics Builder preview never needs a new backend contract — a fresh fetch here just means a fresh
 * base for that in-memory aggregation.
 */
export function useMetricsRawData(datasetId: string | number | null, columns: SchemaColumn[]) {
  const [rows, setRows] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      const relevantColumns = columns.filter((c) => c.column_name);

      if (!datasetId || !relevantColumns.length) {
        setRows([]);
        return;
      }

      setLoading(true);
      setError(null);

      try {
        const columnNames = Array.from(new Set(relevantColumns.map((c) => c.column_name!)));
        const resp = await apiFetch(API.superset.datasetQuery(datasetId), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ columns: columnNames, filters: [], row_limit: RAW_ROW_CAP, row_offset: 0 }),
        });

        if (!resp.ok) {
          const text = await resp.text();
          throw new Error(text || "Unable to load data for the preview.");
        }

        const data = await resp.json();
        if (!cancelled) setRows(Array.isArray(data.rows) ? data.rows : []);
      } catch (err) {
        if (!cancelled) {
          setRows([]);
          setError(err instanceof Error ? err.message : "Unable to load data for the preview.");
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    void load();
    return () => {
      cancelled = true;
    };
  }, [datasetId, columns]);

  return { rows, loading, error };
}
