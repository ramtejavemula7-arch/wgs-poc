export type CurrencyCode = "NONE" | "INR" | "USD" | "EUR" | "GBP" | "JPY";

export const CURRENCY_OPTIONS: { value: CurrencyCode; label: string }[] = [
  { value: "NONE", label: "Plain number" },
  { value: "INR", label: "₹ Rupee (INR)" },
  { value: "USD", label: "$ Dollar (USD)" },
  { value: "EUR", label: "€ Euro (EUR)" },
  { value: "GBP", label: "£ Pound (GBP)" },
  { value: "JPY", label: "¥ Yen (JPY)" },
];

const CURRENCY_META: Record<Exclude<CurrencyCode, "NONE">, { symbol: string; locale: string }> = {
  INR: { symbol: "₹", locale: "en-IN" },
  USD: { symbol: "$", locale: "en-US" },
  EUR: { symbol: "€", locale: "de-DE" },
  GBP: { symbol: "£", locale: "en-GB" },
  JPY: { symbol: "¥", locale: "ja-JP" },
};

/** Returns the formatted currency string, or null if `currency` is unset/"NONE" or `value` isn't numeric. */
export function formatCurrencyValue(value: unknown, currency: CurrencyCode | undefined | null): string | null {
  if (!currency || currency === "NONE") return null;
  const num = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(num)) return null;

  const meta = CURRENCY_META[currency];
  try {
    return new Intl.NumberFormat(meta.locale, {
      style: "currency",
      currency,
      maximumFractionDigits: 2,
    }).format(num);
  } catch {
    return `${meta.symbol}${num.toFixed(2)}`;
  }
}
