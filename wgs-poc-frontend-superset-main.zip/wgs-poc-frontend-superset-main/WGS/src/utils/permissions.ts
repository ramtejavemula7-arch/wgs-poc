import { useEffect, useState } from "react";
import { apiFetch } from "./api";
import { API } from "./api-endpoints";

export type AccessLevel = "none" | "read" | "edit";

export type PermissionModule =
  | "dashboard"
  | "reports"
  | "transaction_search"
  | "rest_endpoints"
  | "admin"
  | "users"
  | "roles";

type PermissionEntry = {
  module?: string;
  access_level?: string;
};

type RoleRecord = {
  id?: string;
  name?: string;
  permissions?: PermissionEntry[];
};

type CurrentUser = {
  id?: string;
  username?: string;
  email?: string;
  role_id?: string | null;
  is_active?: boolean;
};

function normalizePermissions(entries?: PermissionEntry[]): Record<string, AccessLevel> {
  const map: Record<string, AccessLevel> = {};
  (entries ?? []).forEach((entry) => {
    if (!entry.module) return;
    map[entry.module] = entry.access_level === "read" || entry.access_level === "edit" ? entry.access_level : "none";
  });
  return map;
}

let cachedPermissions: Record<string, AccessLevel> | null = null;
let inflightRequest: Promise<Record<string, AccessLevel>> | null = null;

async function fetchCurrentUserPermissions(): Promise<Record<string, AccessLevel>> {
  try {
    const meResp = await apiFetch(API.users.me);
    if (!meResp.ok) return {};

    const me = (await meResp.json()) as CurrentUser;
    if (!me.role_id) return {};

    const roleResp = await apiFetch(API.roles.detail(me.role_id));
    if (!roleResp.ok) return {};

    const role = (await roleResp.json()) as RoleRecord;
    return normalizePermissions(role.permissions);
  } catch {
    return {};
  }
}

/**
 * Permissions are keyed off the logged-in user's role_id (from /users/me), not the
 * role name in the JWT — the backend already resolves admin to "edit" on every
 * module, so there's no client-side admin special-case here.
 */
export async function loadCurrentUserPermissions(): Promise<Record<string, AccessLevel>> {
  if (cachedPermissions) return cachedPermissions;

  if (!inflightRequest) {
    inflightRequest = fetchCurrentUserPermissions().finally(() => {
      inflightRequest = null;
    });
  }

  const map = await inflightRequest;
  cachedPermissions = map;
  return map;
}

export function clearPermissionsCache() {
  cachedPermissions = null;
}

export function useModuleAccess(module: PermissionModule) {
  const [access, setAccess] = useState<AccessLevel>("none");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);

    loadCurrentUserPermissions().then((map) => {
      if (cancelled) return;
      setAccess(map[module] ?? "none");
      setLoading(false);
    });

    return () => {
      cancelled = true;
    };
  }, [module]);

  return {
    access,
    loading,
    canView: access === "read" || access === "edit",
    canEdit: access === "edit",
  };
}
