/**
 * Dot-notation flattening + tabular row discovery for arbitrary REST JSON
 * responses. Arrays are deliberately left as a single column holding the raw
 * array (never expanded into indexed columns like items.0.sku) because array
 * length varies row-to-row in real API responses, which would otherwise
 * produce a ragged, unbounded column set across a sample of rows.
 */

export type DiscoveredRows = {
  rows: Record<string, unknown>[];
  rootKind: "array" | "object-array-property" | "single-object";
  sourceArrayKey?: string;
};

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export function flattenObject(obj: unknown, prefix = ""): Record<string, unknown> {
  const result: Record<string, unknown> = {};

  if (!isPlainObject(obj)) {
    result[prefix || "value"] = obj;
    return result;
  }

  Object.keys(obj).forEach((key) => {
    const path = prefix ? `${prefix}.${key}` : key;
    const value = obj[key];

    if (isPlainObject(value)) {
      Object.assign(result, flattenObject(value, path));
    } else {
      // Arrays and primitives are both stored as-is under this one path.
      result[path] = value;
    }
  });

  return result;
}

export function discoverRows(raw: unknown): DiscoveredRows {
  if (Array.isArray(raw)) {
    return {
      rows: raw.map((item) => (isPlainObject(item) ? item : { value: item })),
      rootKind: "array",
    };
  }

  if (isPlainObject(raw)) {
    const arrayKey = Object.keys(raw).find((key) => Array.isArray(raw[key]));
    if (arrayKey) {
      const arrayValue = raw[arrayKey] as unknown[];
      return {
        rows: arrayValue.map((item) => (isPlainObject(item) ? item : { value: item })),
        rootKind: "object-array-property",
        sourceArrayKey: arrayKey,
      };
    }
    return { rows: [raw], rootKind: "single-object" };
  }

  // Defensive fallback for an unexpected primitive/null top-level body.
  return { rows: [{ value: raw }], rootKind: "single-object" };
}

export function discoverFields(rows: Record<string, unknown>[], sampleSize = 50): string[] {
  const seen = new Set<string>();
  const ordered: string[] = [];

  rows.slice(0, sampleSize).forEach((row) => {
    const flattened = flattenObject(row);
    Object.keys(flattened).forEach((key) => {
      if (!seen.has(key)) {
        seen.add(key);
        ordered.push(key);
      }
    });
  });

  return ordered;
}

export function prettifyFieldName(field: string): string {
  const lastSegment = field.split(".").pop() ?? field;
  const words = lastSegment
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
    .split(/[_\-\s]+/)
    .filter(Boolean);

  return words.map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()).join(" ");
}
