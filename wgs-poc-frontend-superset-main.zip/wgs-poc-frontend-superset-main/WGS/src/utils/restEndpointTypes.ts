import { uuid } from "./uuid";

export type HttpMethod = "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
export type EndpointStatus = "enabled" | "disabled";
export type KeyValuePair = { key: string; value: string };

export const HTTP_METHODS: HttpMethod[] = ["GET", "POST", "PUT", "PATCH", "DELETE"];

/** Only these 4 are supported by the backend today. */
export type AuthType = "none" | "api_key" | "basic_auth" | "bearer_token";

export type AuthConfig =
  | { type: "none" }
  | { type: "api_key"; apiKeyName: string; sendIn: "header" | "query" | "cookie" }
  | { type: "basic_auth"; username: string }
  | { type: "bearer_token" };

export const AUTH_TYPE_LABELS: Record<AuthType, string> = {
  none: "None",
  api_key: "API Key",
  basic_auth: "Basic Authentication",
  bearer_token: "Bearer Token",
};

export const AUTH_TYPE_OPTIONS: { value: AuthType; label: string }[] = (
  Object.keys(AUTH_TYPE_LABELS) as AuthType[]
).map((type) => ({ value: type, label: AUTH_TYPE_LABELS[type] }));

export function createDefaultAuthConfig(type: AuthType): AuthConfig {
  switch (type) {
    case "none":
      return { type: "none" };
    case "api_key":
      return { type: "api_key", apiKeyName: "", sendIn: "header" };
    case "basic_auth":
      return { type: "basic_auth", username: "" };
    case "bearer_token":
      return { type: "bearer_token" };
  }
}

export type RestEndpointSummary = {
  id: number;
  name: string;
  base_url: string;
  http_method: HttpMethod;
  auth_type: AuthType;
  status: EndpointStatus;
  updated_at: string;
};

/** Raw wire shape returned by GET list/detail/create/update (snake_case, matches the backend directly). */
export type RestEndpointApiResponse = {
  id: number;
  name: string;
  description: string | null;
  base_url: string;
  endpoint_path: string | null;
  http_method: HttpMethod;
  timeout: number;
  custom_headers: { name: string; value: string }[];
  query_params: { name: string; value: string }[];
  auth_type: AuthType;
  auth_config: Record<string, unknown>;
  has_secret: boolean;
  status: EndpointStatus;
  created_at?: string;
  updated_at?: string;
};

/** Body shape for POST create, PUT update, and POST test-connection (draft) — the backend docs
 *  confirm the draft test endpoint takes "the same body as Create". */
export type RestEndpointRequestBody = {
  name: string;
  description: string | null;
  base_url: string;
  endpoint_path: string | null;
  http_method: HttpMethod;
  timeout: number;
  custom_headers: { name: string; value: string }[];
  query_params: { name: string; value: string }[];
  auth_type: AuthType;
  auth_config: Record<string, unknown>;
  secret_value?: string;
};

/**
 * Response Mapping and Filters below are entirely client-side for now — the
 * backend's create/update body has no fields to persist them, so they exist
 * only for the current editing session (see RestEndpointRegistration.tsx).
 */
export type MappedField = {
  fieldPath: string;
  alias: string;
  selected: boolean;
  /** Every selected field automatically becomes a search box above the table in Data
   *  Preview/Transaction Search — this picks which control it uses. */
  filterType: FilterValueInputType;
};

export type FilterOperator =
  | "equals"
  | "not_equals"
  | "greater_than"
  | "less_than"
  | "greater_than_or_equal"
  | "less_than_or_equal"
  | "contains"
  | "starts_with"
  | "ends_with"
  | "in"
  | "not_in"
  | "is_null"
  | "is_not_null";

export const FILTER_OPERATOR_LABELS: Record<FilterOperator, string> = {
  equals: "Equals",
  not_equals: "Not Equals",
  greater_than: "Greater Than",
  less_than: "Less Than",
  greater_than_or_equal: "Greater Than or Equal",
  less_than_or_equal: "Less Than or Equal",
  contains: "Contains",
  starts_with: "Starts With",
  ends_with: "Ends With",
  in: "In",
  not_in: "Not In",
  is_null: "Is Null",
  is_not_null: "Is Not Null",
};

export const FILTER_OPERATORS_WITHOUT_VALUE: FilterOperator[] = ["is_null", "is_not_null"];

/** Which control a field's auto-derived search box uses. A new field defaults to the type
 *  inferred from its sample data (see filterFieldTypeDetection.ts), but the admin can override
 *  it per field in Response Mapping. */
export type FilterValueInputType = "dropdown" | "date" | "text";

export const FILTER_VALUE_INPUT_TYPE_LABELS: Record<FilterValueInputType, string> = {
  dropdown: "Dropdown",
  date: "Date",
  text: "Text",
};

export type FilterCondition = {
  id: string;
  field: string;
  operator: FilterOperator;
  value?: string;
  valueInputType?: FilterValueInputType;
};

export type FilterConfig = {
  conditions: FilterCondition[];
  combinator: "AND" | "OR";
};

/**
 * Filters are no longer manually added — every selected Response Mapping field automatically
 * becomes a search condition, using "contains" (works well for text/dropdown-exact-value/date
 * matches alike; see applyClientFilters.ts) and each field's own chosen filter control type.
 * Existing conditions for fields still selected keep their prior operator/value/id.
 */
export function deriveFilterConditionsFromMapping(
  mapping: MappedField[],
  existingConditions: FilterCondition[] = []
): FilterCondition[] {
  const existingByField = new Map(existingConditions.map((c) => [c.field, c]));

  return mapping
    .filter((m) => m.selected)
    .map((m) => {
      const existing = existingByField.get(m.fieldPath);
      return {
        id: existing?.id ?? uuid(),
        field: m.fieldPath,
        operator: existing?.operator ?? "contains",
        value: existing?.value ?? "",
        valueInputType: m.filterType,
      };
    });
}

export const EMPTY_FILTER_CONFIG: FilterConfig = { conditions: [], combinator: "AND" };

/** Response shape for both /test-connection variants (draft and saved). raw_response is a string,
 *  truncated to ~20KB by the backend — not a parsed object. */
export type TestConnectionResult = {
  statusCode: number | null;
  elapsedMs: number | null;
  success: boolean;
  message: string;
  rawResponse: string;
  testedAt: string;
};

export type RawTestConnectionResponse = {
  status_code: number | null;
  elapsed_ms: number | null;
  success: boolean;
  message: string;
  raw_response: string;
};

export function parseTestConnectionResult(raw: RawTestConnectionResponse): TestConnectionResult {
  return {
    statusCode: raw.status_code,
    elapsedMs: raw.elapsed_ms,
    success: raw.success,
    message: raw.message,
    rawResponse: raw.raw_response,
    testedAt: new Date().toISOString(),
  };
}

export type RestEndpointConfig = {
  id: number | null;
  name: string;
  description: string;
  baseUrl: string;
  endpointPath: string;
  httpMethod: HttpMethod;
  timeout: number;
  customHeaders: KeyValuePair[];
  queryParams: KeyValuePair[];
  authType: AuthType;
  authConfig: AuthConfig;
  secretValue: string;
  hasSecret: boolean;
  status: EndpointStatus;
  updatedAt?: string;
  responseMapping: MappedField[];
  filters: FilterConfig;
};

export function createDefaultEndpointConfig(): RestEndpointConfig {
  return {
    id: null,
    name: "",
    description: "",
    baseUrl: "",
    endpointPath: "",
    httpMethod: "GET",
    timeout: 30,
    customHeaders: [],
    queryParams: [],
    authType: "none",
    authConfig: createDefaultAuthConfig("none"),
    secretValue: "",
    hasSecret: false,
    status: "enabled",
    responseMapping: [],
    filters: { ...EMPTY_FILTER_CONFIG },
  };
}

function authConfigToPayload(auth: AuthConfig): Record<string, unknown> {
  switch (auth.type) {
    case "none":
      return {};
    case "api_key":
      return { api_key_name: auth.apiKeyName, send_in: auth.sendIn };
    case "basic_auth":
      return { username: auth.username };
    case "bearer_token":
      return {};
  }
}

/** Builds the exact body for POST create / PUT update / POST test-connection (draft). */
export function buildRequestBody(config: RestEndpointConfig): RestEndpointRequestBody {
  const body: RestEndpointRequestBody = {
    name: config.name.trim(),
    description: config.description.trim() || null,
    base_url: config.baseUrl.trim(),
    endpoint_path: config.endpointPath.trim() || null,
    http_method: config.httpMethod,
    timeout: config.timeout,
    custom_headers: config.customHeaders.map((h) => ({ name: h.key, value: h.value })),
    query_params: config.queryParams.map((p) => ({ name: p.key, value: p.value })),
    auth_type: config.authType,
    auth_config: authConfigToPayload(config.authConfig),
  };
  if (config.secretValue.trim()) {
    body.secret_value = config.secretValue;
  }
  return body;
}

function parseAuthConfig(authType: AuthType, raw: Record<string, unknown>): AuthConfig {
  switch (authType) {
    case "api_key":
      return {
        type: "api_key",
        apiKeyName: typeof raw.api_key_name === "string" ? raw.api_key_name : "",
        sendIn: raw.send_in === "query" || raw.send_in === "cookie" ? raw.send_in : "header",
      };
    case "basic_auth":
      return { type: "basic_auth", username: typeof raw.username === "string" ? raw.username : "" };
    case "bearer_token":
      return { type: "bearer_token" };
    default:
      return { type: "none" };
  }
}

/** Parses a GET list/detail/create/update response into the app's internal config shape.
 *  Response Mapping/Filters are never returned by the backend, so they always start empty here —
 *  re-running Test Connection re-populates them for the current session. */
export function parseEndpointResponse(data: RestEndpointApiResponse): RestEndpointConfig {
  return {
    id: data.id,
    name: data.name ?? "",
    description: data.description ?? "",
    baseUrl: data.base_url ?? "",
    endpointPath: data.endpoint_path ?? "",
    httpMethod: data.http_method ?? "GET",
    timeout: data.timeout ?? 30,
    customHeaders: (data.custom_headers ?? []).map((h) => ({ key: h.name, value: h.value })),
    queryParams: (data.query_params ?? []).map((p) => ({ key: p.name, value: p.value })),
    authType: data.auth_type ?? "none",
    authConfig: parseAuthConfig(data.auth_type, data.auth_config ?? {}),
    secretValue: "",
    hasSecret: Boolean(data.has_secret),
    status: data.status ?? "enabled",
    updatedAt: data.updated_at,
    responseMapping: [],
    filters: { ...EMPTY_FILTER_CONFIG },
  };
}
