import type { FilterCondition, FilterConfig } from "./restEndpointTypes";

function toNumber(value: unknown): number {
  return typeof value === "number" ? value : Number(value);
}

function splitList(value: string): string[] {
  return value
    .split(",")
    .map((v) => v.trim())
    .filter(Boolean);
}

export function evaluateCondition(row: Record<string, unknown>, condition: FilterCondition): boolean {
  const raw = row[condition.field];
  const rawStr = raw === null || raw === undefined ? "" : String(raw);
  const value = condition.value ?? "";

  switch (condition.operator) {
    case "equals":
      return rawStr === value;
    case "not_equals":
      return rawStr !== value;
    case "greater_than":
      return toNumber(raw) > toNumber(value);
    case "less_than":
      return toNumber(raw) < toNumber(value);
    case "greater_than_or_equal":
      return toNumber(raw) >= toNumber(value);
    case "less_than_or_equal":
      return toNumber(raw) <= toNumber(value);
    case "contains":
      return rawStr.toLowerCase().includes(value.toLowerCase());
    case "starts_with":
      return rawStr.toLowerCase().startsWith(value.toLowerCase());
    case "ends_with":
      return rawStr.toLowerCase().endsWith(value.toLowerCase());
    case "in":
      return splitList(value).includes(rawStr);
    case "not_in":
      return !splitList(value).includes(rawStr);
    case "is_null":
      return raw === null || raw === undefined || raw === "";
    case "is_not_null":
      return !(raw === null || raw === undefined || raw === "");
    default:
      return true;
  }
}

/** Applies the endpoint's default filters to a set of already-flattened rows, client-side —
 *  the backend has no persistence/enforcement for these yet (see restEndpointTypes.ts). */
export function applyFilterConfig(
  rows: Record<string, unknown>[],
  config: FilterConfig
): Record<string, unknown>[] {
  if (!config.conditions.length) return rows;

  return rows.filter((row) => {
    const results = config.conditions.map((condition) => evaluateCondition(row, condition));
    return config.combinator === "AND" ? results.every(Boolean) : results.some(Boolean);
  });
}
