import { normalizeFieldName } from "./metricsFieldClassification";
import { ORDER_COUNT_FIELD, type AggregationFn, type MetricSelection } from "./metricsAggregation";
import type { StructuredFilter } from "./filterFieldConfig";

export type MetricsReportConfig = {
  dimensions: string[]; // ordered real column_names — the Row hierarchy, deepest last
  columnField: string | null; // optional single dimension pivoted into columns
  metrics: MetricSelection[]; // the Values, in display order
  filters: StructuredFilter[];
  sortField: string | null; // a dimension's column_name, or a metric's label
  sortDirection: "asc" | "desc";
  columnSortDirection: "asc" | "desc"; // order of the pivoted column headers, when columnField is set
};

export const DEFAULT_METRICS_CONFIG: MetricsReportConfig = {
  dimensions: [],
  columnField: null,
  metrics: [],
  filters: [],
  sortField: null,
  sortDirection: "asc",
  columnSortDirection: "asc",
};

type PresetMetric = { field: string; aggregation: AggregationFn };

export type MetricsPreset = {
  key: string;
  label: string;
  description: string;
  dimensions: string[]; // normalized field names
  columnField?: string; // normalized field name
  metrics: PresetMetric[]; // field is a normalized name, or ORDER_COUNT_FIELD
};

export const METRICS_PRESETS: MetricsPreset[] = [
  {
    key: "sales-by-region",
    label: "Sales by Region",
    description: "Category rows, Region columns, total sales.",
    dimensions: ["category"],
    columnField: "region",
    metrics: [{ field: "sales", aggregation: "SUM" }],
  },
  {
    key: "profit-analysis",
    label: "Profit Analysis",
    description: "Category rows, Segment columns, total profit.",
    dimensions: ["category"],
    columnField: "segment",
    metrics: [{ field: "profit", aggregation: "SUM" }],
  },
  {
    key: "quantity-by-ship-mode",
    label: "Quantity by Ship Mode",
    description: "Category rows, Ship Mode columns, total quantity.",
    dimensions: ["category"],
    columnField: "ship_mode",
    metrics: [{ field: "quantity", aggregation: "SUM" }],
  },
  {
    key: "regional-performance",
    label: "Regional Performance",
    description: "State rows, Region columns, sales and profit.",
    dimensions: ["state"],
    columnField: "region",
    metrics: [
      { field: "sales", aggregation: "SUM" },
      { field: "profit", aggregation: "SUM" },
    ],
  },
];

export type PresetResolvableField = {
  columnName: string;
  label: string;
};

/** Maps a preset's normalized field names onto the actual dataset columns available right now. */
export function resolvePreset(preset: MetricsPreset, availableFields: PresetResolvableField[]): MetricsReportConfig {
  const byNormalizedName = new Map(availableFields.map((f) => [normalizeFieldName(f.columnName), f]));

  const dimensions = preset.dimensions
    .map((name) => byNormalizedName.get(name)?.columnName)
    .filter((v): v is string => Boolean(v));

  const columnField = preset.columnField ? byNormalizedName.get(preset.columnField)?.columnName ?? null : null;

  const metrics: MetricSelection[] = preset.metrics
    .map((m) => {
      if (m.field === ORDER_COUNT_FIELD) {
        return { field: ORDER_COUNT_FIELD, label: "Order Count", aggregation: m.aggregation };
      }
      const resolved = byNormalizedName.get(m.field);
      return resolved ? { field: resolved.columnName, label: resolved.label, aggregation: m.aggregation } : null;
    })
    .filter((v): v is MetricSelection => Boolean(v));

  return {
    dimensions,
    columnField,
    metrics,
    filters: [],
    sortField: null,
    sortDirection: "asc",
    columnSortDirection: "asc",
  };
}
