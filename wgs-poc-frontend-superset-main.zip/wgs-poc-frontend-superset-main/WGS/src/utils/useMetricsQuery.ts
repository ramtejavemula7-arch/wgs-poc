import { useEffect, useState } from "react";
import { apiFetch } from "./api";
import { API } from "./api-endpoints";
import type { MetricsReportConfig } from "./metricsPresets";

const DEBOUNCE_MS = 400;
const DEFAULT_ROW_LIMIT = 100;

/**
 * Calls POST /api/superset/datasets/{id}/metrics-query — real server-side GROUP BY + aggregation.
 * Result rows are keyed by dimension column_name for dimensions, and by each metric's `label`
 * (not its `field`) for metric values, per the backend contract.
 */
export function useMetricsQuery(
  datasetId: string | number | null,
  config: MetricsReportConfig,
  rowLimit: number = DEFAULT_ROW_LIMIT,
  rowOffset: number = 0
) {
  const [rows, setRows] = useState<Record<string, unknown>[]>([]);
  const [total, setTotal] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!datasetId || !config.metrics.length) {
      setRows([]);
      setTotal(null);
      setError(null);
      return;
    }

    const timer = setTimeout(async () => {
      setLoading(true);
      setError(null);

      try {
        // sort.field must exactly match a dimension name or a metric's label — anything else is
        // silently dropped server-side, but we scrub it client-side too so stale references from a
        // just-removed dimension/metric don't linger.
        const validSortField =
          config.sortField &&
          (config.dimensions.includes(config.sortField) || config.metrics.some((m) => m.label === config.sortField))
            ? config.sortField
            : null;

        const resp = await apiFetch(API.superset.metricsQuery(datasetId), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            dimensions: config.dimensions,
            metrics: config.metrics.map((m) => ({ field: m.field, aggregation: m.aggregation, label: m.label })),
            sort: validSortField ? { field: validSortField, direction: config.sortDirection } : null,
            filters: [],
            row_limit: rowLimit,
            row_offset: rowOffset,
          }),
        });

        if (!resp.ok) {
          const text = await resp.text();
          throw new Error(text || "Unable to load the metrics preview.");
        }

        const data = await resp.json();
        const fetchedRows = Array.isArray(data.rows) ? data.rows : [];
        setRows(fetchedRows);
        setTotal(typeof data.rowcount === "number" ? data.rowcount : null);
      } catch (err) {
        setRows([]);
        setTotal(null);
        setError(err instanceof Error ? err.message : "Unable to load the metrics preview.");
      } finally {
        setLoading(false);
      }
    }, DEBOUNCE_MS);

    return () => clearTimeout(timer);
  }, [datasetId, config, rowLimit, rowOffset]);

  return { rows, total, loading, error };
}
