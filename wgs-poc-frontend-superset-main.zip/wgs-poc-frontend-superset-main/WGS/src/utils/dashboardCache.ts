import { apiFetch } from "./api";
import { API } from "./api-endpoints";

// Module-level: holds the in-flight or resolved promise started at login time.
let prefetchPromise: Promise<Response> | null = null;

/** Call immediately after login succeeds (token already in localStorage). */
export function prefetchDashboards(): void {
  prefetchPromise = apiFetch(API.superset.embed);
}

/**
 * Returns and clears the prefetch promise so Dashboard can await it once.
 * Returns null if no prefetch was started (fallback to normal fetch).
 */
export function consumeDashboardPrefetch(): Promise<Response> | null {
  const p = prefetchPromise;
  prefetchPromise = null;
  return p;
}
