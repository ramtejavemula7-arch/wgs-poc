import { getStoredAccessToken } from "./auth";

const TIMEOUT_MS = 30_000;

type ApiFetchOptions = RequestInit & {
  auth?: boolean;
  timeout?: number;
};

export async function apiFetch(
  input: RequestInfo | URL,
  options: ApiFetchOptions = {}
) {
  const headers = new Headers(options.headers);

  if (options.auth !== false) {
    const token = getStoredAccessToken();
    if (token && !headers.has("Authorization")) {
      headers.set("Authorization", `Bearer ${token}`);
    }
  }

  const effectiveTimeout = options.timeout ?? TIMEOUT_MS;
  const controller = new AbortController();
  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, effectiveTimeout);

  try {
    return await fetch(input, {
      ...options,
      headers,
      signal: options.signal ?? controller.signal,
    });
  } catch (err) {
    // The raw AbortError from our own timeout reads as "signal is aborted without reason" —
    // give every caller (they all just do `err instanceof Error ? err.message : ...`) something
    // a user can actually understand, instead of that browser-internal wording.
    if (timedOut) {
      throw new Error(`Request timed out after ${Math.round(effectiveTimeout / 1000)}s. Please try again.`);
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}
