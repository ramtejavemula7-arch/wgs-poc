import { useRef, useState } from "react";
import { getStoredAccessToken } from "./auth";
import { API } from "./api-endpoints";

export type ExportFormat = "pdf" | "excel" | "visual-image";
export type ExportSource = "template" | "dashboard";
export type ExportStatus = "idle" | "pending" | "downloading" | "done" | "error";

export type ExportState = {
  status: ExportStatus;
  error: string | null;
};

const POLL_INTERVAL_MS = 2500;
const TIMEOUT_MS = 300_000; // 5 minutes

function authHeaders(): Record<string, string> {
  const token = getStoredAccessToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export function useExport() {
  const [exportState, setExportState] = useState<ExportState>({ status: "idle", error: null });
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  function stopPolling() {
    if (intervalRef.current !== null) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }

  async function triggerExport(
    source: ExportSource,
    id: string,
    format: ExportFormat
  ) {
    if (exportState.status === "pending" || exportState.status === "downloading") return;

    setExportState({ status: "pending", error: null });
    const headers = authHeaders();

    try {
      const startUrl =
        source === "template"
          ? API.templates.exportStart(id, format)
          : API.superset.dashboardExportStart(id, format);

      const startResp = await fetch(startUrl, { method: "POST", headers });
      if (!startResp.ok) {
        const text = await startResp.text();
        throw new Error(text || "Export failed to start.");
      }
      const { job_id } = await startResp.json() as { job_id: string };

      const statusUrl =
        source === "template"
          ? API.templates.exportStatus(job_id)
          : API.superset.dashboardExportStatus(job_id);

      const deadline = Date.now() + TIMEOUT_MS;

      await new Promise<void>((resolve, reject) => {
        intervalRef.current = setInterval(async () => {
          if (Date.now() > deadline) {
            stopPolling();
            reject(new Error("Export timed out after 5 minutes."));
            return;
          }
          try {
            const statusResp = await fetch(statusUrl, { headers });
            const data = await statusResp.json() as { status: string; error?: string };
            if (data.status === "done") { stopPolling(); resolve(); }
            else if (data.status === "error") { stopPolling(); reject(new Error(data.error || "Export failed.")); }
          } catch {
            // transient network error — keep polling
          }
        }, POLL_INTERVAL_MS);
      });

      setExportState({ status: "downloading", error: null });

      const downloadUrl =
        source === "template"
          ? API.templates.exportDownload(job_id)
          : API.superset.dashboardExportDownload(job_id);

      const downloadResp = await fetch(downloadUrl, { headers });
      if (!downloadResp.ok) throw new Error("File download failed.");

      const blob = await downloadResp.blob();
      const disposition = downloadResp.headers.get("Content-Disposition") ?? "";
      const serverFilename = disposition.match(/filename="([^"]+)"/)?.[1];
      const ext = format === "pdf" ? "pdf" : format === "visual-image" ? "png" : "xlsx";
      const filename = serverFilename ?? `export.${ext}`;
      const objectUrl = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = objectUrl;
      anchor.download = filename;
      anchor.click();
      URL.revokeObjectURL(objectUrl);

      setExportState({ status: "done", error: null });
      setTimeout(() => setExportState({ status: "idle", error: null }), 2000);
    } catch (err) {
      stopPolling();
      setExportState({
        status: "error",
        error: err instanceof Error ? err.message : "Export failed.",
      });
    }
  }

  function dismissError() {
    if (exportState.status === "error") {
      setExportState({ status: "idle", error: null });
    }
  }

  return { exportState, triggerExport, dismissError };
}
