import { useEffect, useState } from "react";
import { apiFetch } from "./api";
import { API } from "./api-endpoints";
import { prettifyFieldLabel } from "./metricsFieldClassification";

export type FilterFieldType = "date" | "numeric" | "boolean" | "categorical" | "text";
export type FilterOperator = "EQ" | "IN" | "BETWEEN" | "LIKE";

export type StructuredFilter = {
  field: string;
  operator: FilterOperator;
  value: unknown;
};

/** Human-readable one-liner for a filter, e.g. "Region: East, West" or "Order Date: 2026-01-01 – 2026-03-31". */
export function formatStructuredFilterSummary(filter: StructuredFilter): string {
  const label = prettifyFieldLabel(filter.field);

  if (filter.operator === "BETWEEN" && Array.isArray(filter.value)) {
    const [start, end] = filter.value as unknown[];
    return `${label}: ${String(start ?? "-")} – ${String(end ?? "-")}`;
  }

  if (filter.operator === "IN" && Array.isArray(filter.value)) {
    const values = filter.value as unknown[];
    const shown = values.slice(0, 3).map(String).join(", ");
    const suffix = values.length > 3 ? ` +${values.length - 3} more` : "";
    return `${label}: ${shown}${suffix}`;
  }

  if (filter.operator === "EQ") {
    const shown = filter.value === true ? "Yes" : filter.value === false ? "No" : String(filter.value);
    return `${label}: ${shown}`;
  }

  return `${label} contains "${String(filter.value)}"`;
}

export type SchemaColumn = {
  id?: string | number;
  column_name?: string;
  type?: string;
};

export type FilterFieldConfig = {
  key: string;
  columnName: string;
  fieldType: FilterFieldType;
  distinctValues: string[] | null;
  distinctCount: number | null;
  cardinalityKnown: boolean;
  min: number | null;
  max: number | null;
};

export const CATEGORICAL_CARDINALITY_THRESHOLD = 50;
const SAMPLE_ROW_LIMIT = 500;

/**
 * Doubles as the filter's `field` value sent to the backend, so it must be the actual
 * queryable column name — not the column's internal id — whenever a name is available.
 */
export function getColumnKey(column: SchemaColumn, index: number): string {
  return String(column.column_name ?? column.id ?? `column-${index}`);
}

/** Buckets a raw SQL/Superset type string. Text columns are refined into categorical/text later, once cardinality is known. */
export function detectFieldType(rawType?: string): FilterFieldType {
  const type = (rawType || "").toUpperCase();
  if (/^(DATE|DATETIME|TIMESTAMP|TIME)/.test(type)) return "date";
  if (/^BOOL/.test(type)) return "boolean";
  if (/^(INT|BIGINT|SMALLINT|TINYINT|DECIMAL|NUMERIC|FLOAT|DOUBLE|REAL)/.test(type)) return "numeric";
  return "text";
}

const RELEVANCE_KEYWORDS = [
  "status", "category", "type", "region", "state", "country", "class", "mode",
  "segment", "channel", "department", "priority", "stage",
];

export function scoreColumnRelevance(columnName: string): number {
  const lower = columnName.toLowerCase();
  return RELEVANCE_KEYWORDS.reduce(
    (score, keyword, idx) => (lower.includes(keyword) ? score + (RELEVANCE_KEYWORDS.length - idx) : score),
    0
  );
}

/** Date field first, then the most relevant categorical fields, padded up to `max` (never below `min` when enough fields exist). */
export function pickRecommendedKeys(configs: FilterFieldConfig[], max = 5, min = 3): string[] {
  const dateField = configs.find((c) => c.fieldType === "date");
  const categorical = configs
    .filter((c) => c.fieldType === "categorical")
    .sort((a, b) => scoreColumnRelevance(b.columnName) - scoreColumnRelevance(a.columnName));

  const picked: string[] = [];
  if (dateField) picked.push(dateField.key);
  for (const c of categorical) {
    if (picked.length >= 2 + (dateField ? 1 : 0)) break;
    if (!picked.includes(c.key)) picked.push(c.key);
  }

  if (picked.length < Math.min(min, configs.length)) {
    for (const config of configs) {
      if (picked.length >= Math.min(max, configs.length)) break;
      if (!picked.includes(config.key)) picked.push(config.key);
    }
  }

  return picked.slice(0, max);
}

type BatchColumnStat = {
  distinctCount?: number;
  values?: string[];
  min?: number;
  max?: number;
};

/**
 * `columnBatchData` is wired into the endpoint map but has never been called from the frontend, so its
 * response shape is unconfirmed. Parsed defensively against a few plausible shapes; anything unrecognized
 * is silently ignored and the caller falls back to client-side sampling.
 */
function parseColumnBatchStats(data: unknown): Record<string, BatchColumnStat> {
  if (!data || typeof data !== "object") return {};

  const record = data as Record<string, unknown>;
  const entries: unknown[] = Array.isArray(data)
    ? (data as unknown[])
    : Array.isArray(record.columns)
      ? (record.columns as unknown[])
      : Object.entries(record).map(([key, value]) => ({ column_name: key, ...(value as object) }));

  const map: Record<string, BatchColumnStat> = {};
  entries.forEach((entry) => {
    if (!entry || typeof entry !== "object") return;
    const e = entry as Record<string, unknown>;
    const name = String(e.column_name ?? e.column ?? e.name ?? "");
    if (!name) return;

    const rawValues = Array.isArray(e.values)
      ? e.values
      : Array.isArray(e.distinct_values)
        ? e.distinct_values
        : undefined;

    map[name] = {
      distinctCount: typeof e.distinct_count === "number" ? e.distinct_count : rawValues?.length,
      values: rawValues?.map(String),
      min: typeof e.min === "number" ? e.min : undefined,
      max: typeof e.max === "number" ? e.max : undefined,
    };
  });

  return map;
}

export function useColumnFilterConfigs(datasetId: string | number | null, columns: SchemaColumn[]) {
  const [configs, setConfigs] = useState<FilterFieldConfig[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function build() {
      if (!datasetId || !columns.length) {
        setConfigs([]);
        return;
      }

      setLoading(true);

      const baseConfigs: FilterFieldConfig[] = columns.map((column, index) => ({
        key: getColumnKey(column, index),
        columnName: column.column_name || String(column.id ?? `Column ${index + 1}`),
        fieldType: detectFieldType(column.type),
        distinctValues: null,
        distinctCount: null,
        cardinalityKnown: false,
        min: null,
        max: null,
      }));

      let stats: Record<string, BatchColumnStat> = {};
      try {
        const resp = await apiFetch(API.superset.columnBatchData(datasetId));
        if (resp.ok) {
          stats = parseColumnBatchStats(await resp.json());
        }
      } catch {
        // Endpoint unavailable or unrecognized shape — sampling below covers the gap.
      }

      const statFor = (config: FilterFieldConfig) => stats[config.columnName] || stats[config.key];
      const needsSampling = baseConfigs.some((config) => {
        if (config.fieldType === "text") return !statFor(config)?.values;
        if (config.fieldType === "numeric") {
          const stat = statFor(config);
          return stat?.min === undefined && stat?.max === undefined;
        }
        return false;
      });

      let sampleRows: Record<string, unknown>[] = [];
      if (needsSampling) {
        try {
          const resp = await apiFetch(API.superset.datasetQuery(datasetId), {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              columns: columns.map((c) => c.column_name).filter(Boolean),
              filters: [],
              row_limit: SAMPLE_ROW_LIMIT,
              row_offset: 0,
            }),
          });
          if (resp.ok) {
            const data = await resp.json();
            sampleRows = Array.isArray(data.rows) ? data.rows : [];
          }
        } catch {
          // No sample available — affected fields default to a safe typeahead/free-text control.
        }
      }

      const resolved: FilterFieldConfig[] = baseConfigs.map((config) => {
        const stat = statFor(config);

        if (config.fieldType === "numeric") {
          if (stat?.min !== undefined || stat?.max !== undefined) {
            return { ...config, min: stat.min ?? null, max: stat.max ?? null, cardinalityKnown: true };
          }
          if (sampleRows.length) {
            const nums = sampleRows
              .map((row) => Number(row[config.columnName]))
              .filter((n) => Number.isFinite(n));
            if (nums.length) {
              return { ...config, min: Math.min(...nums), max: Math.max(...nums) };
            }
          }
          return config;
        }

        if (config.fieldType !== "text") return config;

        if (stat?.values) {
          const isLowCardinality = stat.values.length < CATEGORICAL_CARDINALITY_THRESHOLD;
          return {
            ...config,
            fieldType: isLowCardinality ? "categorical" : "text",
            distinctValues: stat.values,
            distinctCount: stat.distinctCount ?? stat.values.length,
            cardinalityKnown: true,
          };
        }

        if (sampleRows.length) {
          const seen = new Set<string>();
          for (const row of sampleRows) {
            const raw = row[config.columnName];
            if (raw !== null && raw !== undefined) seen.add(String(raw));
            if (seen.size >= CATEGORICAL_CARDINALITY_THRESHOLD) break;
          }
          const sampleCoveredWholeDataset = sampleRows.length < SAMPLE_ROW_LIMIT;
          if (seen.size < CATEGORICAL_CARDINALITY_THRESHOLD && sampleCoveredWholeDataset) {
            return {
              ...config,
              fieldType: "categorical",
              distinctValues: Array.from(seen).sort(),
              distinctCount: seen.size,
              cardinalityKnown: true,
            };
          }
        }

        // Cardinality unknown or high — default to typeahead rather than risk rendering thousands of checkboxes.
        return config;
      });

      if (!cancelled) {
        setConfigs(resolved);
        setLoading(false);
      }
    }

    void build();
    return () => {
      cancelled = true;
    };
  }, [datasetId, columns]);

  return { configs, loading };
}
