import { EMPTY_FILTER_CONFIG, type FilterConfig, type MappedField } from "./restEndpointTypes";

/**
 * The backend has no fields/endpoints to persist Response Mapping or Filters yet (confirmed
 * team decision: client-side only for now). Storing them in localStorage, keyed by endpoint id,
 * is what makes a saved mapping actually survive navigation/reload in this browser instead of
 * being lost the instant the Registration page unmounts.
 */
export type StoredMappingConfig = {
  responseMapping: MappedField[];
  filters: FilterConfig;
};

function storageKey(endpointId: string | number): string {
  return `restEndpoint.${endpointId}.mappingConfig`;
}

export function saveClientMappingConfig(endpointId: string | number, config: StoredMappingConfig): void {
  try {
    localStorage.setItem(storageKey(endpointId), JSON.stringify(config));
  } catch {
    // Storage unavailable/full — non-fatal, mapping just won't persist across reloads.
  }
}

export function loadClientMappingConfig(endpointId: string | number): StoredMappingConfig | null {
  try {
    const raw = localStorage.getItem(storageKey(endpointId));
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<StoredMappingConfig> | null;
    if (!parsed || !Array.isArray(parsed.responseMapping)) return null;
    return {
      // Backfills entries saved before "filterType" existed, or with the now-removed "auto"
      // value, so older browsers don't load an invalid Filter Type into the select.
      responseMapping: parsed.responseMapping.map((m) => ({
        ...m,
        filterType: m.filterType && (m.filterType as string) !== "auto" ? m.filterType : "text",
      })),
      filters: parsed.filters ?? { ...EMPTY_FILTER_CONFIG },
    };
  } catch {
    return null;
  }
}
