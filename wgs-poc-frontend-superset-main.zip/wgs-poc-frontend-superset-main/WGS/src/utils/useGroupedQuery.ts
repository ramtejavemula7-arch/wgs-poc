import { useEffect, useState } from "react";
import { apiFetch } from "./api";
import { API } from "./api-endpoints";
import type { StructuredFilter } from "./filterFieldConfig";

const PREVIEW_DEBOUNCE_MS = 400;
const PREVIEW_ROW_LIMIT = 200;

export type GroupedRow = Record<string, unknown>;

function compareValues(a: unknown, b: unknown): number {
  if (a === b) return 0;
  if (a === null || a === undefined) return -1;
  if (b === null || b === undefined) return 1;
  if (typeof a === "number" && typeof b === "number") return a - b;
  return String(a).localeCompare(String(b));
}

/**
 * rowSpans[dimensionIndex][rowIndex] — how many rows this cell should vertically span, or 0
 * if this row's value is already covered by a span starting at an earlier row. A run only
 * continues while every earlier (outer) dimension also still matches the previous row — so a
 * repeated inner value never merges across a change in an outer group.
 */
function computeRowSpans(rows: GroupedRow[], dimensions: string[]): number[][] {
  const n = rows.length;
  const spans = dimensions.map(() => new Array<number>(n).fill(1));

  for (let d = 0; d < dimensions.length; d++) {
    let runStart = 0;
    for (let i = 1; i <= n; i++) {
      const continuesRun =
        i < n && dimensions.slice(0, d + 1).every((dim) => rows[i][dim] === rows[i - 1][dim]);
      if (!continuesRun) {
        spans[d][runStart] = i - runStart;
        for (let k = runStart + 1; k < i; k++) spans[d][k] = 0;
        runStart = i;
      }
    }
  }

  return spans;
}

export function useGroupedQuery(
  datasetId: string | number | null,
  columns: string[],
  dimensions: string[],
  totalColumns: string[],
  filters: StructuredFilter[]
) {
  const [rows, setRows] = useState<GroupedRow[]>([]);
  const [rowSpans, setRowSpans] = useState<number[][]>([]);
  const [grandTotal, setGrandTotal] = useState<Record<string, number>>({});
  const [total, setTotal] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!datasetId || !columns.length) {
      setRows([]);
      setRowSpans([]);
      setGrandTotal({});
      setTotal(null);
      return;
    }

    const timer = setTimeout(async () => {
      setLoading(true);
      setError(null);

      try {
        const resp = await apiFetch(API.superset.datasetQuery(datasetId), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            columns,
            filters: filters.map((f) => ({ col: f.field, op: f.operator, val: f.value })),
            row_limit: PREVIEW_ROW_LIMIT,
            row_offset: 0,
          }),
        });

        if (!resp.ok) {
          const text = await resp.text();
          throw new Error(text || "Unable to load preview data.");
        }

        const data = await resp.json();
        const fetchedRows: GroupedRow[] = Array.isArray(data.rows) ? data.rows : [];

        const sorted = dimensions.length
          ? [...fetchedRows].sort((a, b) => {
              for (const dim of dimensions) {
                const cmp = compareValues(a[dim], b[dim]);
                if (cmp !== 0) return cmp;
              }
              return 0;
            })
          : fetchedRows;

        const totals: Record<string, number> = {};
        for (const col of totalColumns) {
          totals[col] = sorted.reduce((sum, row) => {
            const value = Number(row[col]);
            return sum + (Number.isFinite(value) ? value : 0);
          }, 0);
        }

        setRows(sorted);
        setRowSpans(computeRowSpans(sorted, dimensions));
        setGrandTotal(totals);
        setTotal(typeof data.total === "number" ? data.total : sorted.length);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Unable to load preview data.");
        setRows([]);
        setRowSpans([]);
        setGrandTotal({});
      } finally {
        setLoading(false);
      }
    }, PREVIEW_DEBOUNCE_MS);

    return () => clearTimeout(timer);
  }, [datasetId, columns, dimensions, totalColumns, filters]);

  return { rows, rowSpans, grandTotal, total, loading, error };
}
