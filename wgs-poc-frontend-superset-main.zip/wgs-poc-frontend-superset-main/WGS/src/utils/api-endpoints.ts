export const BASE_URL: string =
  (import.meta.env.VITE_API_BASE_URL as string | undefined) || "http://localhost:8000";

export const API = {
  auth: {
    login:    `${BASE_URL}/auth/login`,
    activate: `${BASE_URL}/auth/activate`,
  },
  users: {
    create: `${BASE_URL}/users/`,
    me:     `${BASE_URL}/users/me`,
    delete: (userId: string | number) => `${BASE_URL}/users/${userId}`,
  },
  roles: {
    list: `${BASE_URL}/roles/`,
    detail: (roleId: string | number) => `${BASE_URL}/roles/${roleId}`,
    permissions: (roleId: string | number) => `${BASE_URL}/roles/${roleId}/permissions`,
  },
  superset: {
    embed:    `${BASE_URL}/api/superset/embed`,
    allDashboards: `${BASE_URL}/api/superset/dashboards`,
    datasets: `${BASE_URL}/api/superset/datasets`,
    datasetColumns: (datasetId: string | number) =>
      `${BASE_URL}/api/superset/datasets/${datasetId}/columns`,
    columnData: (datasetId: string | number, column: string) =>
      `${BASE_URL}/api/superset/datasets/${datasetId}/columns/${column}/data`,
    columnBatchData: (datasetId: string | number) =>
      `${BASE_URL}/api/superset/datasets/${datasetId}/columns/batch-data`,
    datasetQuery: (datasetId: string | number) =>
      `${BASE_URL}/api/superset/datasets/${datasetId}/query`,
    metricsQuery: (datasetId: string | number) =>
      `${BASE_URL}/api/superset/datasets/${datasetId}/metrics-query`,
    dashboardData: (uuid: string) =>
      `${BASE_URL}/api/superset/dashboard/${uuid}/data`,
    dashboardExportStart:    (uuid: string, format: string) =>
      `${BASE_URL}/api/superset/dashboard/${uuid}/export/${format}/async`,
    dashboardExportStatus:   (jobId: string) =>
      `${BASE_URL}/api/superset/dashboard/export/jobs/${jobId}/status`,
    dashboardExportDownload: (jobId: string) =>
      `${BASE_URL}/api/superset/dashboard/export/jobs/${jobId}/download`,
  },
  templates: {
    list:       `${BASE_URL}/api/templates/`,
    create:     `${BASE_URL}/api/templates/`,
    uploadLogo: `${BASE_URL}/api/templates/upload-logo`,
    detail:     (id: string | number) => `${BASE_URL}/api/templates/${id}`,
    export:     (id: string | number, format: string) =>
      `${BASE_URL}/api/templates/${id}/export/${format}`,
    exportStart:    (id: string | number, format: string) =>
      `${BASE_URL}/api/templates/${id}/export/${format}/async`,
    exportStatus:   (jobId: string) =>
      `${BASE_URL}/api/templates/export/jobs/${jobId}/status`,
    exportDownload: (jobId: string) =>
      `${BASE_URL}/api/templates/export/jobs/${jobId}/download`,
  },
  chat: {
    ask: `${BASE_URL}/api/chat/`,
    agents: `${BASE_URL}/api/chat/agents`,
  },
  pageChat: {
    ask: `${BASE_URL}/api/page-chat/`,
  },
  scheduledReports: {
    list:   `${BASE_URL}/api/scheduled-reports/`,
    create: `${BASE_URL}/api/scheduled-reports/`,
    detail: (id: string | number) => `${BASE_URL}/api/scheduled-reports/${id}`,
    sendNow: (id: string | number) => `${BASE_URL}/api/scheduled-reports/${id}/send-now`,
  },
  restEndpoints: {
    list:                `${BASE_URL}/api/endpoint-registrations/`,
    create:              `${BASE_URL}/api/endpoint-registrations/`,
    detail:              (id: string | number) => `${BASE_URL}/api/endpoint-registrations/${id}`,
    update:              (id: string | number) => `${BASE_URL}/api/endpoint-registrations/${id}`,
    delete:              (id: string | number) => `${BASE_URL}/api/endpoint-registrations/${id}`,
    setEnabled:          (id: string | number) => `${BASE_URL}/api/endpoint-registrations/${id}/status`,
    testConnectionDraft: `${BASE_URL}/api/endpoint-registrations/test-connection`,
    testConnectionSaved: (id: string | number) => `${BASE_URL}/api/endpoint-registrations/${id}/test-connection`,
  },
} as const;
