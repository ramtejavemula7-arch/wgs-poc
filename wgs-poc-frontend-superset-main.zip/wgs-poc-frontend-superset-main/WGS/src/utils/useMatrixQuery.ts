import { useEffect, useState } from "react";
import { apiFetch } from "./api";
import { API } from "./api-endpoints";
import type { MetricsReportConfig } from "./metricsPresets";
import {
  assembleMatrixTree,
  buildRowLevels,
  extractColumnValues,
  levelRequestDimensions,
  pivotLevelRows,
  type MatrixNode,
  type PivotEntry,
} from "./metricsMatrix";

const DEBOUNCE_MS = 400;
const LEVEL_ROW_LIMIT = 5000;

type MatrixResult = {
  roots: MatrixNode[];
  grandTotal: PivotEntry | null;
  columnValues: string[];
  loading: boolean;
  error: string | null;
  warning: string | null;
};

/**
 * Builds a full Matrix (rows hierarchy + optional column pivot + subtotals at every level) using only
 * the existing POST /metrics-query endpoint. One request per row-depth level (deepest first, down to
 * the grand total) — each level asks the backend to aggregate that exact grouping, so SUM/AVG/MIN/MAX
 * subtotals are always correct, never re-derived by summing child subtotals client-side.
 */
export function useMatrixQuery(datasetId: string | number | null, config: MetricsReportConfig): MatrixResult {
  const [roots, setRoots] = useState<MatrixNode[]>([]);
  const [grandTotal, setGrandTotal] = useState<PivotEntry | null>(null);
  const [columnValues, setColumnValues] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [warning, setWarning] = useState<string | null>(null);

  useEffect(() => {
    if (!datasetId || !config.metrics.length || !config.dimensions.length) {
      setRoots([]);
      setGrandTotal(null);
      setColumnValues([]);
      setError(null);
      setWarning(null);
      return;
    }

    const timer = setTimeout(async () => {
      setLoading(true);
      setError(null);
      setWarning(null);

      try {
        const validSortField =
          config.sortField &&
          (config.dimensions.includes(config.sortField) || config.metrics.some((m) => m.label === config.sortField))
            ? config.sortField
            : null;

        const backendFilters = config.filters.map((f) => ({ col: f.field, op: f.operator, val: f.value }));
        const metricsPayload = config.metrics.map((m) => ({ field: m.field, aggregation: m.aggregation, label: m.label }));

        const fetchLevel = async (levelRowFields: string[]) => {
          const dims = levelRequestDimensions(levelRowFields, config.columnField);
          const resp = await apiFetch(API.superset.metricsQuery(datasetId), {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              dimensions: dims,
              metrics: metricsPayload,
              sort: validSortField ? { field: validSortField, direction: config.sortDirection } : null,
              filters: backendFilters,
              row_limit: LEVEL_ROW_LIMIT,
              row_offset: 0,
            }),
          });

          if (!resp.ok) {
            const text = await resp.text();
            throw new Error(text || "Unable to load the matrix preview.");
          }

          const data = await resp.json();
          return Array.isArray(data.rows) ? (data.rows as Record<string, unknown>[]) : [];
        };

        const levels = buildRowLevels(config.dimensions); // [full-depth, ..., []]
        const levelRowsByDepth = await Promise.all(levels.map((levelFields) => fetchLevel(levelFields)));
        // levels[0] is full depth (index = config.dimensions.length); reverse to index by depth (0..N)
        const rowsByDepth = [...levelRowsByDepth].reverse();

        const leafRows = rowsByDepth[config.dimensions.length];
        const resolvedColumnValues = config.columnField
          ? extractColumnValues(leafRows, config.columnField, config.columnSortDirection)
          : [];

        // Each level query is capped at LEVEL_ROW_LIMIT groups. With many Row levels (especially
        // near-unique fields like an ID or a name), the leaf-level group-by can explode past that cap —
        // silently producing an incomplete matrix (and, if the truncated sample happens to miss values,
        // a Column pivot with too few or zero columns). Surface it instead of failing quietly.
        if (leafRows.length >= LEVEL_ROW_LIMIT) {
          setWarning(
            `The most detailed Row level returned ${LEVEL_ROW_LIMIT.toLocaleString()}+ groups and was truncated — ` +
              "this matrix is incomplete. Try using fewer Row levels or avoid near-unique fields (like an ID or name) as a Row."
          );
        } else if (config.columnField && leafRows.length > 0 && resolvedColumnValues.length === 0) {
          setWarning(
            `No values were found for the Column field among the current Rows/Filters — the pivot has no columns to show.`
          );
        }

        const levelMaps = rowsByDepth.map((rows, depth) =>
          pivotLevelRows(rows, config.dimensions.slice(0, depth), config.columnField, config.metrics)
        );

        const tree = assembleMatrixTree(config.dimensions, levelMaps, validSortField, config.sortDirection);
        const grandTotalEntry = levelMaps[0].get("") ?? null;

        setRoots(tree);
        setGrandTotal(grandTotalEntry);
        setColumnValues(resolvedColumnValues);
      } catch (err) {
        setRoots([]);
        setGrandTotal(null);
        setColumnValues([]);
        setError(err instanceof Error ? err.message : "Unable to load the matrix preview.");
      } finally {
        setLoading(false);
      }
    }, DEBOUNCE_MS);

    return () => clearTimeout(timer);
  }, [datasetId, config]);

  return { roots, grandTotal, columnValues, loading, error, warning };
}
