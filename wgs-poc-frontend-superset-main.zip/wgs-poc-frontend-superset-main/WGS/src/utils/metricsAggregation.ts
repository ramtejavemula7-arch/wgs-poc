import { normalizeFieldName } from "./metricsFieldClassification";
import type { CurrencyCode } from "./currencyFormat";

export type AggregationFn = "SUM" | "AVG" | "MIN" | "MAX" | "COUNT";

/** Sentinel field for a synthetic COUNT(*) metric that isn't backed by a real column. */
export const ORDER_COUNT_FIELD = "__order_count__";

export type MetricSelection = {
  field: string; // real column_name, or ORDER_COUNT_FIELD
  label: string; // also the key the backend uses for this metric's value in each result row
  aggregation: AggregationFn;
  format?: CurrencyCode; // currency display format for this measure's values, if any
};

export const AGGREGATION_LABELS: Record<AggregationFn, string> = {
  SUM: "Sum",
  AVG: "Average",
  MIN: "Minimum",
  MAX: "Maximum",
  COUNT: "Count",
};

const METRIC_AGGREGATION_OPTIONS: Record<string, AggregationFn[]> = {
  sales: ["SUM", "AVG", "MIN", "MAX"],
  profit: ["SUM", "AVG", "MAX"],
  quantity: ["SUM", "COUNT"],
  discount: ["AVG", "MAX"],
};

const DEFAULT_AGGREGATION_OPTIONS: AggregationFn[] = ["SUM", "AVG", "MIN", "MAX"];

export function getAggregationOptions(columnName: string): AggregationFn[] {
  if (columnName === ORDER_COUNT_FIELD) return ["COUNT"];
  return METRIC_AGGREGATION_OPTIONS[normalizeFieldName(columnName)] ?? DEFAULT_AGGREGATION_OPTIONS;
}

/** Display text for a table header, e.g. "Sum of Sales". Distinct from `metric.label`, which is the
 *  literal key the backend uses in each result row (e.g. "Sales") and what `sort.field` must match. */
export function metricResultLabel(metric: MetricSelection): string {
  if (metric.field === ORDER_COUNT_FIELD) return metric.label;
  return `${AGGREGATION_LABELS[metric.aggregation]} of ${metric.label}`;
}
