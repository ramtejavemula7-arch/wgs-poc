import { flattenObject } from "./flattenResponse";

export type ClientFilterFieldType = "date" | "categorical" | "text";

export type ClientFilterFieldStat = {
  /** The type inferred from sample data — only used as a fallback when a condition somehow has
   *  no explicit Filter Type; every field's Filter Type is otherwise set in Response Mapping. */
  type: ClientFilterFieldType;
  /** Distinct values seen for this field in the sample, capped — always populated (not just for
   *  "categorical") so a user can manually force "Dropdown" on any field and still get real options. */
  options: string[];
};

const DATE_REGEX = /^\d{4}-\d{2}-\d{2}([T ]\d{2}:\d{2}(:\d{2})?(\.\d+)?(Z|[+-]\d{2}:?\d{2})?)?$/;
const CATEGORICAL_MAX_DISTINCT = 20;
const OPTIONS_CAP = 50;

function looksLikeDate(value: string): boolean {
  return DATE_REGEX.test(value.trim());
}

/**
 * Infers a UI-appropriate default filter control per discovered field from a sample of actual
 * response rows — there's no backend type metadata to rely on, only the values a test call
 * returned. This is only a default; ResponseMappingSection's Filter Type column lets the user override it per field.
 */
export function discoverFieldStats(
  rows: Record<string, unknown>[],
  fields: string[],
  sampleSize = 50
): Record<string, ClientFilterFieldStat> {
  const sample = rows.slice(0, sampleSize).map((row) => flattenObject(row));
  const stats: Record<string, ClientFilterFieldStat> = {};

  fields.forEach((field) => {
    const values: string[] = [];

    sample.forEach((flat) => {
      const raw = flat[field];
      if (raw === null || raw === undefined || raw === "") return;
      values.push(String(raw));
    });

    const distinct = Array.from(new Set(values)).sort().slice(0, OPTIONS_CAP);

    if (values.length > 0 && values.every(looksLikeDate)) {
      stats[field] = { type: "date", options: distinct };
      return;
    }

    const isSmallSet = distinct.length > 0 && distinct.length <= CATEGORICAL_MAX_DISTINCT;
    const hasRepetition = distinct.length < values.length;

    if (isSmallSet && (hasRepetition || values.length <= CATEGORICAL_MAX_DISTINCT)) {
      stats[field] = { type: "categorical", options: distinct };
      return;
    }

    stats[field] = { type: "text", options: distinct };
  });

  return stats;
}
