import { formatCellValue } from "./formatCellValue";

export type CsvColumn = { key: string; label: string };

function escapeCsvCell(raw: string): string {
  if (raw.includes(",") || raw.includes("\"") || raw.includes("\n") || raw.includes("\r")) {
    return `"${raw.replace(/"/g, "\"\"")}"`;
  }
  return raw;
}

export function buildCsv(columns: CsvColumn[], rows: Record<string, unknown>[]): string {
  const headerLine = columns.map((col) => escapeCsvCell(col.label)).join(",");
  const bodyLines = rows.map((row) =>
    columns.map((col) => escapeCsvCell(formatCellValue(row[col.key]))).join(",")
  );
  return [headerLine, ...bodyLines].join("\r\n");
}

/** Same Blob + temporary-anchor mechanics as TemplateView.tsx's downloadBlob, generalized to pre-built text. */
export function downloadCsv(filename: string, csvText: string): void {
  const blob = new Blob([csvText], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}
