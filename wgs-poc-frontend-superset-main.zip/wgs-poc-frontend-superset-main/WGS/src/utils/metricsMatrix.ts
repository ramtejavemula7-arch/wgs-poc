import type { MetricSelection } from "./metricsAggregation";

/** Sentinel bucket used when there is no column pivot field — every value lives under one column. */
export const NO_COLUMN_KEY = "__all__";

const PATH_SEP = "␟";

export type PivotEntry = {
  rowValues: Record<string, unknown>;
  values: Record<string, Record<string, number>>; // columnValue (or NO_COLUMN_KEY) -> metricLabel -> number
};

export type MatrixNode = {
  key: string;
  rowField: string;
  label: string;
  depth: number; // 1-indexed; matches position in the Rows list
  values: Record<string, Record<string, number>>;
  children: MatrixNode[];
  isLeaf: boolean;
};

/** Row-depth levels to query, deepest (full detail) first, down to 0 (grand total). */
export function buildRowLevels(rowFields: string[]): string[][] {
  const levels: string[][] = [];
  for (let depth = rowFields.length; depth >= 0; depth--) {
    levels.push(rowFields.slice(0, depth));
  }
  return levels;
}

export function levelRequestDimensions(levelRowFields: string[], columnField: string | null): string[] {
  return columnField ? [...levelRowFields, columnField] : levelRowFields;
}

function pathKey(rowFields: string[], row: Record<string, unknown>): string {
  return rowFields.map((f) => String(row[f] ?? "")).join(PATH_SEP);
}

// Month/quarter have a small, known domain — always show all 12/4, regardless of what the
// (possibly row_limit-truncated) leaf sample happens to contain. Year has no fixed domain and
// stays data-derived.
const FIXED_COLUMN_DOMAINS: Record<string, string[]> = {
  month: Array.from({ length: 12 }, (_, i) => String(i + 1)),
  quarter: ["1", "2", "3", "4"],
};

export function extractColumnValues(
  leafRows: Record<string, unknown>[],
  columnField: string,
  direction: "asc" | "desc"
): string[] {
  const extractMatch = /__(month|quarter)$/.exec(columnField);
  const fixedDomain = extractMatch ? FIXED_COLUMN_DOMAINS[extractMatch[1]] : undefined;

  let sorted: string[];
  if (fixedDomain) {
    sorted = fixedDomain;
  } else {
    const set = new Set<string>();
    leafRows.forEach((row) => {
      const value = row[columnField];
      if (value !== null && value !== undefined) set.add(String(value));
    });
    sorted = Array.from(set).sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
  }

  return direction === "desc" ? [...sorted].reverse() : sorted;
}

/** Groups one level's flat query result by its row-path, bucketing metric values by pivoted column. */
export function pivotLevelRows(
  flatRows: Record<string, unknown>[],
  levelRowFields: string[],
  columnField: string | null,
  metrics: MetricSelection[]
): Map<string, PivotEntry> {
  const map = new Map<string, PivotEntry>();

  flatRows.forEach((row) => {
    const key = pathKey(levelRowFields, row);
    if (!map.has(key)) {
      const rowValues: Record<string, unknown> = {};
      levelRowFields.forEach((f) => {
        rowValues[f] = row[f];
      });
      map.set(key, { rowValues, values: {} });
    }

    const entry = map.get(key)!;
    const colKey = columnField ? String(row[columnField] ?? "") : NO_COLUMN_KEY;
    const cellValues: Record<string, number> = {};
    metrics.forEach((m) => {
      cellValues[m.label] = Number(row[m.label]) || 0;
    });
    entry.values[colKey] = cellValues;
  });

  return map;
}

/** Sum of a metric across every pivoted column for one node/entry — used for sorting and row totals. */
export function sumAcrossColumns(values: Record<string, Record<string, number>>, metricLabel: string): number {
  return Object.values(values).reduce((sum, cell) => sum + (cell[metricLabel] ?? 0), 0);
}

function compareEntries(
  aLabel: string,
  aValues: Record<string, Record<string, number>>,
  bLabel: string,
  bValues: Record<string, Record<string, number>>,
  sortField: string | null,
  sortDirection: "asc" | "desc",
  rowField: string
): number {
  if (!sortField) return 0;
  let result: number;
  if (sortField === rowField) {
    result = aLabel.localeCompare(bLabel, undefined, { numeric: true });
  } else {
    result = sumAcrossColumns(aValues, sortField) - sumAcrossColumns(bValues, sortField);
  }
  return sortDirection === "desc" ? -result : result;
}

/**
 * Stitches per-level pivot maps (index 0 = grand total with rowFields=[], index N = full-depth leaf)
 * into a sorted row tree. Each depth's entries are matched to their parent by dropping the last
 * path segment — valid because level d+1's dimensions are always level d's dimensions plus one more.
 */
export function assembleMatrixTree(
  rowFields: string[],
  levelMaps: Map<string, PivotEntry>[],
  sortField: string | null,
  sortDirection: "asc" | "desc"
): MatrixNode[] {
  const nodesByDepth: Map<string, MatrixNode>[] = rowFields.map(() => new Map());

  for (let depth = 1; depth <= rowFields.length; depth++) {
    const map = levelMaps[depth];
    const rowField = rowFields[depth - 1];
    for (const [key, entry] of map) {
      const label = String(entry.rowValues[rowField] ?? "");
      nodesByDepth[depth - 1].set(key, {
        key,
        rowField,
        label,
        depth,
        values: entry.values,
        children: [],
        isLeaf: depth === rowFields.length,
      });
    }
  }

  for (let depth = rowFields.length; depth >= 2; depth--) {
    const parentMap = nodesByDepth[depth - 2];
    for (const node of nodesByDepth[depth - 1].values()) {
      const parentKey = node.key.split(PATH_SEP).slice(0, -1).join(PATH_SEP);
      parentMap.get(parentKey)?.children.push(node);
    }
  }

  const sortNodes = (nodes: MatrixNode[]) => {
    nodes.sort((a, b) => compareEntries(a.label, a.values, b.label, b.values, sortField, sortDirection, a.rowField));
    nodes.forEach((n) => sortNodes(n.children));
  };

  const roots = rowFields.length ? Array.from(nodesByDepth[0].values()) : [];
  sortNodes(roots);
  return roots;
}
