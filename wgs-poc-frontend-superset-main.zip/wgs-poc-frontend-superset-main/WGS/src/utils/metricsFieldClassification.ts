export type FieldRole = "dimension" | "metric";

// Superstore-specific classification. Names are matched after normalization, so
// "Sub-Category", "sub_category", and "Sub Category" all resolve the same way.
const DIMENSION_FIELD_NAMES = [
  "order_date",
  "ship_date",
  "ship_mode",
  "customer_name",
  "segment",
  "country",
  "city",
  "state",
  "region",
  "category",
  "sub_category",
  "product_name",
];

const METRIC_FIELD_NAMES = ["sales", "profit", "quantity", "discount"];

export function normalizeFieldName(name: string): string {
  return name
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

/** Fallback for any column outside the known Superstore field lists — every column must land somewhere. */
function inferRoleFromType(rawType?: string): FieldRole {
  const type = (rawType || "").toUpperCase();
  if (/^(INT|BIGINT|SMALLINT|TINYINT|DECIMAL|NUMERIC|FLOAT|DOUBLE|REAL)/.test(type)) return "metric";
  return "dimension"; // dates, text, ids, booleans — all still useful to group by
}

export function classifyField(columnName: string, rawType?: string): FieldRole {
  const normalized = normalizeFieldName(columnName);
  if (DIMENSION_FIELD_NAMES.includes(normalized)) return "dimension";
  if (METRIC_FIELD_NAMES.includes(normalized)) return "metric";
  return inferRoleFromType(rawType);
}

export function isDimensionField(columnName: string, rawType?: string): boolean {
  return classifyField(columnName, rawType) === "dimension";
}

export function isMetricField(columnName: string, rawType?: string): boolean {
  return classifyField(columnName, rawType) === "metric";
}

export function isDateField(rawType?: string): boolean {
  return /^(DATE|DATETIME|TIMESTAMP|TIME)/.test((rawType || "").toUpperCase());
}

/** "order_date" -> "Order Date" — dataset columns are typically snake_case; labels should read naturally. */
export function prettifyFieldLabel(columnName: string): string {
  return columnName
    .replace(/[_-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

const DATE_EXTRACT_LABELS: Record<string, string> = { year: "Year", quarter: "Quarter", month: "Month" };

/**
 * Labels a dimension/column-field key, whether it's a plain column name or a date-part
 * extraction ("order_date__month") — the suffix alone is enough to tell which, no column
 * type lookup needed.
 */
export function dimensionFieldLabel(key: string): string {
  const match = /^(.+)__(year|quarter|month)$/.exec(key);
  if (!match) return prettifyFieldLabel(key);
  const [, base, part] = match;
  return `${prettifyFieldLabel(base)} (${DATE_EXTRACT_LABELS[part]})`;
}

const MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/**
 * A pivoted column's raw value is whatever the SQL date extraction returned — "3" for March,
 * not "Mar". Formats it for display based on which extraction produced it; every other field
 * passes through untouched.
 */
export function formatDimensionValue(fieldKey: string | null, rawValue: string): string {
  if (fieldKey?.endsWith("__month")) {
    const n = Number(rawValue);
    if (Number.isInteger(n) && n >= 1 && n <= 12) return MONTH_NAMES[n - 1];
  }
  if (fieldKey?.endsWith("__quarter")) {
    const n = Number(rawValue);
    if (Number.isInteger(n) && n >= 1 && n <= 4) return `Q${n}`;
  }
  return rawValue;
}
