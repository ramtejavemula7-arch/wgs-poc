import { Navigate, Route, Routes } from "react-router-dom";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import TransactionLookup from "./pages/TransactionLookup";
import AdminUserCreate from "./pages/AdminUserCreate";
import AdminRolesCreate from "./pages/AdminRolesCreate";
import ScheduledReports from "./pages/ScheduledReports";
import ChatAssistant from "./pages/ChatAssistant";
import CreatePassword from "./pages/CreatePassword";
import TemplateBuilder from "./pages/TemplateBuilder";
import TemplateList from "./pages/TemplateList";
import TemplateView from "./pages/TemplateView";
import RestEndpointList from "./pages/RestEndpointList";
import RestEndpointRegistration from "./pages/RestEndpointRegistration";
import DataPreviewPage from "./pages/DataPreviewPage";
import ProtectedRoute from "./components/ProtectedRoute";
import "./App.css";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/login" replace />} />
      <Route path="/login" element={<Login />} />
      <Route path="/create-password" element={<CreatePassword />} />

      <Route element={<ProtectedRoute />}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/transactions" element={<TransactionLookup />} />
        <Route path="/templates" element={<TemplateList />} />
        <Route path="/templates/builder" element={<TemplateBuilder />} />
        <Route path="/templates/:id" element={<TemplateView />} />
        <Route path="/admin/users/new" element={<AdminUserCreate />} />
        <Route path="/admin/roles" element={<AdminRolesCreate />} />
        <Route path="/templates/scheduled-reports" element={<ScheduledReports />} />
        <Route path="/chat-assistant" element={<ChatAssistant />} />
        <Route path="/api-endpoints" element={<RestEndpointList />} />
        <Route path="/api-endpoints/new" element={<RestEndpointRegistration />} />
        <Route path="/api-endpoints/:id/edit" element={<RestEndpointRegistration />} />
        <Route path="/api-endpoints/:id/preview" element={<DataPreviewPage />} />
      </Route>
    </Routes>
  );
}

export default App;
