import { Building2, Mail, Tag } from "lucide-react";

type Props = {
  reportTitle: string;
  templateName: string;
  logoUrl: string | null;
  showMetadata: boolean;
};

// Fixed brand metadata shown on transaction report previews — not per-template configurable.
const REPORT_METADATA = {
  confidentiality: "Confidential",
  company: "Worldline",
  contact: "reports@worldline.com",
};

export default function ReportPreviewHeader({ reportTitle, templateName, logoUrl, showMetadata }: Props) {
  return (
    <div>
      <div className="flex items-center gap-6 px-6 py-4">
        <div className="flex w-32 shrink-0 items-center justify-start">
          {logoUrl ? (
            <img src={logoUrl} alt="Template logo" className="h-20 w-32 object-contain object-left" />
          ) : (
            <span className="text-xs text-slate-400">No logo uploaded</span>
          )}
        </div>
        <div className="flex-1 text-center">
          <h2 className="text-lg font-bold uppercase tracking-wide text-[#00796B]">{reportTitle}</h2>
          {templateName ? <p className="mt-1 text-sm text-slate-500">{templateName}</p> : null}
        </div>
        <div className="w-32 shrink-0" aria-hidden="true" />
      </div>

      <div className="h-1 bg-[#00796B]" />

      {showMetadata ? (
        <div className="grid grid-cols-1 gap-4 bg-slate-50 px-6 py-4 sm:grid-cols-3">
          <div className="flex items-center gap-3">
            <Tag className="text-[#00796B]" size={18} />
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-wide text-[#00796B]">Confidentiality</p>
              <p className="text-sm font-semibold text-slate-900">{REPORT_METADATA.confidentiality}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Building2 className="text-[#00796B]" size={18} />
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-wide text-[#00796B]">Company</p>
              <p className="text-sm font-semibold text-slate-900">{REPORT_METADATA.company}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Mail className="text-[#00796B]" size={18} />
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-wide text-[#00796B]">Contact</p>
              <p className="text-sm font-semibold text-slate-900">{REPORT_METADATA.contact}</p>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
