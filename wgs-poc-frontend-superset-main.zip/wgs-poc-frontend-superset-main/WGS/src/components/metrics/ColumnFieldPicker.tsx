import type { FieldOption } from "./DimensionPicker";
import StyledSelect from "../StyledSelect";

type Props = {
  fields: FieldOption[];
  value: string | null;
  onChange: (field: string | null) => void;
  sortDirection: "asc" | "desc";
  onSortDirectionChange: (direction: "asc" | "desc") => void;
};

export default function ColumnFieldPicker({ fields, value, onChange, sortDirection, onSortDirectionChange }: Props) {
  return (
    <div className="flex flex-wrap items-center gap-3">
      <StyledSelect
        className="w-full max-w-xs"
        buttonClassName="h-10"
        value={value ?? ""}
        onChange={(next) => onChange(next || null)}
        options={[
          { value: "", label: "None — normal grouped table" },
          ...fields.map((field) => ({ value: field.columnName, label: field.label })),
        ]}
      />

      {value ? (
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold uppercase tracking-wide text-slate-500">Column order</span>
          <div className="flex gap-1 rounded-lg bg-slate-100 p-1">
            {(["asc", "desc"] as const).map((direction) => (
              <button
                key={direction}
                type="button"
                onClick={() => onSortDirectionChange(direction)}
                className={`rounded-md px-3 py-1.5 text-xs font-semibold uppercase transition ${
                  sortDirection === direction ? "bg-[#00796B] text-white" : "text-slate-600 hover:bg-white"
                }`}
              >
                {direction}
              </button>
            ))}
          </div>
        </div>
      ) : null}
    </div>
  );
}
