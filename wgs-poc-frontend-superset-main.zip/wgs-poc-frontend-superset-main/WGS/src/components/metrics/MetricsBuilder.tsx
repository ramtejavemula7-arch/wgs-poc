import { useMemo } from "react";
import type { SchemaColumn } from "../../utils/filterFieldConfig";
import { classifyField, isDateField, prettifyFieldLabel } from "../../utils/metricsFieldClassification";
import { ORDER_COUNT_FIELD, getAggregationOptions } from "../../utils/metricsAggregation";
import type { MatrixNode, PivotEntry } from "../../utils/metricsMatrix";
import type { MetricsReportConfig } from "../../utils/metricsPresets";
import AvailableFieldsPanel from "./AvailableFieldsPanel";
import DimensionPicker, { type FieldOption } from "./DimensionPicker";
import ColumnFieldPicker from "./ColumnFieldPicker";
import MetricPicker from "./MetricPicker";
import SortPanel from "./GroupBySortPanel";
import MatrixPreviewTable from "./MatrixPreviewTable";
import MetricsPresetBar from "./MetricsPresetBar";
import FilterBuilder from "../filters/FilterBuilder";

// A date-typed field can be pivoted on as-is, or extracted down to a coarser part. The backend
// expands "<column>__year" / "__quarter" / "__month" into the matching SQL date extraction.
const DATE_EXTRACT_SUFFIXES: { suffix: string; labelSuffix: string }[] = [
  { suffix: "", labelSuffix: "" },
  { suffix: "__year", labelSuffix: " (Year)" },
  { suffix: "__quarter", labelSuffix: " (Quarter)" },
  { suffix: "__month", labelSuffix: " (Month)" },
];

type Props = {
  datasetId: string | number | null;
  columns: SchemaColumn[];
  columnsLoading: boolean;
  value: MetricsReportConfig;
  onChange: (config: MetricsReportConfig) => void;
  matrixRoots: MatrixNode[];
  matrixGrandTotal: PivotEntry | null;
  matrixColumnValues: string[];
  matrixLoading: boolean;
  matrixError: string | null;
  matrixWarning?: string | null;
};

export default function MetricsBuilder({
  datasetId,
  columns,
  columnsLoading,
  value,
  onChange,
  matrixRoots,
  matrixGrandTotal,
  matrixColumnValues,
  matrixLoading,
  matrixError,
  matrixWarning,
}: Props) {
  const dimensionFields: FieldOption[] = useMemo(
    () =>
      columns
        .filter((c) => c.column_name && classifyField(c.column_name, c.type) === "dimension")
        .flatMap((c) => {
          const columnName = c.column_name!;
          const baseLabel = prettifyFieldLabel(columnName);
          if (!isDateField(c.type)) return [{ columnName, label: baseLabel }];
          return DATE_EXTRACT_SUFFIXES.map(({ suffix, labelSuffix }) => ({
            columnName: `${columnName}${suffix}`,
            label: `${baseLabel}${labelSuffix}`,
          }));
        }),
    [columns]
  );

  const realMetricFields: FieldOption[] = useMemo(
    () =>
      columns
        .filter((c) => c.column_name && classifyField(c.column_name, c.type) === "metric")
        .map((c) => ({ columnName: c.column_name!, label: prettifyFieldLabel(c.column_name!) })),
    [columns]
  );

  const metricFieldsWithOrderCount: FieldOption[] = useMemo(
    () => [...realMetricFields, { columnName: ORDER_COUNT_FIELD, label: "Order Count" }],
    [realMetricFields]
  );

  const dimensionLabels = useMemo(
    () => Object.fromEntries(dimensionFields.map((f) => [f.columnName, f.label])),
    [dimensionFields]
  );

  // A field already used as a Row can't also be the Column pivot, and vice versa.
  const columnFieldOptions = useMemo(
    () => dimensionFields.filter((f) => !value.dimensions.includes(f.columnName)),
    [dimensionFields, value.dimensions]
  );

  const columnFieldLabel = value.columnField ? dimensionLabels[value.columnField] ?? value.columnField : "";

  const addRow = (field: FieldOption) => {
    onChange({ ...value, dimensions: [...value.dimensions, field.columnName] });
  };

  const addValue = (field: FieldOption) => {
    const defaultAggregation = getAggregationOptions(field.columnName)[0];
    onChange({ ...value, metrics: [...value.metrics, { field: field.columnName, label: field.label, aggregation: defaultAggregation }] });
  };

  if (columnsLoading) {
    return (
      <div className="flex min-h-[240px] items-center justify-center rounded-3xl border border-slate-200 bg-slate-50 text-sm font-medium text-slate-500">
        Analyzing dataset fields...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <MetricsPresetBar availableFields={[...dimensionFields, ...realMetricFields]} onApply={onChange} />

      <div className="grid gap-6 lg:grid-cols-[260px_1fr]">
        <div>
          <p className="mb-2 text-sm font-semibold text-slate-700">Available fields</p>
          <AvailableFieldsPanel
            dimensionFields={dimensionFields}
            measureFields={metricFieldsWithOrderCount}
            selectedDimensions={value.dimensions}
            selectedMeasureFields={value.metrics.map((m) => m.field)}
            onAddRow={addRow}
            onAddValue={addValue}
          />
        </div>

        <div className="space-y-6">
          <div>
            <p className="mb-2 text-sm font-semibold text-slate-700">Rows</p>
            <DimensionPicker
              fields={dimensionFields}
              selected={value.dimensions}
              onChange={(dimensions) =>
                onChange({
                  ...value,
                  dimensions,
                  // Dropping a field from Rows should also clear it as the Column pivot if it was picked there.
                  columnField: value.columnField && dimensions.includes(value.columnField) ? null : value.columnField,
                })
              }
            />
          </div>

          <div>
            <p className="mb-2 text-sm font-semibold text-slate-700">Columns (optional)</p>
            <ColumnFieldPicker
              fields={columnFieldOptions}
              value={value.columnField}
              onChange={(columnField) => onChange({ ...value, columnField })}
              sortDirection={value.columnSortDirection}
              onSortDirectionChange={(columnSortDirection) => onChange({ ...value, columnSortDirection })}
            />
          </div>

          <div>
            <p className="mb-2 text-sm font-semibold text-slate-700">Values</p>
            <MetricPicker selected={value.metrics} onChange={(metrics) => onChange({ ...value, metrics })} />
          </div>
        </div>
      </div>

      <div>
        <p className="mb-2 text-sm font-semibold text-slate-700">Filters</p>
        <FilterBuilder
          datasetId={datasetId}
          columns={columns}
          columnsLoading={columnsLoading}
          filters={value.filters}
          onChange={(filters) => onChange({ ...value, filters })}
          showPreview={false}
        />
      </div>

      <div>
        <p className="mb-2 text-sm font-semibold text-slate-700">Sort</p>
        <SortPanel
          dimensions={value.dimensions}
          dimensionLabels={dimensionLabels}
          metrics={value.metrics}
          sortField={value.sortField}
          sortDirection={value.sortDirection}
          onSortFieldChange={(sortField) => onChange({ ...value, sortField })}
          onSortDirectionChange={(sortDirection) => onChange({ ...value, sortDirection })}
        />
      </div>

      <div>
        <p className="mb-2 text-sm font-semibold text-slate-700">Live preview</p>
        <MatrixPreviewTable
          rowFields={value.dimensions}
          rowFieldLabels={dimensionLabels}
          columnField={value.columnField}
          columnFieldLabel={columnFieldLabel}
          columnValues={matrixColumnValues}
          metrics={value.metrics}
          roots={matrixRoots}
          grandTotal={matrixGrandTotal}
          loading={matrixLoading}
          error={matrixError}
          warning={matrixWarning}
        />
      </div>
    </div>
  );
}
