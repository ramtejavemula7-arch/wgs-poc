import { ArrowDown, ArrowUp, X } from "lucide-react";

export type FieldOption = { columnName: string; label: string };

type Props = {
  fields: FieldOption[];
  selected: string[];
  onChange: (next: string[]) => void;
};

/** The "Rows" well — ordered, reorderable, removable. Fields are added via the Available Fields panel. */
export default function DimensionPicker({ fields, selected, onChange }: Props) {
  const labelFor = (columnName: string) => fields.find((f) => f.columnName === columnName)?.label ?? columnName;

  const remove = (columnName: string) => {
    onChange(selected.filter((v) => v !== columnName));
  };

  const move = (index: number, delta: number) => {
    const target = index + delta;
    if (target < 0 || target >= selected.length) return;
    const next = [...selected];
    [next[index], next[target]] = [next[target], next[index]];
    onChange(next);
  };

  if (!selected.length) {
    return (
      <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 px-4 py-6 text-center text-sm text-slate-400">
        Add dimensions from Available Fields to build the row hierarchy.
      </div>
    );
  }

  return (
    <ol className="space-y-2">
      {selected.map((columnName, index) => (
        <li
          key={columnName}
          className="flex items-center justify-between gap-2 rounded-xl border border-[#00796B] bg-[#00796B]/5 px-3 py-2"
        >
          <span className="text-sm text-slate-800">
            {index === 0 ? "Group by " : "Then by "}
            <span className="font-semibold">{labelFor(columnName)}</span>
          </span>
          <div className="flex items-center gap-1">
            <button
              type="button"
              disabled={index === 0}
              onClick={() => move(index, -1)}
              className="rounded-md p-1 text-slate-500 transition hover:bg-white disabled:cursor-not-allowed disabled:opacity-30"
            >
              <ArrowUp size={14} />
            </button>
            <button
              type="button"
              disabled={index === selected.length - 1}
              onClick={() => move(index, 1)}
              className="rounded-md p-1 text-slate-500 transition hover:bg-white disabled:cursor-not-allowed disabled:opacity-30"
            >
              <ArrowDown size={14} />
            </button>
            <button
              type="button"
              onClick={() => remove(columnName)}
              aria-label={`Remove ${labelFor(columnName)}`}
              className="rounded-full p-1.5 text-slate-500 transition hover:bg-white hover:text-red-600"
            >
              <X size={14} />
            </button>
          </div>
        </li>
      ))}
    </ol>
  );
}
