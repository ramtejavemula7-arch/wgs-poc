import { metricResultLabel, type MetricSelection } from "../../utils/metricsAggregation";
import StyledSelect from "../StyledSelect";

type Props = {
  dimensions: string[];
  dimensionLabels: Record<string, string>;
  metrics: MetricSelection[];
  sortField: string | null;
  sortDirection: "asc" | "desc";
  onSortFieldChange: (field: string | null) => void;
  onSortDirectionChange: (direction: "asc" | "desc") => void;
};

/** Sort by any Row field or Value. Row hierarchy ordering itself lives in the Rows well (DimensionPicker). */
export default function SortPanel({
  dimensions,
  dimensionLabels,
  metrics,
  sortField,
  sortDirection,
  onSortFieldChange,
  onSortDirectionChange,
}: Props) {
  return (
    <div className="flex flex-wrap gap-2">
      <StyledSelect
        className="max-w-sm flex-1"
        buttonClassName="h-10"
        value={sortField ?? ""}
        onChange={(next) => onSortFieldChange(next || null)}
        options={[
          { value: "", label: "No sorting" },
          ...dimensions.map((dim) => ({ value: dim, label: dimensionLabels[dim] ?? dim })),
          ...metrics.map((metric) => ({ value: metric.label, label: metricResultLabel(metric) })),
        ]}
      />
      <div className="flex gap-1 rounded-lg bg-slate-100 p-1">
        {(["asc", "desc"] as const).map((direction) => (
          <button
            key={direction}
            type="button"
            onClick={() => onSortDirectionChange(direction)}
            className={`rounded-md px-3 py-2 text-xs font-semibold uppercase transition ${
              sortDirection === direction ? "bg-[#00796B] text-white" : "text-slate-600 hover:bg-white"
            }`}
          >
            {direction}
          </button>
        ))}
      </div>
    </div>
  );
}
