import LogoSpinner from "../LogoSpinner";
import { metricResultLabel, type MetricSelection } from "../../utils/metricsAggregation";

type Props = {
  dimensions: string[];
  dimensionLabels: Record<string, string>;
  metrics: MetricSelection[];
  rows: Record<string, unknown>[];
  loading: boolean;
  error: string | null;
};

function formatCell(value: unknown): string {
  if (typeof value === "number") {
    return Number.isInteger(value) ? value.toLocaleString() : value.toFixed(2);
  }
  return value === null || value === undefined ? "-" : String(value);
}

export default function MetricsPreviewTable({ dimensions, dimensionLabels, metrics, rows, loading, error }: Props) {
  if (loading) {
    return (
      <div className="flex min-h-[160px] items-center justify-center rounded-2xl border border-slate-200 bg-slate-50 text-sm font-medium text-slate-500">
        <LogoSpinner className="mr-2 h-5 w-5" /> Building preview...
      </div>
    );
  }

  if (error) {
    return <div className="rounded-2xl bg-red-50 p-4 text-sm text-red-700">{error}</div>;
  }

  if (!dimensions.length || !metrics.length) {
    return (
      <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-4 py-10 text-center text-sm font-medium text-slate-500">
        Select at least one dimension and one metric to see a preview.
      </div>
    );
  }

  return (
    <div className="max-h-96 overflow-auto rounded-2xl border border-slate-200">
      <table className="min-w-full text-left text-sm">
        <thead className="sticky top-0 bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
          <tr>
            {dimensions.map((dim) => (
              <th key={dim} className="whitespace-nowrap px-4 py-3">
                {dimensionLabels[dim] ?? dim}
              </th>
            ))}
            {metrics.map((metric) => (
              <th key={metric.field} className="whitespace-nowrap px-4 py-3 text-right">
                {metricResultLabel(metric)}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 bg-white">
          {rows.length ? (
            rows.map((row, index) => (
              <tr key={index}>
                {dimensions.map((dim) => (
                  <td key={dim} className="whitespace-nowrap px-4 py-2 text-slate-700">
                    {formatCell(row[dim])}
                  </td>
                ))}
                {metrics.map((metric) => (
                  <td key={metric.field} className="whitespace-nowrap px-4 py-2 text-right text-slate-700">
                    {formatCell(row[metric.label])}
                  </td>
                ))}
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={dimensions.length + metrics.length} className="px-4 py-8 text-center text-slate-400">
                No rows match the current configuration.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
