import { useMemo } from "react";
import type { SchemaColumn } from "../../utils/filterFieldConfig";
import { classifyField, dimensionFieldLabel, isDateField, prettifyFieldLabel } from "../../utils/metricsFieldClassification";
import { getAggregationOptions } from "../../utils/metricsAggregation";
import type { MatrixNode, PivotEntry } from "../../utils/metricsMatrix";
import type { MetricsReportConfig } from "../../utils/metricsPresets";
import AvailableFieldsPanel from "./AvailableFieldsPanel";
import DimensionPicker, { type FieldOption } from "./DimensionPicker";
import MetricPicker from "./MetricPicker";
import HeatmapPreviewTable from "./HeatmapPreviewTable";
import FilterBuilder from "../filters/FilterBuilder";

type Props = {
  datasetId: string | number | null;
  columns: SchemaColumn[];
  columnsLoading: boolean;
  value: MetricsReportConfig;
  onChange: (config: MetricsReportConfig) => void;
  matrixRoots: MatrixNode[];
  matrixGrandTotal: PivotEntry | null;
  matrixColumnValues: string[];
  matrixLoading: boolean;
  matrixError: string | null;
  matrixWarning?: string | null;
};

// Heatmap reports have a fixed shape: Year is always the last/innermost Row level, Month is
// always pivoted into Columns. The user picks and orders everything above Year (e.g. Category,
// then Subcategory) — Year/Month themselves are derived from whichever date column exists.
export default function HeatmapBuilder({
  datasetId,
  columns,
  columnsLoading,
  value,
  onChange,
  matrixRoots,
  matrixGrandTotal,
  matrixColumnValues,
  matrixLoading,
  matrixError,
  matrixWarning,
}: Props) {
  const dateColumn = useMemo(
    () => columns.find((c) => c.column_name && isDateField(c.type)) ?? null,
    [columns]
  );

  const yearField = dateColumn ? `${dateColumn.column_name}__year` : null;
  const monthField = dateColumn ? `${dateColumn.column_name}__month` : null;

  // The user only ever manages the levels above Year — Year itself is appended automatically
  // below, so it never shows up as a removable/reorderable entry in `userDimensions`.
  const userDimensions = useMemo(
    () => (yearField ? value.dimensions.filter((d) => d !== yearField) : value.dimensions),
    [value.dimensions, yearField]
  );

  const dimensionFields: FieldOption[] = useMemo(
    () =>
      columns
        .filter((c) => c.column_name && classifyField(c.column_name, c.type) === "dimension" && !isDateField(c.type))
        .map((c) => ({ columnName: c.column_name!, label: prettifyFieldLabel(c.column_name!) })),
    [columns]
  );

  const measureFields: FieldOption[] = useMemo(
    () =>
      columns
        .filter((c) => c.column_name && classifyField(c.column_name, c.type) === "metric")
        .map((c) => ({ columnName: c.column_name!, label: prettifyFieldLabel(c.column_name!) })),
    [columns]
  );

  const dimensionLabels = useMemo(
    () => Object.fromEntries(value.dimensions.map((key) => [key, dimensionFieldLabel(key)])),
    [value.dimensions]
  );

  const columnFieldLabel = value.columnField ? dimensionFieldLabel(value.columnField) : "";

  const applyUserDimensions = (nextUserDimensions: string[]) => {
    onChange({
      ...value,
      dimensions: yearField ? [...nextUserDimensions, yearField] : nextUserDimensions,
      columnField: monthField,
      columnSortDirection: "asc",
    });
  };

  const addRow = (field: FieldOption) => {
    applyUserDimensions([...userDimensions, field.columnName]);
  };

  const addMeasure = (field: FieldOption) => {
    if (value.metrics.some((m) => m.field === field.columnName)) return;
    const defaultAggregation = getAggregationOptions(field.columnName)[0];
    onChange({
      ...value,
      metrics: [...value.metrics, { field: field.columnName, label: field.label, aggregation: defaultAggregation }],
    });
  };

  if (columnsLoading) {
    return (
      <div className="flex min-h-[240px] items-center justify-center rounded-3xl border border-slate-200 bg-slate-50 text-sm font-medium text-slate-500">
        Analyzing dataset fields...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {!dateColumn ? (
        <div className="rounded-2xl bg-amber-50 p-4 text-sm text-amber-800">
          This dataset has no date column. Heatmap reports need one to build the Year/Month columns.
        </div>
      ) : null}

      <div className="grid gap-6 lg:grid-cols-[260px_1fr]">
        <div>
          <p className="mb-2 text-sm font-semibold text-slate-700">Available fields</p>
          <AvailableFieldsPanel
            dimensionFields={dimensionFields}
            measureFields={measureFields}
            selectedDimensions={userDimensions}
            selectedMeasureFields={value.metrics.map((m) => m.field)}
            onAddRow={addRow}
            onAddValue={addMeasure}
          />
        </div>

        <div className="space-y-6">
          <div>
            <p className="mb-2 text-sm font-semibold text-slate-700">Rows</p>
            <p className="mb-2 text-xs text-slate-500">
              Add and order fields above (e.g. Category, then Subcategory). {dateColumn ? "Year" : "A date field"}{" "}
              is always appended as the last level.
            </p>
            <DimensionPicker fields={dimensionFields} selected={userDimensions} onChange={applyUserDimensions} />
            {dateColumn ? (
              <div className="mt-2 flex items-center justify-between gap-2 rounded-xl border border-dashed border-slate-300 bg-slate-50 px-3 py-2 text-sm text-slate-600">
                <span>
                  Then by <span className="font-semibold">{prettifyFieldLabel(dateColumn.column_name!)} (Year)</span>
                </span>
                <span className="text-xs font-semibold uppercase tracking-wide text-slate-400">Fixed</span>
              </div>
            ) : null}
          </div>

          <div>
            <p className="mb-2 text-sm font-semibold text-slate-700">Columns</p>
            <div className="flex items-center justify-between gap-2 rounded-xl border border-dashed border-slate-300 bg-slate-50 px-3 py-2 text-sm text-slate-600">
              <span>{dateColumn ? columnFieldLabel : "No date column available"}</span>
              <span className="text-xs font-semibold uppercase tracking-wide text-slate-400">Fixed</span>
            </div>
          </div>

          <div>
            <p className="mb-2 text-sm font-semibold text-slate-700">Values</p>
            <MetricPicker selected={value.metrics} onChange={(metrics) => onChange({ ...value, metrics })} />
          </div>
        </div>
      </div>

      <div>
        <p className="mb-2 text-sm font-semibold text-slate-700">Filters</p>
        <FilterBuilder
          datasetId={datasetId}
          columns={columns}
          columnsLoading={columnsLoading}
          filters={value.filters}
          onChange={(filters) => onChange({ ...value, filters })}
          showPreview={false}
        />
      </div>

      <div>
        <p className="mb-2 text-sm font-semibold text-slate-700">Live preview</p>
        <HeatmapPreviewTable
          rowFields={value.dimensions}
          rowFieldLabels={dimensionLabels}
          columnField={value.columnField}
          columnFieldLabel={columnFieldLabel}
          columnValues={matrixColumnValues}
          metrics={value.metrics}
          roots={matrixRoots}
          grandTotal={matrixGrandTotal}
          loading={matrixLoading}
          error={matrixError}
          warning={matrixWarning}
        />
      </div>
    </div>
  );
}
