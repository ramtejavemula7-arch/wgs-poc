import { type ReactNode, useState } from "react";
import LogoSpinner from "../LogoSpinner";
import { NO_COLUMN_KEY, sumAcrossColumns, type MatrixNode, type PivotEntry } from "../../utils/metricsMatrix";
import { metricResultLabel, type MetricSelection } from "../../utils/metricsAggregation";
import { formatDimensionValue } from "../../utils/metricsFieldClassification";
import { formatCurrencyValue, type CurrencyCode } from "../../utils/currencyFormat";

type Props = {
  rowFields: string[];
  rowFieldLabels: Record<string, string>;
  columnField: string | null;
  columnFieldLabel: string;
  columnValues: string[];
  metrics: MetricSelection[];
  roots: MatrixNode[];
  grandTotal: PivotEntry | null;
  loading: boolean;
  error: string | null;
  warning?: string | null;
};

type ColumnGroup = { id: string; isTotal: boolean };

function formatCell(value: unknown, currency?: CurrencyCode): string {
  if (currency) {
    const formatted = formatCurrencyValue(value, currency);
    if (formatted !== null) return formatted;
  }
  if (typeof value === "number") {
    return Number.isInteger(value) ? value.toLocaleString() : value.toFixed(2);
  }
  return value === null || value === undefined ? "-" : String(value);
}

/**
 * Same underlying tree (subtotals per level, expand/collapse) as MatrixPreviewTable, but laid out
 * like a classic Excel PivotTable's Tabular Form: each Row field gets its own column, and a node's
 * label only appears in its own depth's column — not combined into one indented column.
 */
export default function HeatmapPreviewTable({
  rowFields,
  rowFieldLabels,
  columnField,
  columnFieldLabel,
  columnValues,
  metrics,
  roots,
  grandTotal,
  loading,
  error,
  warning,
}: Props) {
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());

  const toggle = (key: string) => {
    setCollapsed((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  if (loading) {
    return (
      <div className="flex min-h-[200px] items-center justify-center rounded-2xl border border-slate-200 bg-slate-50 text-sm font-medium text-slate-500">
        <LogoSpinner className="mr-2 h-5 w-5" /> Building heatmap...
      </div>
    );
  }

  if (error) {
    return <div className="rounded-2xl bg-red-50 p-4 text-sm text-red-700">{error}</div>;
  }

  if (!rowFields.length || !metrics.length) {
    return (
      <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-4 py-10 text-center text-sm font-medium text-slate-500">
        Select at least one Row and one Value to see the heatmap.
      </div>
    );
  }

  const columnGroups: ColumnGroup[] = columnField
    ? [...columnValues.map((cv) => ({ id: cv, isTotal: false })), { id: "__total__", isTotal: true }]
    : [];
  const totalHeaderLabel = "Total";
  const headerRowSpan = !columnField ? 1 : metrics.length > 1 ? 3 : 2;

  function groupValue(values: Record<string, Record<string, number>>, group: ColumnGroup, metricLabel: string) {
    return group.isTotal ? sumAcrossColumns(values, metricLabel) : values[group.id]?.[metricLabel];
  }

  function renderValueCells(values: Record<string, Record<string, number>>, cellClassName: string): ReactNode[] {
    if (!columnField) {
      return metrics.map((metric) => (
        <td key={metric.field} className={`whitespace-nowrap px-4 py-2 text-right ${cellClassName}`}>
          {formatCell(values[NO_COLUMN_KEY]?.[metric.label], metric.format)}
        </td>
      ));
    }
    return columnGroups.flatMap((group) => {
      if (metrics.length > 1) {
        return metrics.map((metric) => (
          <td key={`${group.id}:${metric.field}`} className={`whitespace-nowrap px-4 py-2 text-right ${cellClassName}`}>
            {formatCell(groupValue(values, group, metric.label), metric.format)}
          </td>
        ));
      }
      return [
        <td key={group.id} className={`whitespace-nowrap px-4 py-2 text-right ${cellClassName}`}>
          {formatCell(groupValue(values, group, metrics[0].label), metrics[0].format)}
        </td>,
      ];
    });
  }

  // One <td> per row field — a node's label only shows up in its own depth's column, every
  // other row-field column stays blank for that row (Excel's "don't repeat item labels" style).
  function renderRowLabelCells(node: MatrixNode, hasChildren: boolean, isExpanded: boolean): ReactNode[] {
    return rowFields.map((_, index) => {
      const isOwnColumn = index === node.depth - 1;
      const sharedClassName = hasChildren ? "bg-slate-50" : "";
      if (!isOwnColumn) {
        return <td key={index} className={`whitespace-nowrap px-4 py-2 ${sharedClassName}`} />;
      }
      return (
        <td
          key={index}
          className={`whitespace-nowrap px-4 py-2 ${hasChildren ? `${sharedClassName} font-semibold text-slate-800` : "text-slate-700"}`}
        >
          <span className="mr-2 inline-flex w-4 justify-center text-slate-500">
            {hasChildren ? (
              <button type="button" onClick={() => toggle(node.key)} className="hover:text-[#00796B]">
                {isExpanded ? "▾" : "▸"}
              </button>
            ) : null}
          </span>
          {node.label}
        </td>
      );
    });
  }

  function buildNodeRows(node: MatrixNode): ReactNode[] {
    const hasChildren = node.children.length > 0;
    const isExpanded = !collapsed.has(node.key);
    const cellClassName = hasChildren ? "font-semibold text-slate-800" : "text-slate-700";

    const row = (
      <tr key={node.key} className={hasChildren ? "bg-slate-50" : undefined}>
        {renderRowLabelCells(node, hasChildren, isExpanded)}
        {renderValueCells(node.values, cellClassName)}
      </tr>
    );

    if (!isExpanded) return [row];
    return [row, ...node.children.flatMap((child) => buildNodeRows(child))];
  }

  const metricsPerGroup = metrics.length > 1 ? metrics.length : 1;
  const valueColumnCount = columnField ? columnGroups.length * metricsPerGroup : metrics.length;
  const totalColumnCount = rowFields.length + valueColumnCount;

  return (
    <div className="space-y-3">
      {warning ? (
        <div className="rounded-lg bg-amber-50 px-3 py-2 text-xs font-medium text-amber-800">{warning}</div>
      ) : null}
      <div className="max-h-[32rem] overflow-auto rounded-2xl border border-slate-200">
        <table className="min-w-full text-left text-sm">
          <thead className="sticky top-0 bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
            {!columnField ? (
              <tr>
                {rowFields.map((f) => (
                  <th key={f} className="whitespace-nowrap px-4 py-3">
                    {rowFieldLabels[f] ?? f}
                  </th>
                ))}
                {metrics.map((metric) => (
                  <th key={metric.field} className="whitespace-nowrap px-4 py-3 text-right">
                    {metricResultLabel(metric)}
                  </th>
                ))}
              </tr>
            ) : metrics.length === 1 ? (
              <>
                <tr>
                  {rowFields.map((f) => (
                    <th
                      key={f}
                      rowSpan={headerRowSpan}
                      className="whitespace-nowrap px-4 py-3 align-bottom"
                    >
                      {rowFieldLabels[f] ?? f}
                    </th>
                  ))}
                  <th colSpan={columnGroups.length} className="px-4 py-2 text-center">
                    {columnFieldLabel}
                  </th>
                </tr>
                <tr>
                  {columnGroups.map((group) => (
                    <th key={group.id} className="whitespace-nowrap px-4 py-3 text-right">
                      {group.isTotal ? totalHeaderLabel : formatDimensionValue(columnField, group.id)}
                    </th>
                  ))}
                </tr>
              </>
            ) : (
              <>
                <tr>
                  {rowFields.map((f) => (
                    <th
                      key={f}
                      rowSpan={headerRowSpan}
                      className="whitespace-nowrap px-4 py-3 align-bottom"
                    >
                      {rowFieldLabels[f] ?? f}
                    </th>
                  ))}
                  <th colSpan={columnGroups.length * metrics.length} className="px-4 py-2 text-center">
                    {columnFieldLabel}
                  </th>
                </tr>
                <tr>
                  {columnGroups.map((group) => (
                    <th
                      key={group.id}
                      colSpan={metrics.length}
                      className="whitespace-nowrap px-4 py-2 text-center"
                    >
                      {group.isTotal ? totalHeaderLabel : formatDimensionValue(columnField, group.id)}
                    </th>
                  ))}
                </tr>
                <tr>
                  {columnGroups.flatMap((group) =>
                    metrics.map((metric) => (
                      <th
                        key={`${group.id}:${metric.field}`}
                        className="whitespace-nowrap px-4 py-3 text-right"
                      >
                        {metricResultLabel(metric)}
                      </th>
                    ))
                  )}
                </tr>
              </>
            )}
          </thead>
          <tbody className="divide-y divide-slate-100 bg-white">
            {roots.length ? (
              roots.flatMap((root) => buildNodeRows(root))
            ) : (
              <tr>
                <td colSpan={totalColumnCount} className="px-4 py-8 text-center text-slate-400">
                  No rows match the current configuration.
                </td>
              </tr>
            )}

            {grandTotal ? (
              <tr className="border-t-2 border-[#00796B] bg-[#00796B]/10 font-bold text-slate-900">
                <td colSpan={rowFields.length} className="whitespace-nowrap px-4 py-2">
                  Grand Total
                </td>
                {renderValueCells(grandTotal.values, "font-bold")}
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </div>
  );
}
