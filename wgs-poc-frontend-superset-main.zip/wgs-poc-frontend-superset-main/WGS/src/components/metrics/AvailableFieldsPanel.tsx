import type { FieldOption } from "./DimensionPicker";

type Props = {
  dimensionFields: FieldOption[];
  measureFields: FieldOption[];
  selectedDimensions: string[];
  selectedMeasureFields: string[];
  onAddRow: (field: FieldOption) => void;
  onAddValue: (field: FieldOption) => void;
};

/** The Power BI-style field list — Dimensions/Measures grouped, each addable to Rows or Values with one click. */
export default function AvailableFieldsPanel({
  dimensionFields,
  measureFields,
  selectedDimensions,
  selectedMeasureFields,
  onAddRow,
  onAddValue,
}: Props) {
  const availableDimensions = dimensionFields.filter((f) => !selectedDimensions.includes(f.columnName));
  const availableMeasures = measureFields.filter((f) => !selectedMeasureFields.includes(f.columnName));

  return (
    <div className="space-y-4 rounded-2xl border border-slate-200 bg-white p-4">
      <div>
        <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Dimensions</p>
        {availableDimensions.length ? (
          <div className="flex flex-col gap-1.5">
            {availableDimensions.map((field) => (
              <button
                key={field.columnName}
                type="button"
                onClick={() => onAddRow(field)}
                title={`Add ${field.label} to Rows`}
                className="flex items-center justify-between rounded-lg border border-slate-200 bg-white px-3 py-2 text-left text-sm text-slate-700 transition hover:border-[#00796B] hover:text-[#00796B]"
              >
                {field.label}
                <span className="text-xs font-semibold">+ Row</span>
              </button>
            ))}
          </div>
        ) : (
          <p className="text-xs text-slate-400">All dimensions are in Rows.</p>
        )}
      </div>

      <div>
        <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Measures</p>
        {availableMeasures.length ? (
          <div className="flex flex-col gap-1.5">
            {availableMeasures.map((field) => (
              <button
                key={field.columnName}
                type="button"
                onClick={() => onAddValue(field)}
                title={`Add ${field.label} to Values`}
                className="flex items-center justify-between rounded-lg border border-slate-200 bg-white px-3 py-2 text-left text-sm text-slate-700 transition hover:border-[#00796B] hover:text-[#00796B]"
              >
                {field.label}
                <span className="text-xs font-semibold">+ Value</span>
              </button>
            ))}
          </div>
        ) : (
          <p className="text-xs text-slate-400">All measures are in Values.</p>
        )}
      </div>
    </div>
  );
}
