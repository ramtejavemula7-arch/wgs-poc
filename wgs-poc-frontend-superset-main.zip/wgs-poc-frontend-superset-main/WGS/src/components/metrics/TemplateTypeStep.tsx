import { FileSpreadsheet, Flame, Layers } from "lucide-react";
// import { BarChart3 } from "lucide-react"; // re-add when the Matrix (metrics) template type is re-enabled below

export type TemplateType = "transaction" | "metrics" | "grouped" | "heatmap";

// The fixed report title shown on every preview/export header — not user-editable, only the
// template name (a subtitle) changes per template.
export const REPORT_TITLES: Record<TemplateType, string> = {
  transaction: "DAILY TRANSACTION REPORT",
  metrics: "MATRIX REPORT",
  grouped: "MATRIX TEMPLATE",
  heatmap: "VALUE DISTRIBUTION BY PERIOD REPORT",
};

type Props = {
  value: TemplateType | null;
  onSelect: (type: TemplateType) => void;
};

const OPTIONS: { key: TemplateType; label: string; description: string; Icon: typeof FileSpreadsheet }[] = [
  {
    key: "transaction",
    label: "Daily Transaction Details",
    description: "A detailed report with one row per transaction. Pick columns, filter the data, done.",
    Icon: FileSpreadsheet,
  },
  // Matrix (metrics) template type — temporarily disabled from selection. Existing Matrix
  // templates still open/export fine; this only hides it as a choice for new templates.
  // {
  //   key: "metrics",
  //   label: "Matrix Report",
  //   description: "A Power BI-style Matrix — configure Rows, Columns, and Values with hierarchy, subtotals, and Grand Totals.",
  //   Icon: BarChart3,
  // },
  {
    key: "grouped",
    label: "Matrix Template",
    description: "Row-level detail grouped under merged headers, with a single Grand Total. Like an Excel PivotTable in tabular layout.",
    Icon: Layers,
  },
  {
    key: "heatmap",
    label: "Value Distribution by Period",
    description: "A Rows x Columns pivot shaded from light to dark by value — great for spotting highs and lows at a glance.",
    Icon: Flame,
  },
];

export default function TemplateTypeStep({ value, onSelect }: Props) {
  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
      {OPTIONS.map(({ key, label, description, Icon }) => {
        const selected = value === key;
        return (
          <button
            key={key}
            type="button"
            onClick={() => onSelect(key)}
            className={`group rounded-3xl border p-6 text-left transition ${
              selected ? "border-[#00796B] bg-[#effffa]" : "border-slate-200 bg-white hover:border-[#00796B]/80"
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-lg font-semibold text-slate-900">{label}</p>
                <p className="mt-2 text-sm text-slate-500">{description}</p>
              </div>
              <Icon className="shrink-0 text-[#00796B]" />
            </div>
          </button>
        );
      })}
    </div>
  );
}
