import { ArrowDown, ArrowUp, X } from "lucide-react";
import {
  AGGREGATION_LABELS,
  getAggregationOptions,
  ORDER_COUNT_FIELD,
  type AggregationFn,
  type MetricSelection,
} from "../../utils/metricsAggregation";
import { CURRENCY_OPTIONS, type CurrencyCode } from "../../utils/currencyFormat";
import StyledSelect from "../StyledSelect";

type Props = {
  selected: MetricSelection[];
  onChange: (next: MetricSelection[]) => void;
};

/** The "Values" well — ordered, reorderable, removable. Fields are added via the Available Fields panel. */
export default function MetricPicker({ selected, onChange }: Props) {
  const remove = (columnName: string) => {
    onChange(selected.filter((m) => m.field !== columnName));
  };

  const setAggregation = (columnName: string, aggregation: AggregationFn) => {
    onChange(selected.map((m) => (m.field === columnName ? { ...m, aggregation } : m)));
  };

  const setFormat = (columnName: string, format: CurrencyCode) => {
    onChange(
      selected.map((m) => (m.field === columnName ? { ...m, format: format === "NONE" ? undefined : format } : m))
    );
  };

  const move = (index: number, delta: number) => {
    const target = index + delta;
    if (target < 0 || target >= selected.length) return;
    const next = [...selected];
    [next[index], next[target]] = [next[target], next[index]];
    onChange(next);
  };

  if (!selected.length) {
    return (
      <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 px-4 py-6 text-center text-sm text-slate-400">
        Add measures from Available Fields to populate Values.
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {selected.map((metric, index) => {
        const options = getAggregationOptions(metric.field);
        return (
          <div
            key={metric.field}
            className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#00796B] bg-[#00796B]/5 px-3 py-2.5"
          >
            <div className="flex items-center gap-2">
              <div className="flex flex-col">
                <button
                  type="button"
                  disabled={index === 0}
                  onClick={() => move(index, -1)}
                  className="rounded p-0.5 text-slate-500 transition hover:bg-white disabled:cursor-not-allowed disabled:opacity-30"
                >
                  <ArrowUp size={12} />
                </button>
                <button
                  type="button"
                  disabled={index === selected.length - 1}
                  onClick={() => move(index, 1)}
                  className="rounded p-0.5 text-slate-500 transition hover:bg-white disabled:cursor-not-allowed disabled:opacity-30"
                >
                  <ArrowDown size={12} />
                </button>
              </div>
              <span className="text-sm font-medium text-slate-800">{metric.label}</span>
            </div>
            <div className="flex items-center gap-2">
              <StyledSelect
                className="w-36"
                buttonClassName="h-9 px-2"
                value={metric.aggregation}
                onChange={(next) => setAggregation(metric.field, next as AggregationFn)}
                options={options.map((op) => ({ value: op, label: AGGREGATION_LABELS[op] }))}
              />
              {metric.field !== ORDER_COUNT_FIELD && (
                <StyledSelect
                  className="w-32"
                  buttonClassName="h-9 px-2"
                  value={metric.format ?? "NONE"}
                  onChange={(next) => setFormat(metric.field, next as CurrencyCode)}
                  options={CURRENCY_OPTIONS.map((option) => ({ value: option.value, label: option.label }))}
                />
              )}
              <button
                type="button"
                onClick={() => remove(metric.field)}
                aria-label={`Remove ${metric.label}`}
                className="rounded-full p-1.5 text-slate-500 transition hover:bg-white hover:text-red-600"
              >
                <X size={14} />
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
