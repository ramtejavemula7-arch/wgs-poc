import { METRICS_PRESETS, resolvePreset, type MetricsReportConfig, type PresetResolvableField } from "../../utils/metricsPresets";

type Props = {
  availableFields: PresetResolvableField[];
  onApply: (config: MetricsReportConfig) => void;
};

export default function MetricsPresetBar({ availableFields, onApply }: Props) {
  return (
    <div>
      <p className="mb-2 text-sm font-semibold text-slate-700">Smart presets</p>
      <div className="flex flex-wrap gap-2">
        {METRICS_PRESETS.map((preset) => (
          <button
            key={preset.key}
            type="button"
            onClick={() => onApply(resolvePreset(preset, availableFields))}
            title={preset.description}
            className="rounded-full border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 transition hover:border-[#00796B] hover:text-[#00796B]"
          >
            {preset.label}
          </button>
        ))}
      </div>
    </div>
  );
}
