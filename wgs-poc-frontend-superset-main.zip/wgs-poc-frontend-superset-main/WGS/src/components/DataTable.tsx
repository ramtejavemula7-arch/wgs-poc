import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Filter, Search } from "lucide-react";
import { formatCellValue } from "../utils/formatCellValue";
import StyledSelect from "./StyledSelect";
import LogoSpinner from "./LogoSpinner";

export type DataTableColumn<T> = {
  key: string;
  header: string;
  sortable?: boolean;
  filterable?: boolean;
  align?: "left" | "right" | "center";
  render?: (row: T) => ReactNode;
};

export type DataTableProps<T> = {
  columns: DataTableColumn<T>[];
  rows: T[];
  loading?: boolean;
  emptyMessage?: string;
  getRowKey: (row: T, index: number) => string | number;
  searchable?: boolean;
  searchPlaceholder?: string;
  pageSizeOptions?: number[];
  defaultPageSize?: number;
  toolbarActions?: ReactNode;
  toolbarExtra?: ReactNode;
};

function cellValue<T>(row: T, key: string): unknown {
  return (row as Record<string, unknown>)[key];
}

function getPageNumbers(count: number, currentPage: number): (number | "...")[] {
  if (count <= 7) return Array.from({ length: count }, (_, i) => i + 1);
  const pages: (number | "...")[] = [1];
  if (currentPage > 3) pages.push("...");
  const start = Math.max(2, currentPage - 1);
  const end = Math.min(count - 1, currentPage + 1);
  for (let i = start; i <= end; i++) pages.push(i);
  if (currentPage < count - 2) pages.push("...");
  pages.push(count);
  return pages;
}

export default function DataTable<T>({
  columns,
  rows,
  loading = false,
  emptyMessage = "No records found.",
  getRowKey,
  searchable = false,
  searchPlaceholder = "Search...",
  pageSizeOptions = [10, 20, 50],
  defaultPageSize = 10,
  toolbarActions,
  toolbarExtra,
}: DataTableProps<T>) {
  const [search, setSearch] = useState("");
  const [columnFilters, setColumnFilters] = useState<Record<string, string>>({});
  const [openFilterColumn, setOpenFilterColumn] = useState<string | null>(null);
  const [sortKey, setSortKey] = useState<string | null>(null);
  const [sortDesc, setSortDesc] = useState(false);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(defaultPageSize);

  useEffect(() => {
    if (!openFilterColumn) return;
    const close = () => setOpenFilterColumn(null);
    document.addEventListener("click", close);
    return () => document.removeEventListener("click", close);
  }, [openFilterColumn]);

  const filteredRows = useMemo(() => {
    let next = rows;

    const activeColumnFilters = Object.entries(columnFilters).filter(([, value]) => value.trim());
    if (activeColumnFilters.length) {
      next = next.filter((row) =>
        activeColumnFilters.every(([key, value]) =>
          formatCellValue(cellValue(row, key)).toLowerCase().includes(value.trim().toLowerCase())
        )
      );
    }

    if (searchable && search.trim()) {
      const term = search.trim().toLowerCase();
      next = next.filter((row) =>
        columns.some((col) => formatCellValue(cellValue(row, col.key)).toLowerCase().includes(term))
      );
    }

    return next;
  }, [rows, columnFilters, search, searchable, columns]);

  const sortedRows = useMemo(() => {
    if (!sortKey) return filteredRows;
    const copy = [...filteredRows];
    copy.sort((a, b) => {
      const aVal = cellValue(a, sortKey);
      const bVal = cellValue(b, sortKey);
      if (typeof aVal === "number" && typeof bVal === "number") return aVal - bVal;
      const aStr = formatCellValue(aVal);
      const bStr = formatCellValue(bVal);
      return aStr.localeCompare(bStr);
    });
    if (sortDesc) copy.reverse();
    return copy;
  }, [filteredRows, sortKey, sortDesc]);

  const totalPages = Math.max(1, Math.ceil(sortedRows.length / pageSize));
  const clampedPage = Math.min(page, totalPages);
  const pageRows = sortedRows.slice((clampedPage - 1) * pageSize, clampedPage * pageSize);

  const handleSort = (key: string) => {
    if (sortKey === key) {
      setSortDesc((prev) => !prev);
    } else {
      setSortKey(key);
      setSortDesc(false);
    }
  };

  const handleColumnFilterChange = (key: string, value: string) => {
    setPage(1);
    setColumnFilters((prev) => ({ ...prev, [key]: value }));
  };

  return (
    <div className="space-y-3">
      {(searchable || toolbarActions || toolbarExtra) && (
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-3">
            {searchable && (
              <div className="relative">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={search}
                  onChange={(event) => {
                    setPage(1);
                    setSearch(event.target.value);
                  }}
                  placeholder={searchPlaceholder}
                  className="h-10 w-64 rounded-lg border border-slate-300 pl-9 pr-3 text-sm text-slate-900 outline-none transition focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
                />
              </div>
            )}
            {toolbarExtra}
          </div>
          {toolbarActions && <div className="flex flex-wrap items-center gap-2">{toolbarActions}</div>}
        </div>
      )}

      <div className="overflow-x-auto rounded-2xl border border-slate-200">
        <table className="min-w-full divide-y divide-slate-200 text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
            <tr>
              {columns.map((col) => (
                <th
                  key={col.key}
                  className={`relative select-none whitespace-nowrap px-4 py-3 ${
                    col.align === "right" ? "text-right" : col.align === "center" ? "text-center" : "text-left"
                  }`}
                >
                  <span className="flex items-center gap-1.5">
                    <span
                      onClick={() => col.sortable && handleSort(col.key)}
                      className={`flex items-center gap-1.5 rounded px-1 py-0.5 ${
                        col.sortable ? "cursor-pointer hover:bg-slate-200" : ""
                      }`}
                    >
                      {col.header}
                      {col.sortable && (
                        <span className="flex flex-col gap-[1px] text-[10px] leading-none">
                          <span className={sortKey === col.key && !sortDesc ? "opacity-100" : "opacity-30"}>▲</span>
                          <span className={sortKey === col.key && sortDesc ? "opacity-100" : "opacity-30"}>▼</span>
                        </span>
                      )}
                    </span>
                    {col.filterable && (
                      <button
                        type="button"
                        onClick={(event) => {
                          event.stopPropagation();
                          setOpenFilterColumn((current) => (current === col.key ? null : col.key));
                        }}
                        title={`Filter ${col.header}`}
                        className={`rounded p-1 transition hover:bg-slate-200 ${
                          columnFilters[col.key]?.trim() ? "text-[#00796B]" : "text-slate-400"
                        }`}
                      >
                        <Filter size={13} />
                      </button>
                    )}
                  </span>

                  {openFilterColumn === col.key && (
                    <div
                      onClick={(event) => event.stopPropagation()}
                      className="absolute left-0 top-full z-20 mt-1 w-48 rounded-lg border border-slate-200 bg-white p-2 font-normal normal-case text-slate-900 shadow-lg"
                    >
                      <input
                        autoFocus
                        type="text"
                        value={columnFilters[col.key] ?? ""}
                        onChange={(event) => handleColumnFilterChange(col.key, event.target.value)}
                        placeholder={`Search ${col.header}`}
                        className="h-9 w-full rounded-md border border-slate-300 px-2 text-sm text-slate-900 outline-none focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
                      />
                    </div>
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {loading ? (
              <tr>
                <td colSpan={columns.length || 1} className="px-4 py-10 text-center text-slate-500">
                  <LogoSpinner className="mx-auto mb-2 h-5 w-5" />
                  Loading...
                </td>
              </tr>
            ) : pageRows.length ? (
              pageRows.map((row, index) => (
                <tr key={getRowKey(row, index)} className="hover:bg-slate-50">
                  {columns.map((col) => (
                    <td
                      key={col.key}
                      className={`whitespace-nowrap px-4 py-3 text-slate-600 ${
                        col.align === "right" ? "text-right" : col.align === "center" ? "text-center" : "text-left"
                      }`}
                    >
                      {col.render ? col.render(row) : formatCellValue(cellValue(row, col.key))}
                    </td>
                  ))}
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={columns.length || 1} className="px-4 py-10 text-center text-slate-500">
                  {emptyMessage}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {!loading && sortedRows.length > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-3 text-sm text-slate-600">
          <div className="flex items-center gap-2">
            <span>Show</span>
            <StyledSelect
              className="w-20"
              buttonClassName="h-9 px-2"
              value={String(pageSize)}
              onChange={(value) => {
                setPage(1);
                setPageSize(Number(value));
              }}
              options={pageSizeOptions.map((size) => ({ value: String(size), label: String(size) }))}
            />
            <span>
              Showing {(clampedPage - 1) * pageSize + 1}-{Math.min(clampedPage * pageSize, sortedRows.length)} of{" "}
              {sortedRows.length}
            </span>
          </div>

          <div className="flex items-center gap-1">
            <button
              type="button"
              disabled={clampedPage === 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 font-semibold text-slate-700 transition hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40"
            >
              Previous
            </button>
            {getPageNumbers(totalPages, clampedPage).map((p, index) =>
              p === "..." ? (
                <span key={`ellipsis-${index}`} className="px-2 text-slate-400">
                  ...
                </span>
              ) : (
                <button
                  key={p}
                  type="button"
                  onClick={() => setPage(p)}
                  className={`rounded-lg px-3 py-1.5 font-semibold transition ${
                    p === clampedPage
                      ? "bg-[#00796B] text-white"
                      : "border border-slate-300 bg-white text-slate-700 hover:bg-slate-100"
                  }`}
                >
                  {p}
                </button>
              )
            )}
            <button
              type="button"
              disabled={clampedPage === totalPages}
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 font-semibold text-slate-700 transition hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-40"
            >
              Next
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
