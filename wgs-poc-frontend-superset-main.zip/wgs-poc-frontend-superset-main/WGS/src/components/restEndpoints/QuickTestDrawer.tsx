import { useEffect, useState } from "react";
import { X } from "lucide-react";
import { apiFetch } from "../../utils/api";
import { API } from "../../utils/api-endpoints";
import { parseTestConnectionResult, type RawTestConnectionResponse, type TestConnectionResult } from "../../utils/restEndpointTypes";
import TestResultPanel from "./TestResultPanel";

type Props = {
  endpointId: number;
  endpointName: string;
  open: boolean;
  onClose: () => void;
};

export default function QuickTestDrawer({ endpointId, endpointName, open, onClose }: Props) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<TestConnectionResult | null>(null);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    setLoading(true);
    setError(null);
    setResult(null);

    (async () => {
      try {
        const resp = await apiFetch(API.restEndpoints.testConnectionSaved(endpointId), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: "{}",
        });
        const body = (await resp.json().catch(() => null)) as RawTestConnectionResponse | null;
        if (!resp.ok) throw new Error((body as { message?: string } | null)?.message || "Unable to test the connection.");
        if (!body) throw new Error("Unable to test the connection.");
        if (!cancelled) setResult(parseTestConnectionResult(body));
      } catch (err) {
        if (!cancelled) setError(err instanceof Error ? err.message : "Unable to test the connection.");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [open, endpointId]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50">
      <button
        type="button"
        aria-label="Close test drawer"
        className="overlay-enter absolute inset-0 bg-black/40"
        onClick={onClose}
      />
      <aside className="drawer-enter absolute right-0 top-0 flex h-full w-full max-w-xl flex-col overflow-hidden bg-white shadow-2xl">
        <div className="flex items-start justify-between border-b border-slate-200 px-6 py-5">
          <div>
            <h2 className="text-xl font-bold text-slate-900">Test Endpoint</h2>
            <p className="mt-1 text-sm text-slate-600">{endpointName}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-full p-2 text-slate-500 transition hover:bg-slate-100 hover:text-slate-700"
          >
            <X size={20} />
          </button>
        </div>
        <div className="flex-1 overflow-auto px-6 py-5">
          <TestResultPanel result={result} loading={loading} error={error} />
        </div>
      </aside>
    </div>
  );
}
