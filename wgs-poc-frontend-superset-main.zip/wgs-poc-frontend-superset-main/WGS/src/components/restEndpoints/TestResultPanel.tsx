import { CheckCircle2, XCircle } from "lucide-react";
import type { TestConnectionResult } from "../../utils/restEndpointTypes";
import LogoSpinner from "../LogoSpinner";

type Props = {
  result: TestConnectionResult | null;
  loading: boolean;
  error: string | null;
};

/** raw_response is plain text from the backend (truncated to ~20KB) — pretty-print it if it
 *  happens to be valid JSON, otherwise show it exactly as received. */
function formatRawResponse(raw: string): string {
  try {
    return JSON.stringify(JSON.parse(raw), null, 2);
  } catch {
    return raw;
  }
}

export default function TestResultPanel({ result, loading, error }: Props) {
  if (loading) {
    return (
      <div className="flex items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-10 text-sm font-medium text-slate-500">
        <LogoSpinner className="h-5 w-5" />
        Testing connection...
      </div>
    );
  }

  if (error) {
    return <div className="rounded-2xl bg-red-50 p-4 text-sm text-red-700">{error}</div>;
  }

  if (!result) {
    return (
      <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-4 py-8 text-center text-sm font-medium text-slate-500">
        Run a test to see the response here.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div
        className={`flex items-center gap-2 rounded-2xl px-4 py-3 text-sm font-semibold ${
          result.success ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"
        }`}
      >
        {result.success ? <CheckCircle2 size={18} /> : <XCircle size={18} />}
        {result.message}
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
        <div className="rounded-2xl border border-slate-200 p-4">
          <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">HTTP Status</p>
          <p className="mt-1 text-lg font-bold text-slate-900">{result.statusCode ?? "-"}</p>
        </div>
        <div className="rounded-2xl border border-slate-200 p-4">
          <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Response Time</p>
          <p className="mt-1 text-lg font-bold text-slate-900">
            {result.elapsedMs !== null ? `${result.elapsedMs} ms` : "-"}
          </p>
        </div>
      </div>

      <div>
        <p className="mb-2 text-sm font-semibold text-slate-700">Raw Response</p>
        <pre className="max-h-72 overflow-auto rounded-2xl border border-slate-200 bg-slate-900 p-4 text-xs text-emerald-300">
          {formatRawResponse(result.rawResponse)}
        </pre>
      </div>
    </div>
  );
}
