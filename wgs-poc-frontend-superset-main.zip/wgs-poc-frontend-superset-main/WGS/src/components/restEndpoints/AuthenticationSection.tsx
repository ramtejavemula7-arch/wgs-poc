import { AUTH_FORM_REGISTRY } from "./auth/authRegistry";
import { AUTH_TYPE_OPTIONS, type AuthConfig, type AuthType } from "../../utils/restEndpointTypes";
import StyledSelect from "../StyledSelect";

type Props = {
  authType: AuthType;
  authConfig: AuthConfig;
  onAuthTypeChange: (type: AuthType) => void;
  onConfigChange: (config: AuthConfig) => void;
  secretValue: string;
  onSecretValueChange: (value: string) => void;
  hasSecret: boolean;
};

const SECRET_LABELS: Record<AuthType, string | null> = {
  none: null,
  api_key: "API Key Value",
  basic_auth: "Password",
  bearer_token: "Access Token",
};

export default function AuthenticationSection({
  authType,
  authConfig,
  onAuthTypeChange,
  onConfigChange,
  secretValue,
  onSecretValueChange,
  hasSecret,
}: Props) {
  const entry = AUTH_FORM_REGISTRY[authType];
  const AuthForm = entry.Component;
  const secretLabel = SECRET_LABELS[authType];

  return (
    <div className="space-y-5">
      <label className="block max-w-sm">
        <span className="text-sm font-semibold text-slate-700">Authentication Type</span>
        <StyledSelect
          className="mt-2"
          value={authType}
          onChange={(next) => onAuthTypeChange(next as AuthType)}
          options={AUTH_TYPE_OPTIONS.map((option) => ({ value: option.value, label: option.label }))}
        />
      </label>

      <AuthForm draft={authConfig} onChange={onConfigChange} />

      {secretLabel && (
        <label className="block max-w-sm">
          <span className="text-sm font-semibold text-slate-700">{secretLabel}</span>
          <input
            type="password"
            value={secretValue}
            onChange={(event) => onSecretValueChange(event.target.value)}
            placeholder={hasSecret ? "" : `Enter the ${secretLabel.toLowerCase()}`}
            className="mt-2 h-10 w-full rounded-lg border border-slate-300 px-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
          />
          {hasSecret && (
            <p className="mt-1 text-xs text-slate-400">
              Leave blank to keep the existing value. Enter a new value to rotate it.
            </p>
          )}
        </label>
      )}
    </div>
  );
}
