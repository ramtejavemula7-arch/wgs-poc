import type { AuthFormProps } from "./authFormTypes";
import { inputClass, labelClass } from "./authFormTypes";
import type { AuthConfig } from "../../../utils/restEndpointTypes";
import StyledSelect from "../../StyledSelect";

type ApiKeyConfig = Extract<AuthConfig, { type: "api_key" }>;

export default function ApiKeyAuthForm({ draft, onChange }: AuthFormProps<ApiKeyConfig>) {
  return (
    <div className="space-y-4">
      <label className="block">
        <span className={labelClass}>API Key Name</span>
        <input
          type="text"
          value={draft.apiKeyName}
          onChange={(event) => onChange({ ...draft, apiKeyName: event.target.value })}
          placeholder="e.g. X-Api-Key"
          className={inputClass}
        />
      </label>

      <label className="block">
        <span className={labelClass}>Send In</span>
        <StyledSelect
          className="mt-2"
          buttonClassName="h-10"
          value={draft.sendIn}
          onChange={(next) => onChange({ ...draft, sendIn: next as ApiKeyConfig["sendIn"] })}
          options={[
            { value: "header", label: "Header" },
            { value: "query", label: "Query Parameter" },
            { value: "cookie", label: "Cookie" },
          ]}
        />
      </label>
    </div>
  );
}
