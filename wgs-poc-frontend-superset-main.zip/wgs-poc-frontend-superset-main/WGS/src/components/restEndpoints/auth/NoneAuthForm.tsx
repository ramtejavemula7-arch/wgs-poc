export default function NoneAuthForm() {
  return (
    <p className="text-sm text-slate-500">
      No authentication will be applied to this endpoint&apos;s requests.
    </p>
  );
}
