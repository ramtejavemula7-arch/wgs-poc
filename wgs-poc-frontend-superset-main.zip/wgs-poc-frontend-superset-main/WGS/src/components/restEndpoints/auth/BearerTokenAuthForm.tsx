export default function BearerTokenAuthForm() {
  return (
    <p className="text-sm text-slate-500">
      No additional configuration is needed. Enter the bearer token in the Secret Value field below.
    </p>
  );
}
