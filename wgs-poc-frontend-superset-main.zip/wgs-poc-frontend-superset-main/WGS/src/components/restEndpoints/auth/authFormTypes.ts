import type { AuthConfig } from "../../../utils/restEndpointTypes";

/** Only the non-secret auth_config fields live here — the one shared
 *  secret_value field is rendered once by AuthenticationSection, not per-form. */
export type AuthFormProps<T extends AuthConfig = AuthConfig> = {
  draft: T;
  onChange: (next: T) => void;
};

export const inputClass =
  "mt-2 h-10 w-full rounded-lg border border-slate-300 px-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-[#277777] focus:ring-2 focus:ring-[#277777]/20";

export const labelClass = "text-sm font-semibold text-slate-700";
