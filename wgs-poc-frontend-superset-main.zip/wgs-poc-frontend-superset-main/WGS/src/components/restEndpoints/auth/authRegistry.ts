import type { ComponentType } from "react";
import type { AuthConfig, AuthType } from "../../../utils/restEndpointTypes";
import { createDefaultAuthConfig } from "../../../utils/restEndpointTypes";
import type { AuthFormProps } from "./authFormTypes";
import NoneAuthForm from "./NoneAuthForm";
import ApiKeyAuthForm from "./ApiKeyAuthForm";
import BasicAuthForm from "./BasicAuthForm";
import BearerTokenAuthForm from "./BearerTokenAuthForm";

export type AuthFormRegistryEntry = {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  Component: ComponentType<AuthFormProps<any>>;
  createDefaultDraft: () => AuthConfig;
};

/**
 * Strategy Pattern registry: one entry per supported AuthType. Adding a new
 * auth mechanism (once the backend supports it) means adding one form
 * component + one entry here — nothing else in the app needs to change.
 */
export const AUTH_FORM_REGISTRY: Record<AuthType, AuthFormRegistryEntry> = {
  none: {
    Component: NoneAuthForm,
    createDefaultDraft: () => createDefaultAuthConfig("none"),
  },
  api_key: {
    Component: ApiKeyAuthForm,
    createDefaultDraft: () => createDefaultAuthConfig("api_key"),
  },
  basic_auth: {
    Component: BasicAuthForm,
    createDefaultDraft: () => createDefaultAuthConfig("basic_auth"),
  },
  bearer_token: {
    Component: BearerTokenAuthForm,
    createDefaultDraft: () => createDefaultAuthConfig("bearer_token"),
  },
};
