import type { AuthFormProps } from "./authFormTypes";
import { inputClass, labelClass } from "./authFormTypes";
import type { AuthConfig } from "../../../utils/restEndpointTypes";

type BasicAuthConfig = Extract<AuthConfig, { type: "basic_auth" }>;

export default function BasicAuthForm({ draft, onChange }: AuthFormProps<BasicAuthConfig>) {
  return (
    <label className="block">
      <span className={labelClass}>Username</span>
      <input
        type="text"
        value={draft.username}
        onChange={(event) => onChange({ ...draft, username: event.target.value })}
        className={inputClass}
      />
    </label>
  );
}
