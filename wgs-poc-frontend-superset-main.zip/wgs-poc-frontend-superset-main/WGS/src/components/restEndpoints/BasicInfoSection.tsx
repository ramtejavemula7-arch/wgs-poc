import { useEffect, useState } from "react";
import KeyValueListEditor from "../KeyValueListEditor";
import StyledSelect from "../StyledSelect";
import { HTTP_METHODS, type RestEndpointConfig } from "../../utils/restEndpointTypes";

export type BasicInfoDraft = Pick<
  RestEndpointConfig,
  "name" | "description" | "baseUrl" | "endpointPath" | "httpMethod" | "timeout" | "customHeaders" | "queryParams"
>;

type Props = {
  value: BasicInfoDraft;
  onChange: (next: BasicInfoDraft) => void;
  errors?: Partial<Record<"name" | "baseUrl", string>>;
};

const labelClass = "text-sm font-semibold text-slate-700";
const inputClass =
  "mt-2 h-11 w-full rounded-lg border border-slate-300 px-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20";

/** The backend stores base_url and endpoint_path as separate fields, but there's no reason to
 *  make the user split them by hand — this presents one "Endpoint URL" field and derives the two
 *  underlying values from it via the URL API. */
export default function BasicInfoSection({ value, onChange, errors }: Props) {
  const set = <K extends keyof BasicInfoDraft>(key: K, next: BasicInfoDraft[K]) => {
    onChange({ ...value, [key]: next });
  };

  const [rawUrl, setRawUrl] = useState(() => `${value.baseUrl}${value.endpointPath}`);

  useEffect(() => {
    setRawUrl(`${value.baseUrl}${value.endpointPath}`);
    // Only re-sync when the parent value changes for a reason other than our own edits
    // (e.g. loading an existing endpoint) — see handleUrlChange, which updates baseUrl/
    // endpointPath and rawUrl together so this effect is a no-op during normal typing.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value.baseUrl, value.endpointPath]);

  const handleUrlChange = (text: string) => {
    setRawUrl(text);
    try {
      const parsed = new URL(text);
      onChange({ ...value, baseUrl: parsed.origin, endpointPath: parsed.pathname + parsed.search });
    } catch {
      // Not a complete, valid absolute URL yet (e.g. still typing) — let the user keep typing
      // without touching baseUrl/endpointPath until it parses successfully.
    }
  };

  return (
    <div className="space-y-5">
      <div className="grid gap-5 md:grid-cols-2">
        <label className="block">
          <span className={labelClass}>Endpoint Name *</span>
          <input
            type="text"
            value={value.name}
            onChange={(event) => set("name", event.target.value)}
            className={inputClass}
          />
          {errors?.name && <p className="mt-1 text-xs text-red-600">{errors.name}</p>}
        </label>

        <label className="block">
          <span className={labelClass}>Description</span>
          <input
            type="text"
            value={value.description}
            onChange={(event) => set("description", event.target.value)}
            placeholder="Optional"
            className={inputClass}
          />
        </label>
      </div>

      <label className="block">
        <span className={labelClass}>Endpoint URL *</span>
        <input
          type="text"
          value={rawUrl}
          onChange={(event) => handleUrlChange(event.target.value)}
          placeholder="https://api.example.com/v1/employees"
          className={inputClass}
        />
        {errors?.baseUrl && <p className="mt-1 text-xs text-red-600">{errors.baseUrl}</p>}
      </label>

      <div className="grid gap-5 md:grid-cols-2">
        <label className="block">
          <span className={labelClass}>HTTP Method</span>
          <StyledSelect
            className="mt-2"
            value={value.httpMethod}
            onChange={(next) => set("httpMethod", next as BasicInfoDraft["httpMethod"])}
            options={HTTP_METHODS.map((method) => ({ value: method, label: method }))}
          />
        </label>

        <label className="block">
          <span className={labelClass}>Timeout (seconds)</span>
          <input
            type="number"
            min={1}
            max={300}
            value={value.timeout}
            onChange={(event) => set("timeout", Number(event.target.value) || 30)}
            className={inputClass}
          />
        </label>
      </div>

      <div>
        <span className={labelClass}>Custom Headers</span>
        <div className="mt-2">
          <KeyValueListEditor
            pairs={value.customHeaders}
            onChange={(customHeaders) => set("customHeaders", customHeaders)}
            addButtonLabel="+ Add header"
          />
        </div>
      </div>

      <div>
        <span className={labelClass}>Query Parameters</span>
        <div className="mt-2">
          <KeyValueListEditor
            pairs={value.queryParams}
            onChange={(queryParams) => set("queryParams", queryParams)}
            addButtonLabel="+ Add parameter"
          />
        </div>
      </div>
    </div>
  );
}
