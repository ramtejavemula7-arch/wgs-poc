import { useState } from "react";
import { AlertTriangle, Loader2, Save } from "lucide-react";

type Props = {
  validationErrors: string[];
  /** Only true once the user has actually clicked Save while invalid — errors stay hidden
   *  until then rather than showing eagerly on an untouched, empty form. */
  showValidationErrors: boolean;
  hasSucceededTest: boolean;
  saving: boolean;
  onSave: () => void;
  onInvalidAttempt: () => void;
};

export default function SaveConfigurationBar({
  validationErrors,
  showValidationErrors,
  hasSucceededTest,
  saving,
  onSave,
  onInvalidAttempt,
}: Props) {
  const [confirmingUntested, setConfirmingUntested] = useState(false);
  const hasBlockingErrors = validationErrors.length > 0;

  const handleSaveClick = () => {
    if (hasBlockingErrors) {
      onInvalidAttempt();
      return;
    }
    if (!hasSucceededTest && !confirmingUntested) {
      setConfirmingUntested(true);
      return;
    }
    setConfirmingUntested(false);
    onSave();
  };

  return (
    <div className="sticky bottom-0 space-y-3 rounded-3xl border border-slate-200 bg-white p-5 shadow-lg">
      {showValidationErrors && hasBlockingErrors && (
        <div className="rounded-2xl bg-red-50 p-3 text-sm text-red-700">
          <ul className="list-inside list-disc space-y-1">
            {validationErrors.map((err) => (
              <li key={err}>{err}</li>
            ))}
          </ul>
        </div>
      )}

      {!hasBlockingErrors && confirmingUntested && (
        <div className="flex items-center gap-2 rounded-2xl bg-amber-50 p-3 text-sm text-amber-800">
          <AlertTriangle size={16} className="shrink-0" />
          You have not tested this connection in this session. Save anyway?
        </div>
      )}

      <div className="flex justify-end gap-3">
        {confirmingUntested && (
          <button
            type="button"
            onClick={() => setConfirmingUntested(false)}
            className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-100"
          >
            Cancel
          </button>
        )}
        <button
          type="button"
          onClick={handleSaveClick}
          disabled={saving}
          className="inline-flex items-center gap-2 rounded-lg bg-[#00796B] px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-[#00695C] disabled:cursor-not-allowed disabled:bg-slate-300"
        >
          {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
          {confirmingUntested ? "Save Anyway" : "Save Configuration"}
        </button>
      </div>
    </div>
  );
}
