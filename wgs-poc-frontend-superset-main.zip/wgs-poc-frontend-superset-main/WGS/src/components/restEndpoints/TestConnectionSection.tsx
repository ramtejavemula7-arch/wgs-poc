import { useState } from "react";
import { PlugZap } from "lucide-react";
import { apiFetch } from "../../utils/api";
import { API } from "../../utils/api-endpoints";
import {
  buildRequestBody,
  parseTestConnectionResult,
  type RawTestConnectionResponse,
  type RestEndpointConfig,
  type TestConnectionResult,
} from "../../utils/restEndpointTypes";
import TestResultPanel from "./TestResultPanel";

type Props = {
  config: RestEndpointConfig;
  onTestSucceeded: (result: TestConnectionResult) => void;
};

/** Tests a draft (possibly unsaved) config via the stateless POST /test-connection route —
 *  the backend docs confirm it takes "the same body as Create". */
export default function TestConnectionSection({ config, onTestSucceeded }: Props) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<TestConnectionResult | null>(null);

  const handleTest = async () => {
    setLoading(true);
    setError(null);

    try {
      const resp = await apiFetch(API.restEndpoints.testConnectionDraft, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(buildRequestBody(config)),
      });

      const body = (await resp.json().catch(() => null)) as RawTestConnectionResponse | null;

      if (!resp.ok) {
        throw new Error((body as { message?: string } | null)?.message || "Unable to test the connection.");
      }
      if (!body) {
        throw new Error("Unable to test the connection.");
      }

      const testResult = parseTestConnectionResult(body);
      setResult(testResult);
      if (testResult.success) onTestSucceeded(testResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to test the connection.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <button
        type="button"
        onClick={handleTest}
        disabled={loading}
        className="inline-flex items-center gap-2 rounded-lg bg-[#00796B] px-4 py-2 text-sm font-semibold text-white transition hover:bg-[#00695C] disabled:cursor-not-allowed disabled:bg-slate-300"
      >
        <PlugZap size={16} />
        Test Endpoint
      </button>

      <TestResultPanel result={result} loading={loading} error={error} />
    </div>
  );
}
