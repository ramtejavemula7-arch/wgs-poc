import { FILTER_VALUE_INPUT_TYPE_LABELS, type FilterValueInputType, type MappedField } from "../../utils/restEndpointTypes";
import StyledSelect from "../StyledSelect";

type Props = {
  mapping: MappedField[];
  onChange: (next: MappedField[]) => void;
};

const VALUE_INPUT_TYPE_ENTRIES = Object.entries(FILTER_VALUE_INPUT_TYPE_LABELS) as [FilterValueInputType, string][];

/**
 * Discovery (flattenResponse.ts) runs once, right when a test succeeds, in
 * the parent page — this component is purely presentational over the
 * resulting MappedField[] (toggle selection, edit alias, pick filter type).
 * Every selected row automatically becomes a search box above the table in
 * Data Preview/Transaction Search — there's no separate "Add filter" step.
 */
export default function ResponseMappingSection({ mapping, onChange }: Props) {
  const updateRow = (index: number, patch: Partial<MappedField>) => {
    onChange(mapping.map((row, i) => (i === index ? { ...row, ...patch } : row)));
  };

  const setAllSelected = (selected: boolean) => {
    onChange(mapping.map((row) => ({ ...row, selected })));
  };

  if (!mapping.length) {
    return (
      <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-4 py-8 text-center text-sm font-medium text-slate-500">
        No fields were discovered in the last test response.
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <p className="text-xs text-slate-500">
        Selected fields are shown as table columns and automatically become search boxes above the
        table — pick how each one should be searched.
      </p>
      <div className="rounded-2xl border border-slate-200">
        <table className="min-w-full divide-y divide-slate-200 text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-4 py-3 font-semibold">
                <div className="flex flex-col gap-1">
                  <span>Select</span>
                  <div className="flex items-center gap-1 whitespace-nowrap normal-case tracking-normal">
                    <button
                      type="button"
                      onClick={() => setAllSelected(true)}
                      className="font-semibold text-[#00796B] hover:underline"
                    >
                      Select All
                    </button>
                    <span className="text-slate-300">|</span>
                    <button
                      type="button"
                      onClick={() => setAllSelected(false)}
                      className="font-semibold text-[#00796B] hover:underline"
                    >
                      Deselect All
                    </button>
                  </div>
                </div>
              </th>
              <th className="px-4 py-3 font-semibold">Response Field</th>
              <th className="px-4 py-3 font-semibold">Alias</th>
              <th className="px-4 py-3 font-semibold">Filter Type</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 bg-white">
            {mapping.map((row, index) => (
              <tr key={row.fieldPath}>
                <td className="px-4 py-2">
                  <input
                    type="checkbox"
                    checked={row.selected}
                    onChange={(event) => updateRow(index, { selected: event.target.checked })}
                    className="h-4 w-4 rounded border-slate-300 text-[#00796B] focus:ring-[#00796B]"
                  />
                </td>
                <td className="whitespace-nowrap px-4 py-2 font-mono text-xs text-slate-700">{row.fieldPath}</td>
                <td className="px-4 py-2">
                  <input
                    type="text"
                    value={row.alias}
                    onChange={(event) => updateRow(index, { alias: event.target.value })}
                    className="h-9 w-full rounded-md border border-slate-300 px-2 text-sm text-slate-900 outline-none focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
                  />
                </td>
                <td className="px-4 py-2">
                  <StyledSelect
                    buttonClassName="h-9"
                    value={row.filterType}
                    disabled={!row.selected}
                    onChange={(next) => updateRow(index, { filterType: next as FilterValueInputType })}
                    options={VALUE_INPUT_TYPE_ENTRIES.map(([value, label]) => ({ value, label }))}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
