import { useEffect, useRef, useState } from "react";
import embed from "vega-embed";

type Props = {
  spec: object;
};

/** Renders a raw Vega (or Vega-Lite) spec returned by the chat agent. A malformed/unsupported
 *  spec shouldn't take down the whole chat message, so embed errors are swallowed here. */
export default function ChatChart({ spec }: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (!ref.current) return;
    setFailed(false);

    let cancelled = false;
    embed(ref.current, spec, { actions: false }).catch(() => {
      if (!cancelled) setFailed(true);
    });

    return () => {
      cancelled = true;
    };
  }, [spec]);

  if (failed) return null;

  return <div ref={ref} />;
}
