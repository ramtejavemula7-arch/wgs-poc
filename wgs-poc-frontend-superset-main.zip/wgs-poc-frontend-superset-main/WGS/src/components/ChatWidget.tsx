import { useEffect, useRef, useState, type ChangeEvent, type FormEvent, type KeyboardEvent } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Bot, MessageCircle, Send, User, X } from "lucide-react";
import { apiFetch } from "../utils/api";
import { API } from "../utils/api-endpoints";
import { logout } from "../utils/auth";

type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
  isError?: boolean;
};

type ChatResponse = {
  answer: string;
};

type ChatErrorResponse = {
  detail?: string;
};

const MAX_QUESTION_LENGTH = 2000;

function createMessageId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

export default function ChatWidget() {
  const location = useLocation();
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isLoading, isOpen]);

  const askQuestion = async (rawQuestion: string) => {
    const question = rawQuestion.trim();
    if (!question || question.length > MAX_QUESTION_LENGTH || isLoading) return;

    setMessages((prev) => [...prev, { id: createMessageId(), role: "user", content: question }]);
    setInput("");
    if (textareaRef.current) textareaRef.current.style.height = "auto";
    setIsLoading(true);

    const appendError = (content: string) => {
      setMessages((prev) => [...prev, { id: createMessageId(), role: "assistant", content, isError: true }]);
    };

    try {
      const resp = await apiFetch(API.chat.ask, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question, dashboard_id: null }),
        timeout: 90_000, // LLM responses legitimately take longer than the 30s default.
      });

      if (resp.status === 401) {
        appendError("Your session has expired. Please log in again.");
        logout();
        navigate("/login");
        return;
      }

      if (!resp.ok) {
        if (resp.status === 404) {
          appendError("Couldn't load context for this dashboard.");
          return;
        }

        let detail = "Something went wrong. Please try again.";
        try {
          const data = (await resp.json()) as ChatErrorResponse;
          if (data?.detail) detail = data.detail;
        } catch {
          // Response body wasn't valid JSON; fall back to the generic message.
        }
        appendError(detail);
        return;
      }

      const data = (await resp.json()) as ChatResponse;
      setMessages((prev) => [
        ...prev,
        { id: createMessageId(), role: "assistant", content: data.answer },
      ]);
    } catch {
      appendError("Couldn't reach the server. Please check your connection and try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    void askQuestion(input);
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      void askQuestion(input);
    }
  };

  const handleInputChange = (event: ChangeEvent<HTMLTextAreaElement>) => {
    setInput(event.target.value);
    const el = event.target;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 120)}px`;
  };

  const canSend = input.trim().length > 0 && input.trim().length <= MAX_QUESTION_LENGTH && !isLoading;

  const PAGES_WITH_OWN_ASSISTANT = ["/chat-assistant", "/dashboard", "/templates", "/transactions"];
  if (PAGES_WITH_OWN_ASSISTANT.includes(location.pathname)) {
    return null;
  }

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-4 print:hidden">
      {isOpen && (
        <div className="flex h-[520px] w-[360px] max-w-[calc(100vw-3rem)] flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl">
          <div className="flex items-center justify-between bg-[#00796B] px-4 py-3 text-white">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white/15">
                <Bot size={16} />
              </div>
              <div>
                <p className="text-sm font-semibold">Chat Assistant</p>
                <p className="text-[11px] text-white/70">Usually replies instantly</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="flex h-7 w-7 items-center justify-center rounded-full text-white/80 transition hover:bg-white/15 hover:text-white"
              title="Close chat"
            >
              <X size={16} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto bg-slate-50 px-3 py-4">
            {messages.length === 0 ? (
              <div className="flex h-full flex-col items-center justify-center px-4 text-center">
                <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-[#00796B]/10 text-[#00796B]">
                  <Bot size={22} />
                </div>
                <p className="text-sm font-semibold text-slate-800">Hi! How can I help?</p>
                <p className="mt-1 text-xs text-slate-500">
                  Ask about dashboards, templates, or reports.
                </p>
              </div>
            ) : (
              <div className="flex flex-col gap-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex items-start gap-2 ${
                      message.role === "user" ? "flex-row-reverse" : "flex-row"
                    }`}
                  >
                    <div
                      className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full ${
                        message.role === "user"
                          ? "bg-slate-700 text-white"
                          : "bg-[#00796B]/10 text-[#00796B]"
                      }`}
                    >
                      {message.role === "user" ? <User size={12} /> : <Bot size={12} />}
                    </div>
                    <div
                      className={`max-w-[78%] whitespace-pre-wrap rounded-2xl px-3 py-2 text-[13px] leading-relaxed shadow-sm ${
                        message.role === "user"
                          ? "rounded-tr-sm bg-[#00796B] text-white"
                          : message.isError
                            ? "rounded-tl-sm border border-red-200 bg-red-50 text-red-700"
                            : "rounded-tl-sm border border-slate-200 bg-white text-slate-800"
                      }`}
                    >
                      {message.content}
                    </div>
                  </div>
                ))}

                {isLoading && (
                  <div className="flex items-start gap-2">
                    <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#00796B]/10 text-[#00796B]">
                      <Bot size={12} />
                    </div>
                    <div className="flex items-center gap-1 rounded-2xl rounded-tl-sm border border-slate-200 bg-white px-3 py-2.5 shadow-sm">
                      <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-slate-400 [animation-delay:-0.3s]" />
                      <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-slate-400 [animation-delay:-0.15s]" />
                      <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-slate-400" />
                    </div>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>
            )}
          </div>

          <form onSubmit={handleSubmit} className="flex items-end gap-2 border-t border-slate-200 bg-white p-3">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              placeholder="Type a message..."
              rows={1}
              disabled={isLoading}
              maxLength={MAX_QUESTION_LENGTH}
              className="max-h-28 flex-1 resize-none rounded-xl border border-slate-300 px-3 py-2 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20 disabled:bg-slate-50"
            />
            <button
              type="submit"
              disabled={!canSend}
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#00796B] text-white transition hover:bg-[#00695C] disabled:cursor-not-allowed disabled:opacity-40"
              title="Send message"
            >
              <Send size={15} />
            </button>
          </form>
        </div>
      )}

      <button
        type="button"
        onClick={() => setIsOpen((v) => !v)}
        className="flex h-14 w-14 items-center justify-center rounded-full bg-[#00796B] text-white shadow-lg shadow-black/20 transition hover:scale-105 hover:bg-[#00695C]"
        title={isOpen ? "Close chat" : "Open chat"}
      >
        {isOpen ? <X size={24} /> : <MessageCircle size={24} />}
      </button>
    </div>
  );
}
