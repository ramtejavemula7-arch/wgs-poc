import { Plus, X } from "lucide-react";

export type KeyValuePair = { key: string; value: string };

type Props = {
  pairs: KeyValuePair[];
  onChange: (next: KeyValuePair[]) => void;
  keyPlaceholder?: string;
  valuePlaceholder?: string;
  addButtonLabel?: string;
  maskValues?: boolean;
};

/**
 * Generalizes the recipient-chip add/remove mechanics from ScheduledReports.tsx
 * (immutable-array-append on add, filter-based removal) from single strings to
 * {key, value} row pairs.
 */
export default function KeyValueListEditor({
  pairs,
  onChange,
  keyPlaceholder = "Name",
  valuePlaceholder = "Value",
  addButtonLabel = "+ Add",
  maskValues = false,
}: Props) {
  const updateRow = (index: number, field: "key" | "value", nextValue: string) => {
    onChange(pairs.map((pair, i) => (i === index ? { ...pair, [field]: nextValue } : pair)));
  };

  const removeRow = (index: number) => {
    onChange(pairs.filter((_, i) => i !== index));
  };

  const addRow = () => {
    onChange([...pairs, { key: "", value: "" }]);
  };

  return (
    <div className="space-y-2">
      {pairs.map((pair, index) => (
        <div key={index} className="flex items-center gap-2">
          <input
            type="text"
            value={pair.key}
            onChange={(event) => updateRow(index, "key", event.target.value)}
            placeholder={keyPlaceholder}
            className="h-10 flex-1 rounded-lg border border-slate-300 px-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
          />
          <input
            type={maskValues ? "password" : "text"}
            value={pair.value}
            onChange={(event) => updateRow(index, "value", event.target.value)}
            placeholder={valuePlaceholder}
            className="h-10 flex-1 rounded-lg border border-slate-300 px-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
          />
          <button
            type="button"
            onClick={() => removeRow(index)}
            aria-label="Remove row"
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-slate-400 transition hover:bg-red-50 hover:text-red-600"
          >
            <X size={16} />
          </button>
        </div>
      ))}

      <button
        type="button"
        onClick={addRow}
        className="inline-flex items-center gap-1.5 rounded-lg border border-dashed border-slate-300 px-3 py-2 text-sm font-semibold text-slate-600 transition hover:border-[#00796B] hover:text-[#00796B]"
      >
        <Plus size={14} />
        {addButtonLabel}
      </button>
    </div>
  );
}
