import { Navigate, Outlet, useLocation } from "react-router-dom";
import { isAuthenticated } from "../utils/auth";
import ChatWidget from "./ChatWidget";

// Routes that render their own page-scoped PageChatbot — the global
// ChatWidget shares the same fixed bottom-right position, so it must be
// suppressed here or it renders on top of and hides the page-scoped one.
const PAGE_SCOPED_CHAT_ROUTES = [
  /^\/dashboard$/,
  /^\/transactions$/,
  /^\/templates\/(?!builder$|scheduled-reports$)[^/]+$/,
  /^\/admin\/users\/new$/,
  /^\/admin\/roles$/,
  /^\/api-endpoints$/,
  /^\/api-endpoints\/new$/,
  /^\/api-endpoints\/[^/]+\/edit$/,
  /^\/api-endpoints\/[^/]+\/preview$/,
];

function hasPageScopedChat(pathname: string) {
  return PAGE_SCOPED_CHAT_ROUTES.some((pattern) => pattern.test(pathname));
}

export default function ProtectedRoute() {
  const location = useLocation();

  if (!isAuthenticated()) {
    return <Navigate to="/login" replace />;
  }

  return (
    <>
      <Outlet />
      {!hasPageScopedChat(location.pathname) && <ChatWidget />}
    </>
  );
}
