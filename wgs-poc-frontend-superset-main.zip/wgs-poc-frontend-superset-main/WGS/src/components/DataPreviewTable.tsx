import { useCallback, useEffect, useState } from "react";
import { Download, RefreshCcw, RotateCcw } from "lucide-react";
import { apiFetch } from "../utils/api";
import { API } from "../utils/api-endpoints";
import { discoverFields, discoverRows, flattenObject, prettifyFieldName } from "../utils/flattenResponse";
import { buildCsv, downloadCsv } from "../utils/csvExport";
import { loadClientMappingConfig } from "../utils/clientSideMappingStore";
import { applyFilterConfig } from "../utils/applyClientFilters";
import { discoverFieldStats } from "../utils/filterFieldTypeDetection";
import {
  parseEndpointResponse,
  parseTestConnectionResult,
  FILTER_OPERATORS_WITHOUT_VALUE,
  FILTER_OPERATOR_LABELS,
  type FilterCondition,
  type FilterConfig,
  type MappedField,
  type RawTestConnectionResponse,
  type RestEndpointApiResponse,
  type RestEndpointConfig,
} from "../utils/restEndpointTypes";
import DataTable, { type DataTableColumn } from "./DataTable";
import StyledSelect from "./StyledSelect";

type Props = {
  endpointId: string | number;
  className?: string;
  showExportCsv?: boolean;
};

type Column = { key: string; header: string };

function buildColumns(mapping: MappedField[], rows: Record<string, unknown>[]): Column[] {
  const selected = mapping.filter((m) => m.selected);
  if (selected.length) {
    return selected.map((m) => ({ key: m.fieldPath, header: m.alias || prettifyFieldName(m.fieldPath) }));
  }
  return discoverFields(rows).map((field) => ({ key: field, header: prettifyFieldName(field) }));
}

const filterInputClass =
  "h-10 min-w-[10rem] rounded-lg border border-slate-300 px-3 text-sm text-slate-900 outline-none focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20";

export default function DataPreviewTable({ endpointId, className, showExportCsv = true }: Props) {
  const [config, setConfig] = useState<RestEndpointConfig | null>(null);
  const [rawRows, setRawRows] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastRefreshedAt, setLastRefreshedAt] = useState<Date | null>(null);
  const [liveFilterValues, setLiveFilterValues] = useState<Record<string, string>>({});

  useEffect(() => {
    setLiveFilterValues({});
  }, [endpointId]);

  const loadConfig = useCallback(async () => {
    try {
      const resp = await apiFetch(API.restEndpoints.detail(endpointId));
      if (!resp.ok) return;
      const data = (await resp.json()) as RestEndpointApiResponse;
      const parsedConfig = parseEndpointResponse(data);
      const stored = loadClientMappingConfig(data.id);
      setConfig(
        stored ? { ...parsedConfig, responseMapping: stored.responseMapping, filters: stored.filters } : parsedConfig
      );
    } catch {
      // Non-fatal — the table can still render with auto-discovered columns.
    }
  }, [endpointId]);

  /** No dedicated data endpoint exists yet — this reuses the saved-endpoint test-connection
   *  call as a stopgap data source (per team decision). Note the backend truncates
   *  raw_response to ~20KB and this re-invokes the live third-party endpoint on every refresh. */
  const loadData = useCallback(async () => {
    setError(null);
    setLoading(true);
    try {
      const resp = await apiFetch(API.restEndpoints.testConnectionSaved(endpointId), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: "{}",
      });
      const body = (await resp.json().catch(() => null)) as RawTestConnectionResponse | null;
      if (!resp.ok || !body) {
        throw new Error((body as { message?: string } | null)?.message || "Unable to load data for this endpoint.");
      }

      const result = parseTestConnectionResult(body);
      if (!result.success) {
        throw new Error(result.message || "The endpoint did not respond successfully.");
      }

      let parsed: unknown;
      try {
        parsed = JSON.parse(result.rawResponse);
      } catch {
        throw new Error("The endpoint response is not valid JSON and cannot be shown as a table.");
      }

      const { rows } = discoverRows(parsed);
      setRawRows(rows.map((row) => flattenObject(row)));
      setLastRefreshedAt(new Date());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to load data for this endpoint.");
    } finally {
      setLoading(false);
    }
  }, [endpointId]);

  useEffect(() => {
    void loadConfig();
    void loadData();
  }, [loadConfig, loadData]);

  const columns: DataTableColumn<Record<string, unknown>>[] = buildColumns(config?.responseMapping ?? [], rawRows).map(
    (col) => ({ key: col.key, header: col.header, sortable: true, filterable: true })
  );

  const appliedConditions = config?.filters.conditions ?? [];

  // Dropdown/date detection is recomputed from the currently-loaded live rows (not persisted
  // stats from registration time) so option lists always reflect what's actually on screen.
  const filterFieldStats = discoverFieldStats(rawRows, appliedConditions.map((c) => c.field));

  const effectiveFilterConfig: FilterConfig = {
    combinator: config?.filters.combinator ?? "AND",
    conditions: appliedConditions.map((cond) => ({
      ...cond,
      value: liveFilterValues[cond.id] ?? cond.value,
    })),
  };

  const filteredRows = applyFilterConfig(rawRows, effectiveFilterConfig);
  const hasCustomFilterValues = Object.keys(liveFilterValues).length > 0;

  const handleExportCsv = () => {
    const csvColumns = columns.map((col) => ({ key: col.key, label: col.header }));
    const csv = buildCsv(csvColumns, filteredRows);
    downloadCsv(`${config?.name || endpointId}.csv`, csv);
  };

  const effectiveType = (cond: FilterCondition) => cond.valueInputType ?? filterFieldStats[cond.field]?.type ?? "text";

  const renderFilterControl = (cond: FilterCondition) => {
    const type = effectiveType(cond);
    const options = filterFieldStats[cond.field]?.options ?? [];
    const value = liveFilterValues[cond.id] ?? cond.value ?? "";
    const setValue = (next: string) => setLiveFilterValues((prev) => ({ ...prev, [cond.id]: next }));

    if (type === "date") {
      return <input type="date" value={value.slice(0, 10)} onChange={(e) => setValue(e.target.value)} className={filterInputClass} />;
    }

    if (type === "categorical" || type === "dropdown") {
      return (
        <StyledSelect
          className="min-w-[10rem]"
          buttonClassName="h-10"
          value={value}
          onChange={setValue}
          options={[{ value: "", label: "All" }, ...options.map((option) => ({ value: option, label: option }))]}
        />
      );
    }

    return (
      <input
        type="text"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder={`Search ${prettifyFieldName(cond.field)}`}
        className={filterInputClass}
      />
    );
  };

  return (
    <div className={className}>
      {error && <div className="mb-4 rounded-2xl bg-red-50 p-4 text-sm text-red-700">{error}</div>}

      <p className="mb-3 text-xs text-slate-400">
        Preview data comes from a live test call to this endpoint and may be truncated to the
        first ~20KB of its response.
      </p>

      {appliedConditions.length > 0 && (
        <div className="mb-4 rounded-2xl border border-slate-200 bg-slate-50 p-4">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Filters</p>
            <div className="flex items-center gap-3">
              <p className="text-xs text-slate-500">
                Showing {filteredRows.length} of {rawRows.length} rows
              </p>
              {hasCustomFilterValues && (
                <button
                  type="button"
                  onClick={() => setLiveFilterValues({})}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-[#00796B] hover:underline"
                >
                  <RotateCcw size={12} />
                  Reset
                </button>
              )}
            </div>
          </div>

          <div className="flex flex-wrap items-end gap-3">
            {appliedConditions.map((cond) => {
              const needsValue = !FILTER_OPERATORS_WITHOUT_VALUE.includes(cond.operator);
              return (
                <div key={cond.id} className="flex items-end gap-2">
                  <label className="block">
                    <span className="block text-xs font-semibold text-slate-600">
                      {prettifyFieldName(cond.field)}
                    </span>
                    {needsValue ? (
                      <div className="mt-1">{renderFilterControl(cond)}</div>
                    ) : (
                      <span className="mt-1 flex h-10 items-center rounded-lg border border-slate-200 bg-white px-3 text-sm text-slate-500">
                        {FILTER_OPERATOR_LABELS[cond.operator]}
                      </span>
                    )}
                  </label>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <DataTable
        columns={columns}
        rows={filteredRows}
        loading={loading}
        getRowKey={(_, index) => index}
        searchable
        searchPlaceholder="Search results"
        emptyMessage="No data available."
        toolbarActions={
          <>
            <button
              type="button"
              onClick={() => void loadData()}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-semibold text-slate-700 transition hover:border-[#00796B] hover:text-[#00796B]"
            >
              <RefreshCcw size={14} />
              Refresh
            </button>
            {showExportCsv && (
              <button
                type="button"
                onClick={handleExportCsv}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-semibold text-slate-700 transition hover:border-[#00796B] hover:text-[#00796B]"
              >
                <Download size={14} />
                Export CSV
              </button>
            )}
          </>
        }
        toolbarExtra={
          lastRefreshedAt && (
            <span className="text-xs text-slate-500">Last refreshed at {lastRefreshedAt.toLocaleTimeString()}</span>
          )
        }
      />
    </div>
  );
}
