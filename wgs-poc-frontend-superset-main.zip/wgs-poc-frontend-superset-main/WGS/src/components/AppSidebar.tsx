import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  BarChart3,
  ChevronLeft,
  ChevronRight,
  LayoutDashboard,
  LogOut,
  MessageCircle,
  Plug,
  Search,
  Shield,
  UserPlus,
} from "lucide-react";
import wgslogo from "../assets/wgswhitelogo.svg";
import { getCurrentRole, logout } from "../utils/auth";

type AppSidebarProps = {
  active?: string;
  onDashboardClick?: () => void;
};

export default function AppSidebar({
  active,
  onDashboardClick,
}: AppSidebarProps) {
  const isAdmin = getCurrentRole() === "admin";
  const navigate = useNavigate();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(true);

  const navClass = (key: string) =>
    `flex w-full shrink-0 items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-semibold transition ${
      isCollapsed ? "justify-center" : "justify-start"
    } ${
      active === key
        ? "bg-white/10 text-[#46BEAA]"
        : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
    }`;

  return (
    <aside
      className={`flex h-full shrink-0 flex-col overflow-hidden bg-black px-6 py-6 transition-[width] duration-300 ease-in-out ${
        isCollapsed ? "w-24" : "w-72"
      }`}
    >
      <div
        className={`mb-6 flex shrink-0 items-center ${
          isCollapsed ? "justify-center" : "justify-between"
        }`}
      >
        {!isCollapsed && (
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#00796B]">
              <img src={wgslogo} alt="" className="h-5 w-8 object-contain" />
            </div>
            <div>
              <p className="text-sm font-semibold text-white">Worldline</p>
              <p className="text-xs text-slate-400">Data access</p>
            </div>
          </div>
        )}
        <button
          type="button"
          onClick={() => setIsCollapsed((v) => !v)}
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-white/5 text-slate-300 transition hover:bg-white/10"
          title={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {isCollapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
        </button>
      </div>

      <hr className="shrink-0 border-white/10" />

      <nav className="sidebar-scroll mt-4 min-h-0 flex-1 space-y-2 overflow-y-auto text-sm font-semibold">
        {onDashboardClick ? (
          <button
            type="button"
            onClick={onDashboardClick}
            title="Dashboard"
            className={navClass("dashboard")}
          >
            <LayoutDashboard size={20} />
            {!isCollapsed && <span>Dashboard</span>}
          </button>
        ) : (
          <Link to="/dashboard" title="Dashboard" className={navClass("dashboard")}>
            <LayoutDashboard size={20} />
            {!isCollapsed && <span>Dashboard</span>}
          </Link>
        )}

        <Link to="/templates" title="Reports" className={navClass("templates")}>
          <BarChart3 size={20} />
          {!isCollapsed && <span>Reports</span>}
        </Link>

        <Link to="/api-endpoints" title="API Endpoints" className={navClass("api-endpoints")}>
          <Plug size={20} />
          {!isCollapsed && <span>API Endpoints</span>}
        </Link>

        <Link to="/transactions" title="Transaction Search" className={navClass("transactions")}>
          <Search size={20} />
          {!isCollapsed && <span>Transaction Search</span>}
        </Link>

        <Link to="/chat-assistant" title="Chat Assistant" className={navClass("chat-assistant")}>
          <MessageCircle size={20} />
          {!isCollapsed && <span>Chat Assistant</span>}
        </Link>

        {isAdmin && (
          <>
            <button
              type="button"
              onClick={() => setIsAdminOpen((v) => !v)}
              title="Admin"
              className={`flex w-full shrink-0 items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-semibold text-slate-400 transition hover:bg-white/5 hover:text-slate-200 ${
                isCollapsed ? "justify-center" : "justify-start"
              }`}
            >
              <UserPlus size={20} />
              {!isCollapsed && <span>Admin</span>}
            </button>

            {!isCollapsed && isAdminOpen && (
              <div className="ml-4 space-y-1">
                <Link
                  to="/admin/users/new"
                  title="Users"
                  className={`flex items-center gap-3 rounded-xl px-4 py-1.5 text-sm transition ${
                    active === "admin-users"
                      ? "bg-white/10 text-[#46BEAA]"
                      : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
                  }`}
                >
                  <UserPlus size={18} />
                  <span>Users</span>
                </Link>
                <Link
                  to="/admin/roles"
                  title="Roles"
                  className={`flex items-center gap-3 rounded-xl px-4 py-1.5 text-sm transition ${
                    active === "admin-roles"
                      ? "bg-white/10 text-[#46BEAA]"
                      : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
                  }`}
                >
                  <Shield size={18} />
                  <span>Roles</span>
                </Link>
              </div>
            )}
          </>
        )}
      </nav>

      <hr className="my-3 shrink-0 border-white/10" />

      <button
        type="button"
        title="Logout"
        onClick={() => { logout(); navigate("/login"); }}
        className={`flex w-full shrink-0 items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold text-slate-400 transition hover:bg-white/5 hover:text-slate-200 ${
          isCollapsed ? "justify-center" : "justify-start"
        }`}
      >
        <LogOut size={20} />
        {!isCollapsed && <span>Logout</span>}
      </button>
    </aside>
  );
}
