import { useMemo, useState } from "react";
import { X } from "lucide-react";
import type { FilterFieldConfig, StructuredFilter } from "../../utils/filterFieldConfig";

type Props = {
  config: FilterFieldConfig;
  value: StructuredFilter | undefined;
  onChange: (filter: StructuredFilter | null) => void;
};

export default function SearchableFilter({ config, value, onChange }: Props) {
  const [query, setQuery] = useState("");
  const hasSuggestions = Boolean(config.distinctValues?.length);
  const selected = value?.operator === "IN" && Array.isArray(value.value) ? (value.value as string[]) : [];

  const suggestions = useMemo(() => {
    if (!hasSuggestions) return [];
    const lower = query.trim().toLowerCase();
    if (!lower) return [];
    return (config.distinctValues ?? [])
      .filter((v) => v.toLowerCase().includes(lower) && !selected.includes(v))
      .slice(0, 8);
  }, [config.distinctValues, hasSuggestions, query, selected]);

  if (!hasSuggestions) {
    const text = value?.operator === "LIKE" ? String(value.value) : "";
    return (
      <div>
        <input
          type="text"
          value={text}
          onChange={(event) => {
            const next = event.target.value;
            onChange(next.trim() ? { field: config.key, operator: "LIKE", value: next.trim() } : null);
          }}
          placeholder={`Type to filter by ${config.columnName}`}
          className="h-10 w-full rounded-lg border border-slate-300 px-3 text-sm text-slate-900 outline-none focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
        />
        <p className="mt-1 text-xs text-slate-400">Distinct values unavailable — filtering by partial text match.</p>
      </div>
    );
  }

  const addValue = (raw: string) => {
    const trimmed = raw.trim();
    if (!trimmed || selected.includes(trimmed)) {
      setQuery("");
      return;
    }
    onChange({ field: config.key, operator: "IN", value: [...selected, trimmed] });
    setQuery("");
  };

  const removeValue = (item: string) => {
    const next = selected.filter((v) => v !== item);
    onChange(next.length ? { field: config.key, operator: "IN", value: next } : null);
  };

  return (
    <div className="space-y-2">
      {selected.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {selected.map((item) => (
            <span
              key={item}
              className="inline-flex items-center gap-1 rounded-full bg-[#00796B]/10 px-2 py-1 text-xs font-medium text-[#00796B]"
            >
              {item}
              <button
                type="button"
                onClick={() => removeValue(item)}
                aria-label={`Remove ${item}`}
                className="rounded-full p-0.5 hover:bg-[#00796B]/20"
              >
                <X size={12} />
              </button>
            </span>
          ))}
        </div>
      )}
      <div className="relative">
        <input
          type="text"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder={`Search ${config.columnName}...`}
          className="h-10 w-full rounded-lg border border-slate-300 px-3 text-sm text-slate-900 outline-none focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
        />
        {suggestions.length > 0 && (
          <div className="absolute left-0 top-full z-10 mt-1 w-full rounded-lg border border-slate-200 bg-white shadow-lg">
            {suggestions.map((suggestion) => (
              <button
                key={suggestion}
                type="button"
                onClick={() => addValue(suggestion)}
                className="block w-full px-3 py-2 text-left text-sm text-slate-700 hover:bg-slate-50"
              >
                {suggestion}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
