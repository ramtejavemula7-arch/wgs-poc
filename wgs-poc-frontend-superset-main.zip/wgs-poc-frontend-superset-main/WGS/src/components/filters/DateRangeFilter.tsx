import { useState } from "react";
import type { FilterFieldConfig, StructuredFilter } from "../../utils/filterFieldConfig";

type Props = {
  config: FilterFieldConfig;
  value: StructuredFilter | undefined;
  onChange: (filter: StructuredFilter | null) => void;
};

type Preset = "last7" | "thisMonth" | "lastQuarter" | "custom";

const PRESETS: { key: Preset; label: string }[] = [
  { key: "last7", label: "Last 7 days" },
  { key: "thisMonth", label: "This month" },
  { key: "lastQuarter", label: "Last quarter" },
  { key: "custom", label: "Custom" },
];

function toISODate(date: Date) {
  return date.toISOString().slice(0, 10);
}

function computePresetRange(preset: Preset): [string, string] | null {
  const now = new Date();

  if (preset === "last7") {
    const start = new Date(now);
    start.setDate(start.getDate() - 6);
    return [toISODate(start), toISODate(now)];
  }

  if (preset === "thisMonth") {
    const start = new Date(now.getFullYear(), now.getMonth(), 1);
    return [toISODate(start), toISODate(now)];
  }

  if (preset === "lastQuarter") {
    const currentQuarterStartMonth = Math.floor(now.getMonth() / 3) * 3;
    const lastQuarterStartMonth = currentQuarterStartMonth - 3;
    const year = lastQuarterStartMonth < 0 ? now.getFullYear() - 1 : now.getFullYear();
    const month = (lastQuarterStartMonth + 12) % 12;
    const start = new Date(year, month, 1);
    const end = new Date(year, month + 3, 0);
    return [toISODate(start), toISODate(end)];
  }

  return null;
}

export default function DateRangeFilter({ config, value, onChange }: Props) {
  const [preset, setPreset] = useState<Preset>("custom");
  const range = Array.isArray(value?.value) ? (value.value as [string, string]) : ["", ""];

  const applyPreset = (nextPreset: Preset) => {
    setPreset(nextPreset);
    if (nextPreset === "custom") return;
    const computed = computePresetRange(nextPreset);
    if (computed) onChange({ field: config.key, operator: "BETWEEN", value: computed });
  };

  const updateCustomRange = (start: string, end: string) => {
    setPreset("custom");
    if (!start && !end) {
      onChange(null);
      return;
    }
    onChange({ field: config.key, operator: "BETWEEN", value: [start, end] });
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        {PRESETS.map((p) => (
          <button
            key={p.key}
            type="button"
            onClick={() => applyPreset(p.key)}
            className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
              preset === p.key ? "bg-[#00796B] text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
            }`}
          >
            {p.label}
          </button>
        ))}
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <input
          type="date"
          value={range[0] || ""}
          onChange={(event) => updateCustomRange(event.target.value, range[1] || "")}
          className="h-10 rounded-lg border border-slate-300 px-3 text-sm text-slate-900 outline-none focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
        />
        <span className="text-sm text-slate-400">to</span>
        <input
          type="date"
          value={range[1] || ""}
          onChange={(event) => updateCustomRange(range[0] || "", event.target.value)}
          className="h-10 rounded-lg border border-slate-300 px-3 text-sm text-slate-900 outline-none focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
        />
        {value ? (
          <button
            type="button"
            onClick={() => {
              setPreset("custom");
              onChange(null);
            }}
            className="text-xs font-semibold text-slate-500 hover:text-red-600"
          >
            Clear
          </button>
        ) : null}
      </div>
    </div>
  );
}
