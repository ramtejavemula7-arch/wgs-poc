import type { FilterFieldConfig, StructuredFilter } from "../../utils/filterFieldConfig";

type Props = {
  config: FilterFieldConfig;
  value: StructuredFilter | undefined;
  onChange: (filter: StructuredFilter | null) => void;
};

export default function MultiSelectFilter({ config, value, onChange }: Props) {
  const selected = Array.isArray(value?.value) ? (value.value as string[]) : [];
  const options = config.distinctValues ?? [];

  const toggle = (option: string) => {
    const next = selected.includes(option) ? selected.filter((v) => v !== option) : [...selected, option];
    onChange(next.length ? { field: config.key, operator: "IN", value: next } : null);
  };

  return (
    <div className="flex max-h-40 flex-wrap gap-2 overflow-auto rounded-lg border border-slate-200 p-3">
      {options.length ? (
        options.map((option) => (
          <label
            key={option}
            className={`flex cursor-pointer items-center gap-2 rounded-lg px-2 py-1 text-sm transition ${
              selected.includes(option) ? "bg-[#00796B]/10 text-[#00796B]" : "text-slate-600 hover:bg-slate-50"
            }`}
          >
            <input
              type="checkbox"
              checked={selected.includes(option)}
              onChange={() => toggle(option)}
              className="h-4 w-4 rounded border-slate-300 text-[#00796B] focus:ring-[#00796B]"
            />
            {option}
          </label>
        ))
      ) : (
        <p className="text-sm text-slate-400">No values available.</p>
      )}
    </div>
  );
}
