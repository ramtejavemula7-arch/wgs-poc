import { useEffect, useMemo, useState } from "react";
import { Loader2, Search } from "lucide-react";
import LogoSpinner from "../LogoSpinner";
import { apiFetch } from "../../utils/api";
import { API } from "../../utils/api-endpoints";
import {
  pickRecommendedKeys,
  useColumnFilterConfigs,
  type FilterFieldConfig,
  type SchemaColumn,
  type StructuredFilter,
} from "../../utils/filterFieldConfig";
import { formatCurrencyValue, type CurrencyCode } from "../../utils/currencyFormat";
import DateRangeFilter from "./DateRangeFilter";
import MultiSelectFilter from "./MultiSelectFilter";
import SearchableFilter from "./SearchableFilter";
import RangeFilter from "./RangeFilter";
import ToggleFilter from "./ToggleFilter";

const PREVIEW_DEBOUNCE_MS = 400;
const LARGE_RESULT_THRESHOLD = 50_000;
const PREVIEW_ROW_LIMIT = 100;
const PREVIEW_COLUMN_CAP = 8;

type Props = {
  datasetId: string | number | null;
  columns: SchemaColumn[];
  columnsLoading: boolean;
  filters: StructuredFilter[];
  onChange: (filters: StructuredFilter[]) => void;
  /** Shows the record-count + first-100-rows preview. Defaults to on (existing Transaction flow
   *  behavior); pass false where the caller already has its own preview (e.g. the Matrix Builder's
   *  Live Preview) to avoid a redundant fetch and a confusing second table. */
  showPreview?: boolean;
  /** Per-column currency format (keyed by column_name), applied to numeric cells in the preview table. */
  columnFormats?: Record<string, CurrencyCode>;
};

function renderControl(
  config: FilterFieldConfig,
  current: StructuredFilter | undefined,
  onFieldChange: (next: StructuredFilter | null) => void
) {
  switch (config.fieldType) {
    case "date":
      return <DateRangeFilter config={config} value={current} onChange={onFieldChange} />;
    case "numeric":
      return <RangeFilter config={config} value={current} onChange={onFieldChange} />;
    case "boolean":
      return <ToggleFilter config={config} value={current} onChange={onFieldChange} />;
    case "categorical":
      return <MultiSelectFilter config={config} value={current} onChange={onFieldChange} />;
    default:
      return <SearchableFilter config={config} value={current} onChange={onFieldChange} />;
  }
}

export default function FilterBuilder({
  datasetId,
  columns,
  columnsLoading,
  filters,
  onChange,
  showPreview = true,
  columnFormats,
}: Props) {
  const { configs, loading: configsLoading } = useColumnFilterConfigs(datasetId, columns);
  const [moreOpen, setMoreOpen] = useState(false);
  const [moreSearch, setMoreSearch] = useState("");

  const recommendedKeys = useMemo(() => pickRecommendedKeys(configs), [configs]);
  const recommended = configs.filter((c) => recommendedKeys.includes(c.key));
  const rest = configs
    .filter((c) => !recommendedKeys.includes(c.key))
    .filter((c) => c.columnName.toLowerCase().includes(moreSearch.trim().toLowerCase()));

  const setFilter = (field: string, next: StructuredFilter | null) => {
    const withoutField = filters.filter((f) => f.field !== field);
    onChange(next ? [...withoutField, next] : withoutField);
  };

  const [previewLoading, setPreviewLoading] = useState(false);
  const [recordCount, setRecordCount] = useState<number | null>(null);
  const [previewRows, setPreviewRows] = useState<Record<string, unknown>[]>([]);
  const [previewColumns, setPreviewColumns] = useState<string[]>([]);
  const [previewError, setPreviewError] = useState<string | null>(null);

  useEffect(() => {
    if (!showPreview || !datasetId || !columns.length) return;

    const timer = setTimeout(async () => {
      setPreviewLoading(true);
      setPreviewError(null);

      try {
        const columnNames = columns.map((c) => c.column_name).filter((v): v is string => Boolean(v));
        const cappedColumns = columnNames.slice(0, PREVIEW_COLUMN_CAP);

        const resp = await apiFetch(API.superset.datasetQuery(datasetId), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            columns: columnNames,
            filters: filters.map((f) => ({ col: f.field, op: f.operator, val: f.value })),
            row_limit: PREVIEW_ROW_LIMIT,
            row_offset: 0,
          }),
        });

        if (!resp.ok) {
          const text = await resp.text();
          throw new Error(text || "Unable to preview filtered data.");
        }

        const data = await resp.json();
        const rows = Array.isArray(data.rows) ? data.rows : [];
        setPreviewRows(rows);
        setPreviewColumns(cappedColumns);
        setRecordCount(typeof data.total === "number" ? data.total : rows.length);
      } catch (err) {
        setPreviewError(err instanceof Error ? err.message : "Unable to preview filtered data.");
      } finally {
        setPreviewLoading(false);
      }
    }, PREVIEW_DEBOUNCE_MS);

    return () => clearTimeout(timer);
  }, [datasetId, columns, filters, showPreview]);

  if (columnsLoading || configsLoading) {
    return (
      <div className="flex min-h-[240px] items-center justify-center rounded-3xl border border-slate-200 bg-slate-50 text-sm font-medium text-slate-500">
        <LogoSpinner className="mr-2 h-5 w-5" /> Analyzing columns...
      </div>
    );
  }

  if (!configs.length) {
    return (
      <div className="rounded-3xl border border-dashed border-slate-300 bg-slate-50 p-12 text-center text-sm font-medium text-slate-500">
        No filterable columns found for this dataset.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <p className="mb-3 text-sm font-semibold text-slate-700">Recommended filters</p>
        <div className="grid gap-4 md:grid-cols-2">
          {recommended.map((config) => (
            <div key={config.key} className="rounded-2xl border border-slate-200 bg-white p-4">
              <p className="mb-2 text-sm font-semibold text-slate-900">{config.columnName}</p>
              {renderControl(config, filters.find((f) => f.field === config.key), (next) => setFilter(config.key, next))}
            </div>
          ))}
        </div>
      </div>

      {configs.length > recommended.length && (
        <div className="rounded-2xl border border-slate-200">
          <button
            type="button"
            onClick={() => setMoreOpen((v) => !v)}
            className="flex w-full items-center justify-between px-4 py-3 text-sm font-semibold text-slate-700"
          >
            More filters ({configs.length - recommended.length})
            <span>{moreOpen ? "−" : "+"}</span>
          </button>
          {moreOpen && (
            <div className="space-y-4 border-t border-slate-200 p-4">
              <div className="relative">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={moreSearch}
                  onChange={(event) => setMoreSearch(event.target.value)}
                  placeholder="Search fields..."
                  className="h-10 w-full rounded-lg border border-slate-300 pl-9 pr-3 text-sm text-slate-900 outline-none focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
                />
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                {rest.map((config) => (
                  <div key={config.key} className="rounded-2xl border border-slate-200 bg-white p-4">
                    <p className="mb-2 text-sm font-semibold text-slate-900">{config.columnName}</p>
                    {renderControl(config, filters.find((f) => f.field === config.key), (next) => setFilter(config.key, next))}
                  </div>
                ))}
                {!rest.length && <p className="text-sm text-slate-400">No matching fields.</p>}
              </div>
            </div>
          )}
        </div>
      )}

      {!showPreview && filters.length > 0 ? (
        <div className="flex justify-end">
          <button
            type="button"
            onClick={() => onChange([])}
            className="text-xs font-semibold text-slate-500 hover:text-red-600"
          >
            Clear all filters
          </button>
        </div>
      ) : null}

      {showPreview ? (
        <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="text-sm text-slate-600">
              {previewLoading ? (
                <span className="inline-flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" /> Updating preview...
                </span>
              ) : recordCount !== null ? (
                <>
                  Matches <span className="font-semibold text-slate-900">{recordCount.toLocaleString()}</span> record
                  {recordCount === 1 ? "" : "s"}
                </>
              ) : (
                "Adjust filters to preview matching records."
              )}
            </p>
            {filters.length > 0 && (
              <button
                type="button"
                onClick={() => onChange([])}
                className="text-xs font-semibold text-slate-500 hover:text-red-600"
              >
                Clear all filters
              </button>
            )}
          </div>

          {recordCount !== null && recordCount > LARGE_RESULT_THRESHOLD && (
            <div className="mt-3 rounded-lg bg-amber-50 px-3 py-2 text-xs font-medium text-amber-800">
              This selection matches over {LARGE_RESULT_THRESHOLD.toLocaleString()} records. Consider narrowing your
              filters for faster report generation.
            </div>
          )}

          {previewError && (
            <div className="mt-3 rounded-lg bg-red-50 px-3 py-2 text-xs font-medium text-red-700">{previewError}</div>
          )}
        </div>
      ) : null}

      {showPreview && previewRows.length > 0 && (
        <div>
          <p className="mb-2 text-sm font-semibold text-slate-700">Preview (first {previewRows.length} rows)</p>
          <div className="max-h-72 overflow-auto rounded-2xl border border-slate-200">
            <table className="min-w-full text-left text-sm">
              <thead className="sticky top-0 bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                <tr>
                  {previewColumns.map((col) => (
                    <th key={col} className="whitespace-nowrap px-4 py-2">
                      {col}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {previewRows.map((row, index) => (
                  <tr key={index}>
                    {previewColumns.map((col) => {
                      const value = row[col];
                      if (value === null || value === undefined) {
                        return (
                          <td key={col} className="whitespace-nowrap px-4 py-2 text-slate-600">
                            -
                          </td>
                        );
                      }
                      const currency = columnFormats?.[col];
                      const formatted = currency ? formatCurrencyValue(value, currency) : null;
                      return (
                        <td key={col} className="whitespace-nowrap px-4 py-2 text-slate-600">
                          {formatted ?? String(value)}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
