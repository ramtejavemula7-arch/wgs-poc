import type { FilterFieldConfig, StructuredFilter } from "../../utils/filterFieldConfig";

type Props = {
  config: FilterFieldConfig;
  value: StructuredFilter | undefined;
  onChange: (filter: StructuredFilter | null) => void;
};

type Choice = "all" | "yes" | "no";

export default function ToggleFilter({ config, value, onChange }: Props) {
  const choice: Choice = value === undefined ? "all" : value.value === true ? "yes" : "no";

  const select = (next: Choice) => {
    if (next === "all") {
      onChange(null);
      return;
    }
    onChange({ field: config.key, operator: "EQ", value: next === "yes" });
  };

  return (
    <div className="flex gap-1 rounded-lg bg-slate-100 p-1">
      {(["all", "yes", "no"] as Choice[]).map((option) => (
        <button
          key={option}
          type="button"
          onClick={() => select(option)}
          className={`flex-1 rounded-md px-3 py-2 text-xs font-semibold capitalize transition ${
            choice === option ? "bg-[#00796B] text-white" : "text-slate-600 hover:bg-white"
          }`}
        >
          {option}
        </button>
      ))}
    </div>
  );
}
