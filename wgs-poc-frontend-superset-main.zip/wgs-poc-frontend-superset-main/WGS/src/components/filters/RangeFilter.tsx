import type { FilterFieldConfig, StructuredFilter } from "../../utils/filterFieldConfig";

type Props = {
  config: FilterFieldConfig;
  value: StructuredFilter | undefined;
  onChange: (filter: StructuredFilter | null) => void;
};

export default function RangeFilter({ config, value, onChange }: Props) {
  const bounds = { min: config.min ?? 0, max: config.max ?? 100 };
  const [currentMin, currentMax] = Array.isArray(value?.value)
    ? (value.value as [number, number])
    : [bounds.min, bounds.max];

  const update = (nextMin: number, nextMax: number) => {
    if (nextMin <= bounds.min && nextMax >= bounds.max) {
      onChange(null);
      return;
    }
    onChange({ field: config.key, operator: "BETWEEN", value: [nextMin, nextMax] });
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        <input
          type="number"
          value={currentMin}
          min={bounds.min}
          max={currentMax}
          onChange={(event) => update(Number(event.target.value), currentMax)}
          className="h-10 w-28 rounded-lg border border-slate-300 px-3 text-sm text-slate-900 outline-none focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
        />
        <span className="text-sm text-slate-400">to</span>
        <input
          type="number"
          value={currentMax}
          min={currentMin}
          max={bounds.max}
          onChange={(event) => update(currentMin, Number(event.target.value))}
          className="h-10 w-28 rounded-lg border border-slate-300 px-3 text-sm text-slate-900 outline-none focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20"
        />
      </div>
      <div className="flex items-center gap-2">
        <input
          type="range"
          min={bounds.min}
          max={bounds.max}
          value={currentMin}
          onChange={(event) => update(Number(event.target.value), currentMax)}
          className="w-full accent-[#00796B]"
        />
        <input
          type="range"
          min={bounds.min}
          max={bounds.max}
          value={currentMax}
          onChange={(event) => update(currentMin, Number(event.target.value))}
          className="w-full accent-[#00796B]"
        />
      </div>
      <p className="text-xs text-slate-400">
        Available range: {bounds.min} – {bounds.max}
      </p>
    </div>
  );
}
