import type { ReactNode } from "react";
import AppSidebar from "./AppSidebar";
import wgslogo from "../assets/wgslogo.png";

type SidebarLayoutProps = {
  active?: string;
  onDashboardClick?: () => void;
  contentClassName?: string;
  children: ReactNode;
};

export default function SidebarLayout({
  active,
  onDashboardClick,
  contentClassName = "p-8",
  children,
}: SidebarLayoutProps) {
  return (
    <main className="min-h-screen bg-white print:min-h-0 print:bg-white">
      <section className="flex h-screen w-full overflow-hidden bg-white bg-[radial-gradient(1500px_800px_at_15%_0%,rgba(70,190,170,0.22),transparent_75%),radial-gradient(1300px_900px_at_100%_100%,rgba(250,204,21,0.16),transparent_75%),radial-gradient(1000px_700px_at_0%_100%,rgba(70,190,170,0.14),transparent_75%)] print:block print:h-auto print:overflow-visible print:bg-white print:bg-none">
        <div className="contents print:hidden">
          <AppSidebar
            active={active}
            onDashboardClick={onDashboardClick}
          />
        </div>
        <img
          src={wgslogo}
          alt=""
          aria-hidden="true"
          className="pointer-events-none fixed left-1/2 top-1/2 z-0 h-80 w-80 -translate-x-1/2 -translate-y-1/2 object-contain opacity-[0.09] print:hidden"
        />
        <div className={`page-enter relative z-10 flex-1 overflow-auto print:overflow-visible ${contentClassName}`}>
          {children}
        </div>
      </section>
    </main>
  );
}
