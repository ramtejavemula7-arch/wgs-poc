import { useEffect, useRef, useState, type ChangeEvent, type FormEvent, type KeyboardEvent } from "react";
import { Bot, Info, MessageCircle, Minus, Send, User, X } from "lucide-react";
import { apiFetch } from "../utils/api";
import { API } from "../utils/api-endpoints";

type AgentType = "dashboard" | "reports" | "transactions" | "users" | "roles" | "rest_endpoints";

interface PageChatbotProps {
  agentType: AgentType;
  pageData: object;
}

type TextBlock = {
  type: "text";
  text?: string;
  content?: string;
};

type TableBlock = {
  type: "table";
  headers?: string[];
  columns?: string[];
  rows?: Array<Array<string | number>> | Array<Record<string, string | number>>;
};

type ChatBlock = TextBlock | TableBlock;

type PageChatResponse = {
  message: string;
  found_in_page_data: boolean;
  blocks?: ChatBlock[];
};

type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
  blocks?: ChatBlock[];
  foundInPageData?: boolean;
  isError?: boolean;
};

const MAX_QUESTION_LENGTH = 2000;

const AGENT_LABELS: Record<AgentType, string> = {
  dashboard: "Ask about this dashboard",
  reports: "Ask about these reports",
  transactions: "Ask about these transactions",
  users: "Ask about these users",
  roles: "Ask about these roles",
  rest_endpoints: "Ask about this endpoint",
};

function createMessageId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

function getTableRows(block: TableBlock, headers: string[]): (string | number)[][] {
  const rows = block.rows ?? [];
  if (!rows.length) return [];

  if (Array.isArray(rows[0])) {
    return rows as (string | number)[][];
  }

  return (rows as Array<Record<string, string | number>>).map((row) =>
    headers.map((header) => row[header] ?? "")
  );
}

function TableBlockView({ block }: { block: TableBlock }) {
  const rows = block.rows ?? [];
  const firstRow = rows[0];
  const headers =
    block.headers ??
    block.columns ??
    (firstRow && !Array.isArray(firstRow) ? Object.keys(firstRow) : []);

  const tableRows = getTableRows(block, headers);

  if (!headers.length || !tableRows.length) return null;

  return (
    <div className="mt-2 overflow-x-auto rounded-lg border border-slate-200">
      <table className="min-w-full divide-y divide-slate-200 text-left text-[11px]">
        <thead className="bg-slate-50 text-[10px] uppercase tracking-wide text-slate-500">
          <tr>
            {headers.map((header) => (
              <th key={header} className="px-2 py-1.5 font-semibold">
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 bg-white">
          {tableRows.map((row, rowIndex) => (
            <tr key={rowIndex}>
              {row.map((cell, cellIndex) => (
                <td key={cellIndex} className="px-2 py-1.5 text-slate-700">
                  {String(cell)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function PageChatbot({ agentType, pageData }: PageChatbotProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isLoading, isOpen]);

  const askQuestion = async (rawQuestion: string) => {
    const question = rawQuestion.trim();
    if (!question || question.length > MAX_QUESTION_LENGTH || isLoading) return;

    setMessages((prev) => [...prev, { id: createMessageId(), role: "user", content: question }]);
    setInput("");
    if (textareaRef.current) textareaRef.current.style.height = "auto";
    setIsLoading(true);

    try {
      const resp = await apiFetch(API.pageChat.ask, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ agentType, pageData, question }),
        timeout: 90_000, // LLM responses legitimately take longer than the 30s default.
      });

      if (!resp.ok) {
        setMessages((prev) => [
          ...prev,
          { id: createMessageId(), role: "assistant", content: "Something went wrong, try again.", isError: true },
        ]);
        return;
      }

      const data = (await resp.json()) as PageChatResponse;
      setMessages((prev) => [
        ...prev,
        {
          id: createMessageId(),
          role: "assistant",
          content: data.message,
          blocks: data.blocks,
          foundInPageData: data.found_in_page_data,
        },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        { id: createMessageId(), role: "assistant", content: "Something went wrong, try again.", isError: true },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    void askQuestion(input);
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      void askQuestion(input);
    }
  };

  const handleInputChange = (event: ChangeEvent<HTMLTextAreaElement>) => {
    setInput(event.target.value);
    const el = event.target;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 120)}px`;
  };

  const canSend = input.trim().length > 0 && input.trim().length <= MAX_QUESTION_LENGTH && !isLoading;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-0 print:hidden">
      {isOpen && (
        <div
          className={`flex w-[360px] max-w-[calc(100vw-3rem)] flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl ${
            isMinimized ? "h-auto" : "h-[520px]"
          }`}
        >
          <div className="flex items-center justify-between bg-[#00796B] px-4 py-3 text-white">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white/15">
                <Bot size={16} />
              </div>
              <div>
                <p className="text-sm font-semibold">Chat Assistant</p>
                <p className="text-[11px] text-white/70">{AGENT_LABELS[agentType]}</p>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setIsMinimized((v) => !v)}
                className="flex h-7 w-7 items-center justify-center rounded-full text-white/80 transition hover:bg-white/15 hover:text-white"
                title={isMinimized ? "Expand chat" : "Minimize chat"}
              >
                <Minus size={16} />
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsOpen(false);
                  setIsMinimized(false);
                }}
                className="flex h-7 w-7 items-center justify-center rounded-full text-white/80 transition hover:bg-white/15 hover:text-white"
                title="Close chat"
              >
                <X size={16} />
              </button>
            </div>
          </div>

          {!isMinimized && (
          <div className="flex-1 overflow-y-auto bg-slate-50 px-3 py-4">
            {messages.length === 0 ? (
              <div className="flex h-full flex-col items-center justify-center px-4 text-center">
                <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-[#00796B]/10 text-[#00796B]">
                  <Bot size={22} />
                </div>
                <p className="text-sm font-semibold text-slate-800">{AGENT_LABELS[agentType]}</p>
                <p className="mt-1 text-xs text-slate-500">
                  Only answers using the data currently shown on this page.
                </p>
              </div>
            ) : (
              <div className="flex flex-col gap-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex items-start gap-2 ${
                      message.role === "user" ? "flex-row-reverse" : "flex-row"
                    }`}
                  >
                    <div
                      className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full ${
                        message.role === "user"
                          ? "bg-slate-700 text-white"
                          : "bg-[#00796B]/10 text-[#00796B]"
                      }`}
                    >
                      {message.role === "user" ? <User size={12} /> : <Bot size={12} />}
                    </div>

                    <div
                      className={`max-w-[82%] whitespace-pre-wrap rounded-2xl px-3 py-2 text-[13px] leading-relaxed shadow-sm ${
                        message.role === "user"
                          ? "rounded-tr-sm bg-[#00796B] text-white"
                          : message.isError
                            ? "rounded-tl-sm border border-red-200 bg-red-50 text-red-700"
                            : message.foundInPageData === false
                              ? "rounded-tl-sm border border-amber-200 bg-amber-50 text-amber-800"
                              : "rounded-tl-sm border border-slate-200 bg-white text-slate-800"
                      }`}
                    >
                      {message.role === "assistant" && message.foundInPageData === false && (
                        <div className="mb-1 flex items-center gap-1 text-[11px] font-semibold uppercase tracking-wide text-amber-600">
                          <Info size={12} />
                          Not in this page's data
                        </div>
                      )}

                      {message.content}

                      {message.blocks?.map((block, index) =>
                        block.type === "table" ? (
                          <TableBlockView key={index} block={block} />
                        ) : (
                          (block.text || block.content) && (
                            <p key={index} className="mt-2 whitespace-pre-wrap">
                              {block.text || block.content}
                            </p>
                          )
                        )
                      )}
                    </div>
                  </div>
                ))}

                {isLoading && (
                  <div className="flex items-start gap-2">
                    <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#00796B]/10 text-[#00796B]">
                      <Bot size={12} />
                    </div>
                    <div className="flex items-center gap-1 rounded-2xl rounded-tl-sm border border-slate-200 bg-white px-3 py-2.5 shadow-sm">
                      <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-slate-400 [animation-delay:-0.3s]" />
                      <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-slate-400 [animation-delay:-0.15s]" />
                      <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-slate-400" />
                    </div>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>
            )}
          </div>
          )}

          {!isMinimized && (
          <form onSubmit={handleSubmit} className="flex items-end gap-2 border-t border-slate-200 bg-white p-3">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              placeholder="Ask about this page..."
              rows={1}
              disabled={isLoading}
              maxLength={MAX_QUESTION_LENGTH}
              className="max-h-28 flex-1 resize-none rounded-xl border border-slate-300 px-3 py-2 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-[#00796B] focus:ring-2 focus:ring-[#00796B]/20 disabled:bg-slate-50"
            />
            <button
              type="submit"
              disabled={!canSend}
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#00796B] text-white transition hover:bg-[#00695C] disabled:cursor-not-allowed disabled:opacity-40"
              title="Send message"
            >
              <Send size={15} />
            </button>
          </form>
          )}
        </div>
      )}

      {!isOpen && (
        <button
          type="button"
          onClick={() => setIsOpen(true)}
          className="flex h-14 w-14 items-center justify-center rounded-full bg-[#00796B] text-white shadow-lg shadow-black/20 transition hover:scale-105 hover:bg-[#00695C]"
          title="Open chat"
        >
          <MessageCircle size={24} />
        </button>
      )}
    </div>
  );
}
