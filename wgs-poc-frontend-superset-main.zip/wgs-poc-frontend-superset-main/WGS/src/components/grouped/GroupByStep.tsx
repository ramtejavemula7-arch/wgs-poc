import DimensionPicker, { type FieldOption } from "../metrics/DimensionPicker";

type Props = {
  /** Every currently-selected report column, pickable as a group-by field. */
  fields: FieldOption[];
  /** The ordered group-by hierarchy (a prefix of the report's columns). */
  selected: string[];
  onChange: (next: string[]) => void;
};

/** Lets the user promote already-selected columns into an ordered group-by hierarchy. */
export default function GroupByStep({ fields, selected, onChange }: Props) {
  const available = fields.filter((f) => !selected.includes(f.columnName));

  const add = (field: FieldOption) => {
    onChange([...selected, field.columnName]);
  };

  return (
    <div className="grid gap-6 lg:grid-cols-[260px_1fr]">
      <div>
        <p className="mb-2 text-sm font-semibold text-slate-700">Selected columns</p>
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          {available.length ? (
            <div className="flex flex-col gap-1.5">
              {available.map((field) => (
                <button
                  key={field.columnName}
                  type="button"
                  onClick={() => add(field)}
                  title={`Group by ${field.label}`}
                  className="flex items-center justify-between rounded-lg border border-slate-200 bg-white px-3 py-2 text-left text-sm text-slate-700 transition hover:border-[#00796B] hover:text-[#00796B]"
                >
                  {field.label}
                  <span className="text-xs font-semibold">+ Group</span>
                </button>
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-400">
              {fields.length
                ? "All selected columns are already grouped."
                : "Go back and select columns first."}
            </p>
          )}
        </div>
      </div>

      <div>
        <p className="mb-2 text-sm font-semibold text-slate-700">Group by (in order)</p>
        <DimensionPicker fields={fields} selected={selected} onChange={onChange} />
      </div>
    </div>
  );
}
