import LogoSpinner from "../LogoSpinner";
import { prettifyFieldLabel } from "../../utils/metricsFieldClassification";
import type { GroupedRow } from "../../utils/useGroupedQuery";
import { formatCurrencyValue, type CurrencyCode } from "../../utils/currencyFormat";

type Props = {
  columns: string[];
  dimensions: string[];
  totalColumns: string[];
  rows: GroupedRow[];
  rowSpans: number[][];
  grandTotal: Record<string, number>;
  loading: boolean;
  error: string | null;
  /** Per-column currency format (keyed the same as `columns`), applied to numeric cells. */
  columnFormats?: Record<string, CurrencyCode>;
};

function formatCell(value: unknown, currency?: CurrencyCode): string {
  if (value === null || value === undefined || value === "") return "-";
  if (currency) {
    const formatted = formatCurrencyValue(value, currency);
    if (formatted !== null) return formatted;
  }
  return String(value);
}

/**
 * Row-level detail rows, sorted by `dimensions`, with each dimension column merged (rowSpan)
 * across contiguous equal-value runs, plus a single Grand Total row pinned under the header.
 * This mirrors exactly what the backend's /export/pdf and /export/excel produce for a
 * "grouped" template — an Excel PivotTable-style tabular layout with subtotals turned off.
 */
export default function GroupedPreviewTable({
  columns,
  dimensions,
  totalColumns,
  rows,
  rowSpans,
  grandTotal,
  loading,
  error,
  columnFormats,
}: Props) {
  if (loading) {
    return (
      <div className="flex min-h-[160px] items-center justify-center text-sm font-medium text-slate-500">
        <LogoSpinner className="mr-2 h-5 w-5" /> Loading preview...
      </div>
    );
  }

  if (error) {
    return <div className="rounded-2xl bg-red-50 p-4 text-sm text-red-700">{error}</div>;
  }

  if (!columns.length) {
    return <p className="p-6 text-sm text-slate-400">No columns selected.</p>;
  }

  const detailColumns = columns.filter((c) => !dimensions.includes(c));

  return (
    <div className="overflow-x-auto rounded-2xl border border-slate-200">
      <table className="w-full text-sm">
        <thead>
          <tr className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
            {columns.map((col) => (
              <th key={col} className="whitespace-nowrap px-4 py-3 text-left">
                {prettifyFieldLabel(col)}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          <tr className="bg-slate-100 font-semibold text-slate-900">
            <td
              colSpan={Math.max(dimensions.length, 1)}
              className="whitespace-nowrap border-b border-slate-200 px-4 py-3"
            >
              Grand Total
            </td>
            {detailColumns.slice(dimensions.length > 0 ? 0 : 1).map((col) => {
              const currency = columnFormats?.[col];
              const total = grandTotal[col] ?? 0;
              const formattedTotal = currency ? formatCurrencyValue(total, currency) : null;
              return (
                <td key={col} className="whitespace-nowrap border-b border-slate-200 px-4 py-3">
                  {totalColumns.includes(col) ? formattedTotal ?? total.toLocaleString() : ""}
                </td>
              );
            })}
          </tr>

          {rows.length ? (
            rows.map((row, rowIndex) => (
              <tr key={rowIndex} className={rowIndex % 2 === 0 ? "bg-white" : "bg-slate-50"}>
                {dimensions.map((dim, dimIndex) => {
                  const span = rowSpans[dimIndex]?.[rowIndex] ?? 1;
                  if (span === 0) return null;
                  return (
                    <td
                      key={dim}
                      rowSpan={span}
                      className="whitespace-nowrap border-b border-slate-200 px-4 py-3 align-top font-medium text-slate-900"
                    >
                      {formatCell(row[dim])}
                    </td>
                  );
                })}
                {detailColumns.map((col) => (
                  <td key={col} className="whitespace-nowrap border-b border-slate-200 px-4 py-3 text-slate-700">
                    {formatCell(row[col], columnFormats?.[col])}
                  </td>
                ))}
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={columns.length} className="px-4 py-10 text-center text-slate-400">
                No preview rows available yet.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
