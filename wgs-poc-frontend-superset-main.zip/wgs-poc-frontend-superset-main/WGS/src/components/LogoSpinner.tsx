import wgslogo from "../assets/wgslogo.png";

type Props = {
  /** Controls the overall box size (and any margin), e.g. "h-5 w-5" or "mr-2 h-5 w-5". */
  className?: string;
  /** Ring border thickness in px — bump this up for larger loaders. */
  thickness?: number;
};

/** The app's branded loading spinner — a rotating ring around the Worldline mark.
 *  Used in place of a plain Loader2 icon for every full section/page loading state. */
export default function LogoSpinner({ className = "h-5 w-5", thickness = 2 }: Props) {
  return (
    <span className={`relative inline-flex shrink-0 items-center justify-center ${className}`}>
      <span
        className="absolute inset-0 animate-spin rounded-full border-slate-200 border-t-[#00796B]"
        style={{ borderWidth: thickness }}
      />
      <img src={wgslogo} alt="" aria-hidden="true" className="h-1/2 w-1/2 object-contain" />
    </span>
  );
}
