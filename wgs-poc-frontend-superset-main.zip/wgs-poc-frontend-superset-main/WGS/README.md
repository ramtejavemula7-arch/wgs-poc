# WGS Superset Frontend

React + TypeScript + Vite frontend with an embedded Superset dashboard.

## Prerequisites

- Node.js 20+ and npm
- Access to the backend API and a Superset instance with embedding enabled

## Setup

1. Install dependencies:
   ```
   npm install
   ```
2. Create your local environment file:
   ```
   cp .env.example .env
   ```
   Then fill in `.env`:
   - `VITE_API_BASE_URL` — backend API base URL (no trailing slash)
   - `VITE_SUPERSET_DOMAIN` — Superset host serving the embedded dashboard

## Running the app

Start the dev server (with hot reload):
```
npm run dev
```
The app runs at the URL Vite prints (default `http://localhost:5173`).

## Other scripts

- `npm run build` — type-check and build for production (output in `dist/`)
- `npm run preview` — serve the production build locally
- `npm run lint` — run Oxlint

## Docker

A `Dockerfile` and `nginx.conf` are provided at the repo root for building a production container image.
