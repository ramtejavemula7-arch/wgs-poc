# Superset embed example (FastAPI)

This is an example FastAPI endpoint you can add to your separate Python backend. It accepts a `dashboard_uuid` and optional `guest_id`, then returns an `embed_url` suitable for use in an iframe.

This example uses environment variables:

- `SUPERSET_BASE` (e.g. `https://superset.example.com`)
- `SUPERSET_USER`
- `SUPERSET_PASS`

Adjust endpoints/paths to match your Superset version and auth setup — this is an example and may require small tweaks for your Superset deployment.

```py
# backend/superset_embed_example.py
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import os
import requests

class Payload(BaseModel):
    dashboard_uuid: str
    guest_id: str | None = None

app = FastAPI()

SUPERSET_BASE = os.environ.get("SUPERSET_BASE") or "https://superset.example.com"
SUPERSET_USER = os.environ.get("SUPERSET_USER")
SUPERSET_PASS = os.environ.get("SUPERSET_PASS")

@app.post("http://localhost:8000/api/superset/embed")
def get_embed(p: Payload):
    if not SUPERSET_USER or not SUPERSET_PASS:
        raise HTTPException(status_code=500, detail="Superset credentials not configured")

    try:
        # Start a session and attempt to authenticate. Depending on your Superset setup
        # you may need to use the API login endpoint or a cookie-based login flow.
        s = requests.Session()

        # Try API login (may vary depending on Superset version and config)
        login_url = f"{SUPERSET_BASE}/api/v1/security/login"
        login_resp = s.post(login_url, json={"username": SUPERSET_USER, "password": SUPERSET_PASS, "provider": "db"})

        # If login succeeded, try guest token endpoint (if enabled on your Superset)
        if login_resp.ok:
            guest_url = f"{SUPERSET_BASE}/api/v1/security/guest_token"
            payload = {
                "resources": [{"type": "dashboard", "id": p.dashboard_uuid}],
                "user": {"username": SUPERSET_USER}
            }
            if p.guest_id:
                payload["user"]["id"] = p.guest_id

            r = s.post(guest_url, json=payload)
            if r.ok:
                token = r.json().get("token")
                embed = f"{SUPERSET_BASE}/superset/dashboard/{p.dashboard_uuid}/?standalone=1&guest_token={token}"
                return {"embed_url": embed}

        # Fallback: return the dashboard URL (may require auth in browser)
        embed = f"{SUPERSET_BASE}/superset/dashboard/{p.dashboard_uuid}/?standalone=1"
        return {"embed_url": embed}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
```

Run with:

```bash
export SUPERSET_BASE=https://your-superset
export SUPERSET_USER=alice
export SUPERSET_PASS=secret
uvicorn backend.superset_embed_example:app --reload --port 8000
```

Notes:
- If your Superset requires csrf tokens or a different login path, adapt the login flow accordingly.
- If you have a reverse proxy in front of Superset, use the public base URL in `SUPERSET_BASE`.
- Ensure your backend is allowed to reach Superset and that the returned embed URL is accessible from clients.

This file is a starting point — if you want, I can help adapt it to your exact Superset version and test it against your instance.
