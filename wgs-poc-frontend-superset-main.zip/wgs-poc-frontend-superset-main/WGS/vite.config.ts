import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig(({ mode }) => ({
  plugins: [react(), tailwindcss()],
  build: {
    sourcemap: mode !== "production",
    minify: "oxc",
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (["react", "react-dom", "react-router-dom"].some((pkg) => id.includes(`node_modules/${pkg}/`))) {
            return "react";
          }
          if (id.includes("node_modules/@superset-ui/embedded-sdk/")) {
            return "superset";
          }
        },
      },
    },
  },
}));