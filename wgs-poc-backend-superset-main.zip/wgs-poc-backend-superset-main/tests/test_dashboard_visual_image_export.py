import time
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest
from fastapi.testclient import TestClient

import app.services.superset_visuals as visuals

_FAKE_ADMIN_USER = SimpleNamespace(role=SimpleNamespace(name="Admin"))


class _FakeResponse:
    def __init__(self, status_code, json_data=None, content=b""):
        self.status_code = status_code
        self._json_data = json_data or {}
        self.content = content

    def json(self):
        return self._json_data

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code}")


class _FakePlaywrightContextManager:
    """Stands in for `with sync_playwright() as p: ...`, handing back a `p`
    whose `.chromium.launch()` returns a browser wired to the given page."""

    def __init__(self, page):
        self.page = page
        self.browser = MagicMock()
        context = MagicMock()
        context.new_page.return_value = page
        self.browser.new_context.return_value = context

    def __enter__(self):
        p = MagicMock()
        p.chromium.launch.return_value = self.browser
        return p

    def __exit__(self, *exc_info):
        return False


# ------------------------------------------------------------------ #
# capture_dashboard_screenshot                                         #
# ------------------------------------------------------------------ #

def test_capture_dashboard_screenshot_logs_in_then_captures_full_page(monkeypatch):
    monkeypatch.setattr(
        visuals.requests, "get",
        lambda *a, **k: _FakeResponse(200, {"result": {"slug": "sales-dash"}}),
    )
    monkeypatch.setattr(visuals.settings, "superset_user", "admin")
    monkeypatch.setattr(visuals.settings, "superset_pass", "secret")

    page = MagicMock()
    page.url = "https://superset.example/superset/dashboard/sales-dash/?standalone=true"
    page.screenshot.return_value = b"PNGDATA"
    fake_pw = _FakePlaywrightContextManager(page)
    monkeypatch.setattr(visuals, "sync_playwright", lambda: fake_pw)

    result = visuals.capture_dashboard_screenshot("https://superset.example", "tok", 23)

    assert result == b"PNGDATA"
    page.goto.assert_any_call(
        "https://superset.example/login/", wait_until="networkidle", timeout=240_000
    )
    page.fill.assert_any_call("#username", "admin")
    page.fill.assert_any_call("#password", "secret")
    page.press.assert_called_once_with("#password", "Enter")
    page.goto.assert_any_call(
        "https://superset.example/superset/dashboard/sales-dash/?standalone=true",
        wait_until="networkidle", timeout=240_000,
    )
    page.screenshot.assert_called_once_with(full_page=True)
    fake_pw.browser.close.assert_called_once()


def test_capture_dashboard_screenshot_raises_if_login_did_not_redirect(monkeypatch):
    monkeypatch.setattr(
        visuals.requests, "get",
        lambda *a, **k: _FakeResponse(200, {"result": {"slug": "sales-dash"}}),
    )
    monkeypatch.setattr(visuals.settings, "superset_user", "admin")
    monkeypatch.setattr(visuals.settings, "superset_pass", "wrong-password")

    page = MagicMock()
    page.url = "https://superset.example/login/"
    fake_pw = _FakePlaywrightContextManager(page)
    monkeypatch.setattr(visuals, "sync_playwright", lambda: fake_pw)

    with pytest.raises(RuntimeError, match="login"):
        visuals.capture_dashboard_screenshot("https://superset.example", "tok", 23)

    fake_pw.browser.close.assert_called_once()


def test_capture_dashboard_screenshot_raises_without_credentials(monkeypatch):
    monkeypatch.setattr(visuals.settings, "superset_user", None)
    monkeypatch.setattr(visuals.settings, "superset_pass", None)
    with pytest.raises(RuntimeError):
        visuals.capture_dashboard_screenshot("https://superset.example", "tok", 23)


def test_capture_dashboard_screenshot_wraps_playwright_timeout(monkeypatch):
    monkeypatch.setattr(
        visuals.requests, "get",
        lambda *a, **k: _FakeResponse(200, {"result": {"slug": "sales-dash"}}),
    )
    monkeypatch.setattr(visuals.settings, "superset_user", "admin")
    monkeypatch.setattr(visuals.settings, "superset_pass", "secret")

    page = MagicMock()
    page.goto.side_effect = visuals.PlaywrightTimeoutError("timeout waiting for navigation")
    fake_pw = _FakePlaywrightContextManager(page)
    monkeypatch.setattr(visuals, "sync_playwright", lambda: fake_pw)

    with pytest.raises(TimeoutError):
        visuals.capture_dashboard_screenshot("https://superset.example", "tok", 23, timeout_seconds=5)

    fake_pw.browser.close.assert_called_once()


def test_capture_dashboard_screenshot_raises_on_dashboard_lookup_error(monkeypatch):
    monkeypatch.setattr(visuals.requests, "get", lambda *a, **k: _FakeResponse(500))
    monkeypatch.setattr(visuals.settings, "superset_user", "admin")
    monkeypatch.setattr(visuals.settings, "superset_pass", "secret")
    with pytest.raises(RuntimeError):
        visuals.capture_dashboard_screenshot("https://superset.example", "tok", 23)


# ------------------------------------------------------------------ #
# TemplateService.build_dashboard_image                                #
# ------------------------------------------------------------------ #

def test_build_dashboard_image_resolves_id_then_captures_screenshot(monkeypatch):
    from app.services.template_service import TemplateService

    service = TemplateService()
    monkeypatch.setattr(service, "_superset_login", lambda base: "tok")
    monkeypatch.setattr(
        TemplateService, "_resolve_dashboard_id",
        classmethod(lambda cls, base, token, uuid: (23, "My Dashboard")),
    )

    captured = {}

    def fake_fetch(base, token, dashboard_id, timeout_seconds=60):
        captured.update(base=base, token=token, dashboard_id=dashboard_id)
        return b"PNGDATA"

    monkeypatch.setattr("app.services.template_service.capture_dashboard_screenshot", fake_fetch)

    result = service.build_dashboard_image("some-uuid")

    assert result == b"PNGDATA"
    assert captured["token"] == "tok"
    assert captured["dashboard_id"] == 23


def test_build_dashboard_image_uses_numeric_id_directly_when_given(monkeypatch):
    """When the caller already knows the numeric ID, resolution must be
    skipped entirely — needed when the admin lacks 'can_read on Dashboard'."""
    from app.services.template_service import TemplateService

    service = TemplateService()
    monkeypatch.setattr(service, "_superset_login", lambda base: "tok")

    def _explode(cls, base, token, uuid):
        raise AssertionError("must not resolve UUID when dashboard_id is provided")

    monkeypatch.setattr(TemplateService, "_resolve_dashboard_id", classmethod(_explode))

    captured = {}

    def fake_fetch(base, token, dashboard_id, timeout_seconds=60):
        captured.update(dashboard_id=dashboard_id)
        return b"PNGDATA"

    monkeypatch.setattr("app.services.template_service.capture_dashboard_screenshot", fake_fetch)

    result = service.build_dashboard_image("some-uuid", dashboard_id=99)

    assert result == b"PNGDATA"
    assert captured["dashboard_id"] == 99


# ------------------------------------------------------------------ #
# Route: POST .../export/visual-image/async → status → download        #
# ------------------------------------------------------------------ #

class _ExplodingSession:
    """A fake DB session that blows up if ever queried — the route must
    skip the DB lookup entirely when `dashboard_id` is passed explicitly."""

    def query(self, *args, **kwargs):
        raise AssertionError("must not hit the DB when dashboard_id is provided explicitly")

    def close(self):
        pass


def test_visual_image_export_route_end_to_end(monkeypatch):
    from app.main import app
    from app.core.database import get_db
    from app.api.dependencies import get_current_user
    import app.api.routes.superset as superset_routes

    def _fake_get_db():
        yield _ExplodingSession()

    app.dependency_overrides[get_db] = _fake_get_db
    app.dependency_overrides[get_current_user] = lambda: _FAKE_ADMIN_USER
    monkeypatch.setattr(
        superset_routes._svc, "build_dashboard_image", lambda uuid, dashboard_id=None: b"FAKEPNGDATA"
    )
    try:
        client = TestClient(app)
        resp = client.post(
            "/api/superset/dashboard/some-uuid/export/visual-image/async",
            params={"dashboard_id": 42},
        )
        assert resp.status_code == 202
        job_id = resp.json()["job_id"]
        assert resp.json()["status"] == "pending"

        status_json = {"status": "pending"}
        for _ in range(50):
            status_json = client.get(f"/api/superset/dashboard/export/jobs/{job_id}/status").json()
            if status_json["status"] != "pending":
                break
            time.sleep(0.05)
        assert status_json["status"] == "done"

        download_resp = client.get(f"/api/superset/dashboard/export/jobs/{job_id}/download")
        assert download_resp.status_code == 200
        assert download_resp.content == b"FAKEPNGDATA"
        assert download_resp.headers["content-type"] == "image/png"
    finally:
        app.dependency_overrides.pop(get_db, None)
        app.dependency_overrides.pop(get_current_user, None)


def test_visual_image_export_route_reports_screenshot_timeout_as_job_error(monkeypatch):
    from app.main import app
    from app.core.database import get_db
    from app.api.dependencies import get_current_user
    import app.api.routes.superset as superset_routes

    def _fake_get_db():
        yield _ExplodingSession()

    def _raise_timeout(uuid, dashboard_id=None):
        raise TimeoutError("Dashboard 42 screenshot did not finish within 60s")

    app.dependency_overrides[get_db] = _fake_get_db
    app.dependency_overrides[get_current_user] = lambda: _FAKE_ADMIN_USER
    monkeypatch.setattr(superset_routes._svc, "build_dashboard_image", _raise_timeout)
    try:
        client = TestClient(app)
        resp = client.post(
            "/api/superset/dashboard/some-uuid/export/visual-image/async",
            params={"dashboard_id": 42},
        )
        job_id = resp.json()["job_id"]

        status_json = {"status": "pending"}
        for _ in range(50):
            status_json = client.get(f"/api/superset/dashboard/export/jobs/{job_id}/status").json()
            if status_json["status"] != "pending":
                break
            time.sleep(0.05)

        assert status_json["status"] == "error"
        assert "did not finish" in status_json["error"]
    finally:
        app.dependency_overrides.pop(get_db, None)
        app.dependency_overrides.pop(get_current_user, None)


# ------------------------------------------------------------------ #
# _dashboard_filename_stem                                             #
# ------------------------------------------------------------------ #

def test_dashboard_filename_stem_strips_non_latin1_characters():
    """A dashboard title with an em-dash (e.g. pasted from Word/PowerPoint)
    must not survive into the filename — Content-Disposition is a raw HTTP
    header and non-Latin-1 characters there crash uvicorn while writing the
    response, turning a successful export into a 500 on download.
    Reproduced directly against a real dashboard before this fix."""
    from app.api.routes.superset import _dashboard_filename_stem, _svc

    _svc._dashboard_id_cache["em-dash-uuid"] = (6, "Card Transactions — Executive Overview")

    stem = _dashboard_filename_stem("em-dash-uuid")

    stem.encode("latin-1")  # must not raise
    assert stem == "Card_Transactions_Executive_Overview"
