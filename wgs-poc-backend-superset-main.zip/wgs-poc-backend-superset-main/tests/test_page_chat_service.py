import types

import pytest
from fastapi import HTTPException
from google.genai import types as genai_types

from app.services.page_chat_service import (
    PageChatService,
    _aggregate,
    _build_system_prompt,
    _charts_from_page_data,
    _filter_rows_tool,
    _list_distinct,
)


class _FakeModels:
    def __init__(self, responses):
        # list of (text_or_None, error_or_None), consumed in call order
        self._responses = list(responses)
        self.calls = []

    def generate_content(self, model, contents, config):
        self.calls.append(config.system_instruction)
        text, error = self._responses.pop(0)
        if error:
            raise error
        return types.SimpleNamespace(text=text)


class _FakeGenaiClient:
    def __init__(self, responses):
        self.models = _FakeModels(responses)


_SAMPLE_ROWS = [
    {"city": "New York City", "quantity": 52},
    {"city": "New York City", "quantity": 10},
    {"city": "Omaha", "quantity": 5},
    {"city": "Omaha", "quantity": 9},
    {"city": "Boise", "quantity": None},
]
_SAMPLE_CHARTS = {"Table chart": _SAMPLE_ROWS}


class _FakeToolCallModels:
    """Simulates one round of the model calling `aggregate`, then a final
    text-only answer once it receives the tool's result."""

    def __init__(self, function_call, final_text):
        self._function_call = function_call
        self._final_text = final_text
        self.calls = []

    def generate_content(self, model, contents, config):
        self.calls.append((config.system_instruction, list(contents)))
        if len(self.calls) == 1:
            fc = genai_types.FunctionCall(name=self._function_call[0], args=self._function_call[1])
            content = genai_types.Content(role="model", parts=[genai_types.Part(function_call=fc)])
            return types.SimpleNamespace(
                text=None,
                function_calls=[fc],
                candidates=[types.SimpleNamespace(content=content)],
            )
        return types.SimpleNamespace(text=self._final_text, function_calls=None)


class _FakeParallelToolCallModels:
    """Simulates the model requesting TWO tool calls in a single turn
    (parallel function calling, e.g. "first and last order date" -> MIN + MAX
    together) — the real Gemini API 400s unless both function responses are
    sent back as parts of ONE Content turn, not two separate turns."""

    def __init__(self, function_calls, final_text):
        self._function_calls = function_calls
        self._final_text = final_text
        self.calls = []

    def generate_content(self, model, contents, config):
        self.calls.append(list(contents))
        if len(self.calls) == 1:
            fcs = [genai_types.FunctionCall(name=n, args=a) for n, a in self._function_calls]
            content = genai_types.Content(
                role="model", parts=[genai_types.Part(function_call=fc) for fc in fcs]
            )
            return types.SimpleNamespace(
                text=None,
                function_calls=fcs,
                candidates=[types.SimpleNamespace(content=content)],
            )
        # Assert the follow-up call bundled both function responses into a
        # single Content turn, matching the real API's requirement.
        function_response_turns = [
            c for c in contents if any(getattr(p, "function_response", None) for p in c.parts)
        ]
        assert len(function_response_turns) == 1
        assert len(function_response_turns[0].parts) == len(self._function_calls)
        return types.SimpleNamespace(text=self._final_text, function_calls=None)


def test_aggregate_sum_with_filter():
    result = _aggregate(_SAMPLE_CHARTS, "SUM", "quantity", filters=[{"col": "city", "op": "==", "val": "New York City"}])
    assert result == {"result": 62, "matched_rows": 2}


def test_aggregate_count_ignores_column():
    result = _aggregate(_SAMPLE_CHARTS, "COUNT", filters=[{"col": "city", "op": "==", "val": "Omaha"}])
    assert result == {"result": 2, "matched_rows": 2}


def test_aggregate_skips_non_numeric_values():
    result = _aggregate(_SAMPLE_CHARTS, "SUM", "quantity", filters=[{"col": "city", "op": "==", "val": "Boise"}])
    assert result["result"] is None
    assert result["matched_rows"] == 1


def test_aggregate_unsupported_operation_returns_error_not_exception():
    result = _aggregate(_SAMPLE_CHARTS, "MEDIAN", "quantity")
    assert "error" in result


def test_aggregate_min_max_on_date_strings_uses_lexicographic_comparison():
    """MIN/MAX must work on non-numeric-but-orderable columns like ISO date
    strings (order_date/ship_date) — not just numeric columns."""
    date_rows = [
        {"order_date": "2017-09-20"},
        {"order_date": "2015-06-29"},
        {"order_date": "2016-12-10"},
    ]
    charts = {"chart": date_rows}
    assert _aggregate(charts, "MIN", "order_date") == {"result": "2015-06-29", "matched_rows": 3}
    assert _aggregate(charts, "MAX", "order_date") == {"result": "2017-09-20", "matched_rows": 3}


def test_like_filter_strips_sql_style_percent_wildcards():
    """Regression test: models naturally write LIKE filter values with
    SQL-style %wildcard% syntax (e.g. "%New York%"), but this filter
    language has no wildcard grammar. Confirmed directly against the live
    API that a literal-match LIKE (checking for the "%" characters
    themselves) always returns zero rows, which sent the model on repeated
    dead-end retries that exhausted the tool-call round budget before it
    could ever report the answer it already had."""
    charts = {"chart": [{"city": "New York City"}, {"city": "Omaha"}]}
    assert _list_distinct(charts, "city", filters=[{"col": "city", "op": "LIKE", "val": "%New York%"}]) == {
        "values": ["New York City"],
        "count": 1,
        "truncated": False,
    }
    assert _list_distinct(charts, "city", filters=[{"col": "city", "op": "LIKE", "val": "New York%"}]) == {
        "values": ["New York City"],
        "count": 1,
        "truncated": False,
    }
    assert _list_distinct(charts, "city", filters=[{"col": "city", "op": "LIKE", "val": "%Omaha"}]) == {
        "values": ["Omaha"],
        "count": 1,
        "truncated": False,
    }


def test_aggregate_with_explicit_chart_name():
    result = _aggregate(_SAMPLE_CHARTS, "SUM", "quantity", chart="Table chart")
    assert result["matched_rows"] == 5


def test_aggregate_unknown_chart_name_returns_error():
    result = _aggregate(_SAMPLE_CHARTS, "SUM", "quantity", chart="Nonexistent chart")
    assert "error" in result


def test_aggregate_requires_chart_when_multiple_present():
    two_charts = {"Table chart": _SAMPLE_ROWS, "Other chart": [{"x": 1}]}
    result = _aggregate(two_charts, "COUNT")
    assert "error" in result
    # explicit chart resolves the ambiguity
    result = _aggregate(two_charts, "COUNT", chart="Other chart")
    assert result == {"result": 1, "matched_rows": 1}


def test_list_distinct_deduplicates():
    result = _list_distinct(_SAMPLE_CHARTS, "city")
    assert result == {"values": ["New York City", "Omaha", "Boise"], "count": 3, "truncated": False}


def test_list_distinct_caps_values_but_keeps_exact_count():
    """Regression hardening: a high-cardinality column (e.g. 531 distinct
    cities, observed live) must not return every value in the function
    response — only 'count' needs to stay exact; 'values' is a capped sample."""
    many_cities_chart = {"chart": [{"city": f"City {i}"} for i in range(200)]}
    result = _list_distinct(many_cities_chart, "city")
    assert result["count"] == 200
    assert len(result["values"]) == 50
    assert result["truncated"] is True


def test_filter_rows_tool_caps_and_reports_truncation():
    many_rows_chart = {"chart": [{"n": i} for i in range(100)]}
    result = _filter_rows_tool(many_rows_chart, limit=1000)
    assert len(result["rows"]) == 50  # capped at _MAX_FILTER_ROWS regardless of requested limit
    assert result["total_matched"] == 100
    assert result["truncated"] is True


def test_charts_from_page_data_accepts_flat_rows_shape():
    assert _charts_from_page_data({"rows": _SAMPLE_ROWS}) == {"this page": _SAMPLE_ROWS}


def test_charts_from_page_data_accepts_real_dashboard_shape():
    """The real production page_data shape (confirmed from a live browser
    payload): {"chartData": {"charts": [{"title", "headers", "rows"}]}},
    alongside a pile of unrelated dashboard/embed metadata that must be
    ignored (dashboards, selectedDashboard, embed_url, guest_token, ...)."""
    page_data = {
        "chartData": {
            "title": "Tabular Dashboard",
            "charts": [
                {"title": "Table chart", "headers": ["city", "quantity"], "rows": _SAMPLE_ROWS},
            ],
        },
        "dashboards": [{"id": 3, "title": "Tabular Dashboard"}],
        "selectedDashboard": {"id": 3},
        "embed_url": "http://172.17.0.1/embedded/some-uuid",
        "guest_token": "some.jwt.token",
        "id": 3,
    }
    assert _charts_from_page_data(page_data) == {"Table chart": _SAMPLE_ROWS}


def test_charts_from_page_data_handles_multiple_charts():
    page_data = {
        "chartData": {
            "charts": [
                {"title": "Table chart", "rows": _SAMPLE_ROWS},
                {"title": "Summary chart", "rows": [{"total": 76}]},
            ]
        }
    }
    result = _charts_from_page_data(page_data)
    assert set(result.keys()) == {"Table chart", "Summary chart"}
    assert result["Summary chart"] == [{"total": 76}]


def test_charts_from_page_data_rejects_unknown_shapes():
    assert _charts_from_page_data({"chartData": {}}) is None
    assert _charts_from_page_data({"rows": [1, 2, 3]}) is None
    assert _charts_from_page_data({"rows": "not-a-list"}) is None
    assert _charts_from_page_data({"chartData": {"charts": [{"title": "x", "rows": "nope"}]}}) is None


def test_ask_uses_aggregate_tool_and_returns_final_answer():
    """End-to-end (mocked client): the model calls `aggregate`, gets the
    deterministic Python-computed result, and produces a final JSON answer —
    verifies the tool-calling loop itself, not just the pure helpers."""
    service = PageChatService()
    client = types.SimpleNamespace()
    client.models = _FakeToolCallModels(
        function_call=("aggregate", {"operation": "SUM", "column": "quantity"}),
        final_text='{"message": "62", "found_in_page_data": true, "blocks": []}',
    )
    service._client = client

    result = service.ask("dashboard", {"rows": _SAMPLE_ROWS}, "SUM(quantity) for new york")

    assert result.message == "62"
    assert len(client.models.calls) == 2  # one tool-call round + one final round


def test_ask_bundles_parallel_tool_calls_into_one_function_response_turn():
    """Regression test: reproduced directly against the live Gemini API that
    sending each parallel function call's response back as its own separate
    Content turn 400s with 'the number of function response parts is equal
    to the number of function call parts'. Every response must be parts of
    ONE Content turn — asserted inside _FakeParallelToolCallModels itself."""
    service = PageChatService()
    client = types.SimpleNamespace()
    client.models = _FakeParallelToolCallModels(
        function_calls=[
            ("aggregate", {"operation": "MIN", "column": "order_date"}),
            ("aggregate", {"operation": "MAX", "column": "order_date"}),
        ],
        final_text='{"message": "first and last", "found_in_page_data": true, "blocks": []}',
    )
    service._client = client

    result = service.ask("dashboard", {"rows": _SAMPLE_ROWS}, "first and last order date")

    assert result.message == "first and last"


def test_build_system_prompt_includes_page_name_and_data_context():
    prompt = _build_system_prompt("dashboard", {"rows": [{"city": "NYC", "qty": 52}]})

    assert "Dashboard" in prompt
    assert "NYC" in prompt
    assert "found_in_page_data" in prompt


def test_ask_returns_parsed_response_on_valid_json():
    service = PageChatService()
    service._client = _FakeGenaiClient(
        [('{"message": "42", "found_in_page_data": true, "blocks": []}', None)]
    )

    result = service.ask("dashboard", {"rows": []}, "What's the total?")

    assert result.message == "42"
    assert result.found_in_page_data is True
    assert result.blocks == []


def test_ask_retries_once_on_malformed_json_then_succeeds():
    service = PageChatService()
    client = _FakeGenaiClient(
        [
            ("not valid json at all", None),
            ('{"message": "42", "found_in_page_data": true, "blocks": []}', None),
        ]
    )
    service._client = client

    result = service.ask("dashboard", {"rows": []}, "What's the total?")

    assert result.message == "42"
    assert len(client.models.calls) == 2
    assert "IMPORTANT" in client.models.calls[1]


def test_ask_raises_http_exception_when_retry_also_fails():
    service = PageChatService()
    service._client = _FakeGenaiClient([("still not json", None), ("still not json", None)])

    with pytest.raises(HTTPException) as exc_info:
        service.ask("dashboard", {"rows": []}, "What's the total?")

    assert exc_info.value.status_code == 502


def test_ask_raises_400_on_unknown_agent_type():
    service = PageChatService()

    with pytest.raises(HTTPException) as exc_info:
        service.ask("not-a-real-page", {}, "hi")

    assert exc_info.value.status_code == 400


def test_ask_raises_http_exception_when_client_errors():
    service = PageChatService()
    service._client = _FakeGenaiClient([(None, RuntimeError("boom"))])

    with pytest.raises(HTTPException) as exc_info:
        service.ask("dashboard", {"rows": []}, "What's the total?")

    assert exc_info.value.status_code == 502


def test_ask_raises_http_exception_when_no_answer_text():
    service = PageChatService()
    service._client = _FakeGenaiClient([(None, None)])

    with pytest.raises(HTTPException) as exc_info:
        service.ask("dashboard", {"rows": []}, "What's the total?")

    assert exc_info.value.status_code == 502


def test_ask_normalizes_object_shaped_table_rows():
    service = PageChatService()
    service._client = _FakeGenaiClient(
        [
            (
                '{"message": "The total profit is 286397.02", "found_in_page_data": true, '
                '"blocks": [{"type": "table", "columns": ["SUM(profit)"], '
                '"rows": [{"SUM(profit)": 286397.02}]}]}',
                None,
            )
        ]
    )

    result = service.ask("dashboard", {"rows": []}, "give me total profit")

    assert result.blocks[0].rows == [[286397.02]]
