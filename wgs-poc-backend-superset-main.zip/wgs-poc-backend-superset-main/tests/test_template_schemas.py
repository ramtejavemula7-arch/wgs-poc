import pytest

from app.schemas.template import TemplateCreate
from app.services.template_service import TemplateService


def test_template_create_accepts_columns_and_filters():
    payload = TemplateCreate(
        name="Sales Template",
        logo_url="/uploads/logo.png",
        logo_position="left",
        dataset_id=1,
        columns=["customer", "revenue"],
        filters=[{"column": "region", "operator": "eq", "value": "US"}],
    )

    assert payload.name == "Sales Template"
    assert payload.columns == ["customer", "revenue"]
    assert payload.filters[0]["column"] == "region"


def test_read_logo_bytes_reads_local_upload_url(tmp_path, monkeypatch):
    logo_dir = tmp_path / "uploads"
    logo_dir.mkdir()
    logo_path = logo_dir / "logo.png"
    logo_path.write_bytes(b"fake-image-bytes")

    service = TemplateService()
    monkeypatch.chdir(tmp_path)
    content = service._read_logo_bytes("http://localhost:8000/uploads/logo.png")

    assert content == b"fake-image-bytes"
