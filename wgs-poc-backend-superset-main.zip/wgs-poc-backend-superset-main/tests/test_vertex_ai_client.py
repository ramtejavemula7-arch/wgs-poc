import pytest
from fastapi import HTTPException

from app.core.config import settings
from app.services.vertex_ai_client import build_vertex_ai_client


def test_build_vertex_ai_client_uses_api_key_when_configured(monkeypatch):
    monkeypatch.setattr(settings, "gemini_api_key", "fake-api-key-for-test")

    client = build_vertex_ai_client()

    assert client is not None
    # API key mode has no region/location concept at all — unlike Vertex AI.
    assert client.vertexai is False


def test_build_vertex_ai_client_raises_http_exception_on_missing_credentials_file(monkeypatch):
    monkeypatch.setattr(settings, "gemini_api_key", None)
    monkeypatch.setattr(settings, "google_application_credentials", "/nonexistent/path.json")

    with pytest.raises(HTTPException) as exc_info:
        build_vertex_ai_client()

    assert exc_info.value.status_code == 502


def test_build_vertex_ai_client_falls_back_to_adc_when_no_credentials_path(monkeypatch):
    # With no explicit credentials path, the client should still construct
    # (it defers to Application Default Credentials, not resolved until a
    # real call is made) rather than raising at build time.
    monkeypatch.setattr(settings, "gemini_api_key", None)
    monkeypatch.setattr(settings, "google_application_credentials", None)

    client = build_vertex_ai_client()

    assert client is not None
    assert client.vertexai is True
