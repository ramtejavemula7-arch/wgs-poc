def test_dummy_user():
    assert 1 + 1 == 2
