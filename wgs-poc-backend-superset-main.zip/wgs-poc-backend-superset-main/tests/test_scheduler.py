from datetime import date, datetime, timezone
from zoneinfo import ZoneInfo

import apscheduler.triggers.cron as cron_module
import apscheduler.triggers.date as date_module
import pytest

from app.core.scheduler import _build_trigger


class _FakeSchedule:
    def __init__(self, frequency, hour=10, minute=0, day_of_week=None, run_date=None):
        self.frequency = frequency
        self.hour = hour
        self.minute = minute
        self.day_of_week = day_of_week
        self.run_date = run_date


@pytest.fixture(autouse=True)
def force_utc_local_timezone(monkeypatch):
    """Simulate a container whose OS-local timezone is UTC (e.g. Cloud Run
    with no TZ env var) — the exact condition that let this bug hide on a
    dev machine whose local clock happens to be IST-equivalent."""
    monkeypatch.setattr(cron_module, "get_localzone", lambda: timezone.utc)
    monkeypatch.setattr(date_module, "get_localzone", lambda: timezone.utc)


def test_daily_trigger_is_pinned_to_scheduler_timezone_not_local_tz():
    schedule = _FakeSchedule(frequency="daily", hour=10, minute=0)
    trigger = _build_trigger(schedule)

    assert trigger.timezone == ZoneInfo("Asia/Kolkata")

    now = datetime(2026, 7, 15, 0, 0, tzinfo=timezone.utc)
    next_fire = trigger.get_next_fire_time(None, now)

    # 10:00 IST == 04:30 UTC, NOT 10:00 UTC.
    assert next_fire.astimezone(timezone.utc) == datetime(2026, 7, 15, 4, 30, tzinfo=timezone.utc)


def test_weekly_trigger_is_pinned_to_scheduler_timezone_not_local_tz():
    schedule = _FakeSchedule(frequency="weekly", hour=10, minute=0, day_of_week="wed")
    trigger = _build_trigger(schedule)

    assert trigger.timezone == ZoneInfo("Asia/Kolkata")

    now = datetime(2026, 7, 15, 0, 0, tzinfo=timezone.utc)  # a Wednesday
    next_fire = trigger.get_next_fire_time(None, now)

    assert next_fire.astimezone(timezone.utc) == datetime(2026, 7, 15, 4, 30, tzinfo=timezone.utc)


def test_once_trigger_is_pinned_to_scheduler_timezone_not_local_tz():
    schedule = _FakeSchedule(frequency="once", hour=10, minute=0, run_date=date(2026, 7, 20))
    trigger = _build_trigger(schedule)

    assert trigger.run_date.tzinfo == ZoneInfo("Asia/Kolkata")
    assert trigger.run_date.astimezone(timezone.utc) == datetime(2026, 7, 20, 4, 30, tzinfo=timezone.utc)
