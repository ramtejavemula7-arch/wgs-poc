from app.services.template_service import TemplateService


class _FakeResponse:
    def __init__(self, status_code=200, payload=None):
        self.status_code = status_code
        self.ok = 200 <= status_code < 300
        self._payload = payload if payload is not None else {"result": [{"data": []}]}

    def json(self):
        return self._payload


def test_run_grouped_metrics_query_orders_by_expanded_derived_dimension(monkeypatch):
    # Regression test: ordering by a derived date-part dimension (e.g.
    # "Date__year") as a bare string 400s against Superset ("Unknown column
    # used in orderby") because it isn't a real column — only the adhoc
    # EXTRACT(...) column defined in groupby/columns exists. orderby must
    # reference that SAME adhoc-column object, not the plain name.
    service = TemplateService()
    monkeypatch.setattr(service, "_superset_login", lambda base_url: "fake-token")

    captured = {}

    def fake_post(url, **kwargs):
        captured["json"] = kwargs.get("json")
        return _FakeResponse(200, {"result": [{"data": []}]})

    monkeypatch.setattr("app.services.template_service.requests.post", fake_post)

    service._run_grouped_metrics_query(
        dataset_id=1,
        groupby=["ProductName", "Date__year"],
        metric_specs=[{"field": "sales", "aggregation": "SUM", "label": "Sales"}],
        filters=[],
        sort=None,
        force=False,
    )

    query = captured["json"]["queries"][0]
    expanded_date_col = {
        "label": "Date__year", "sqlExpression": "EXTRACT(YEAR FROM Date)", "expressionType": "SQL",
    }

    # groupby/columns carry the expanded adhoc column for the derived dim
    assert query["groupby"] == ["ProductName", expanded_date_col]
    assert query["columns"] == ["ProductName", expanded_date_col]

    # orderby must reference the identical adhoc-column object, not "Date__year"
    assert query["orderby"] == [["ProductName", True], [expanded_date_col, True]]


def test_run_grouped_metrics_query_orderby_respects_explicit_dimension_sort(monkeypatch):
    service = TemplateService()
    monkeypatch.setattr(service, "_superset_login", lambda base_url: "fake-token")

    captured = {}

    def fake_post(url, **kwargs):
        captured["json"] = kwargs.get("json")
        return _FakeResponse(200, {"result": [{"data": []}]})

    monkeypatch.setattr("app.services.template_service.requests.post", fake_post)

    service._run_grouped_metrics_query(
        dataset_id=1,
        groupby=["ProductName", "Date__year"],
        metric_specs=[{"field": "sales", "aggregation": "SUM", "label": "Sales"}],
        filters=[],
        sort={"field": "Date__year", "direction": "desc"},
        force=False,
    )

    query = captured["json"]["queries"][0]
    expanded_date_col = {
        "label": "Date__year", "sqlExpression": "EXTRACT(YEAR FROM Date)", "expressionType": "SQL",
    }
    # Explicit desc sort on the derived dimension still uses its expanded form
    assert query["orderby"][1] == [expanded_date_col, False]
