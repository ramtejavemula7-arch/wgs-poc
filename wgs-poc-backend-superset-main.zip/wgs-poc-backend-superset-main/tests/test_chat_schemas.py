import pytest

from app.schemas.chat import ChatRequest, ChatResponse


def test_chat_request_accepts_valid_payload():
    payload = ChatRequest(question="What is total revenue?")

    assert payload.question == "What is total revenue?"


def test_chat_request_rejects_empty_question():
    with pytest.raises(ValueError):
        ChatRequest(question="")


def test_chat_response_sql_defaults_to_none():
    response = ChatResponse(answer="42", intent="SQL", confidence=0.9, session_id="s1")

    assert response.answer == "42"
    assert response.sql is None
