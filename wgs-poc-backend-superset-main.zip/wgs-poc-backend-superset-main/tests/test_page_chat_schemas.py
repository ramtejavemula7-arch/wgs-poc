import pytest

from app.schemas.page_chat import PageChatBlock, PageChatRequest, PageChatResponse


def test_page_chat_request_accepts_camel_case_wire_format():
    payload = PageChatRequest.model_validate(
        {"agentType": "dashboard", "pageData": {"rows": [1, 2, 3]}, "question": "What's the total?"}
    )

    assert payload.agent_type == "dashboard"
    assert payload.page_data == {"rows": [1, 2, 3]}
    assert payload.question == "What's the total?"


def test_page_chat_request_rejects_unknown_agent_type():
    with pytest.raises(ValueError):
        PageChatRequest.model_validate(
            {"agentType": "not-a-real-page", "pageData": {}, "question": "hi"}
        )


def test_page_chat_request_rejects_empty_question():
    with pytest.raises(ValueError):
        PageChatRequest.model_validate({"agentType": "dashboard", "pageData": {}, "question": ""})


def test_page_chat_response_defaults_blocks_to_empty_list():
    response = PageChatResponse(message="42", found_in_page_data=True)

    assert response.blocks == []


def test_page_chat_block_accepts_table_shape():
    block = PageChatBlock(type="table", columns=["city", "qty"], rows=[["NYC", 52]])

    assert block.columns == ["city", "qty"]
    assert block.rows == [["NYC", 52]]
