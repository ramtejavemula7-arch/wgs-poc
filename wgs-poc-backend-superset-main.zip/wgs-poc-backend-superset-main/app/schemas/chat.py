from typing import Any

from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    question: str = Field(..., min_length=1, max_length=2000)
    session_id: str | None = None  # omit to start a new conversation
    # BigQuery Data Agent resource name picked from the Chat Assistant's own
    # agent dropdown (see GET .../agents) — applies only to this question;
    # omit/null to use direct Gemini-SQL-generation instead.
    data_agent: str | None = None


class ChatTable(BaseModel):
    columns: list[str]
    rows: list[list[Any]]


class ChatResponse(BaseModel):
    answer: str
    sql: str | None = None
    table: ChatTable | None = None
    chart: dict[str, Any] | None = None  # auto-detected Vega-Lite chart spec, if any — rendered by the frontend
    intent: str  # SQL | RAG | HYBRID | CONTEXT | CLARIFY
    confidence: float
    follow_ups: list[str] = Field(default_factory=list)
    session_id: str  # echoed back — pass this on the next request to keep conversation context
