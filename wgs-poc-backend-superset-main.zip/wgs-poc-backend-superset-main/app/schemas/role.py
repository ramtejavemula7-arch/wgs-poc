from enum import Enum
from typing import Optional
from uuid import UUID
from datetime import datetime
from pydantic import BaseModel, ConfigDict


class Module(str, Enum):
    DASHBOARD = "dashboard"
    REPORTS = "reports"
    TRANSACTION_SEARCH = "transaction_search"
    API_ENDPOINTS = "rest_endpoints"  # matches the frontend's module key for the API Endpoints page
    ADMIN = "admin"
    USERS = "users"
    ROLES = "roles"


class AccessLevel(str, Enum):
    NONE = "none"
    READ = "read"
    EDIT = "edit"


class RolePermissionIn(BaseModel):
    module: Module
    access_level: AccessLevel


class RolePermissionRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    module: Module
    access_level: AccessLevel


class RoleCreate(BaseModel):
    name: str


class RoleUpdate(BaseModel):
    name: Optional[str] = None


class RoleRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    name: str
    created_by: Optional[UUID] = None
    created_at: datetime
    permissions: list[RolePermissionRead] = []


class RolePermissionsUpdate(BaseModel):
    permissions: list[RolePermissionIn]
