from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

AgentType = Literal["dashboard", "reports", "transactions", "users", "roles"]


class PageChatRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    agent_type: AgentType = Field(alias="agentType")
    # The JSON the calling page already fetched to render itself — the
    # model's entire universe of facts for this request, nothing else.
    page_data: dict[str, Any] = Field(alias="pageData")
    question: str = Field(..., min_length=1, max_length=2000)


class PageChatBlock(BaseModel):
    type: Literal["text", "table"]
    content: str | None = None
    columns: list[str] | None = None
    rows: list[list[Any]] | None = None


class PageChatResponse(BaseModel):
    message: str
    found_in_page_data: bool
    blocks: list[PageChatBlock] = Field(default_factory=list)
