from typing import Any, Literal
from pydantic import BaseModel, Field, model_validator

# "metrics" is the legacy fully-aggregated pivot ("Matrix" in its day) — kept
# only so existing rows already saved with this type keep reading/exporting;
# TemplateService.create/update reject creating or switching INTO "metrics"
# going forward. "grouped" is the current user-facing "Matrix" template —
# row-level detail merged/grouped by `dimensions`, not aggregated. "heatmap"
# reuses the same aggregated-pivot engine as "metrics" (dimensions → row
# hierarchy, column_field → pivoted columns, metrics → SUM/AVG/etc.) and adds
# a value-based color scale over the leaf cells.
TemplateType = Literal["transaction", "metrics", "grouped", "heatmap"]


class MetricSpec(BaseModel):
    field: str  # or the sentinel "__order_count__" for COUNT(*) with no real column
    aggregation: Literal["SUM", "AVG", "MIN", "MAX", "COUNT"]
    label: str
    # Currency code (e.g. "USD"); omitted/None means "plain number." An
    # unrecognized code falls back to plain number formatting at export time
    # rather than erroring — same contract as Template.column_formats.
    format: str | None = None


class SortSpec(BaseModel):
    field: str
    direction: Literal["asc", "desc"]


def _check_grouped_dimensions_prefix(dimensions: list[str] | None, columns: list[str] | None) -> None:
    """A "grouped" template's row-merge hierarchy must be an ordered prefix of
    the displayed columns — group columns render leftmost, merged vertically,
    followed by the per-row detail columns. Without this constraint the merge
    span computation in TemplateService has no well-defined column order."""
    dims = dimensions or []
    cols = columns or []
    if not dims:
        raise ValueError("A 'grouped' template requires at least one dimension to group by")
    if cols[: len(dims)] != dims:
        raise ValueError(
            "A 'grouped' template's dimensions must be an ordered prefix of its columns "
            f"(expected columns to start with {dims}, got {cols[: len(dims)]})"
        )


class TemplateBase(BaseModel):
    name: str = Field(..., min_length=1)
    template_type: TemplateType = "transaction"
    logo_url: str | None = None
    logo_position: str = Field(default="left")
    template_color: str | None = None
    dataset_id: int
    columns: list[str] = Field(default_factory=list)
    filters: list[dict[str, Any]] = Field(default_factory=list)
    total_columns: list[str] = Field(default_factory=list)
    # column_name -> currency code (e.g. "USD"); unrecognized codes fall back
    # to plain number formatting at export time rather than erroring.
    column_formats: dict[str, str] = Field(default_factory=dict)
    dimensions: list[str] | None = None
    metrics: list[MetricSpec] | None = None
    sort: SortSpec | None = None
    column_field: str | None = None  # metrics templates: optional pivot dimension, e.g. "ship_mode"
    column_sort_direction: Literal["asc", "desc"] = "asc"

    @model_validator(mode="after")
    def _validate_grouped_dimensions(self):
        if self.template_type == "grouped":
            _check_grouped_dimensions_prefix(self.dimensions, self.columns)
        return self


class TemplateCreate(TemplateBase):
    pass


class TemplateUpdate(BaseModel):
    name: str | None = None
    template_type: TemplateType | None = None
    logo_url: str | None = None
    logo_position: str | None = None
    template_color: str | None = None
    dataset_id: int | None = None
    columns: list[str] | None = None
    filters: list[dict[str, Any]] | None = None
    total_columns: list[str] | None = None
    column_formats: dict[str, str] | None = None
    dimensions: list[str] | None = None
    metrics: list[MetricSpec] | None = None
    sort: SortSpec | None = None
    column_field: str | None = None
    column_sort_direction: Literal["asc", "desc"] | None = None

    @model_validator(mode="after")
    def _validate_grouped_dimensions(self):
        # Only checked when the patch itself carries enough information —
        # partial patches that don't touch template_type/columns/dimensions
        # together are validated against the merged row at the service layer
        # implicitly (the merge-span computation itself requires the prefix).
        if self.template_type == "grouped" and self.columns is not None and self.dimensions is not None:
            _check_grouped_dimensions_prefix(self.dimensions, self.columns)
        return self


class TemplateRead(TemplateBase):
    id: int


class LogoUploadResponse(BaseModel):
    url: str
