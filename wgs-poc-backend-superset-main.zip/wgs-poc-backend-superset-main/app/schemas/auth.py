from pydantic import BaseModel
from typing import Optional
from uuid import UUID


class Token(BaseModel):
    access_token: str
    token_type: str
    role: Optional[str] = None
    user_id: Optional[UUID] = None


class LoginRequest(BaseModel):
    email: str
    password: str


class ActivateAccountRequest(BaseModel):
    token: str
    password: str
