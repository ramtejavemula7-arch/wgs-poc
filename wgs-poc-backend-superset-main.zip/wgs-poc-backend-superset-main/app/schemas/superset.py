from pydantic import BaseModel
from typing import Optional


class DashboardEmbedRequest(BaseModel):
    dashboard_id: str
    username: Optional[str] = "guest"


class DashboardEmbedResponse(BaseModel):
    dashboard_id: str
    guest_token: str
    embed_url: str


class DashboardListResponse(BaseModel):
    id: str
    dashboard_title: Optional[str] = None
    description: Optional[str] = None
