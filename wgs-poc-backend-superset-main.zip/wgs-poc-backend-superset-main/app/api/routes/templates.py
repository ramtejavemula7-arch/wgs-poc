import logging
import threading
import types
from typing import Any
from uuid import uuid4

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from fastapi.responses import Response
from sqlalchemy.orm import Session

from app.api.dependencies import require_permission
from app.core.database import get_db
from app.core.export_jobs import (
    cleanup_old_jobs, complete_job, create_job, fail_job, get_job, pop_job,
)
from app.models.user import User
from app.schemas.role import AccessLevel, Module
from app.schemas.template import LogoUploadResponse, TemplateCreate, TemplateRead, TemplateUpdate
from app.services.template_service import TemplateService
from app.core.endpoints import TemplateRoutes

logger = logging.getLogger(__name__)

router = APIRouter(prefix=TemplateRoutes.PREFIX, tags=["templates"])
service = TemplateService()

# Reused across this file's endpoints — all gated by the "reports" module.
_reports_read = Depends(require_permission(Module.REPORTS, AccessLevel.READ))
_reports_edit = Depends(require_permission(Module.REPORTS, AccessLevel.EDIT))


# ------------------------------------------------------------------ #
# Build helpers that return (bytes, media_type, filename)             #
# ------------------------------------------------------------------ #

def _build_pdf(template_data: dict[str, Any]):
    mock = types.SimpleNamespace(**template_data)
    pdf_bytes = service.build_pdf(mock)
    filename = template_data["name"].replace(" ", "_") + ".pdf"
    return pdf_bytes, "application/pdf", filename


def _build_excel(template_data: dict[str, Any]):
    mock = types.SimpleNamespace(**template_data)
    excel_bytes = service.build_excel(mock)
    filename = template_data["name"].replace(" ", "_") + ".xlsx"
    return (
        excel_bytes,
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        filename,
    )


def _template_snapshot(template) -> dict[str, Any]:
    return {
        "id": template.id,
        "name": template.name,
        "template_type": template.template_type,
        "dataset_id": template.dataset_id,
        "columns": template.columns,
        "filters": template.filters,
        "total_columns": template.total_columns,
        "column_formats": template.column_formats,
        "logo_url": template.logo_url,
        "logo_position": template.logo_position,
        "template_color": template.template_color,
        "dimensions": template.dimensions,
        "metrics": template.metrics,
        "sort": template.sort,
        "column_field": template.column_field,
        "column_sort_direction": template.column_sort_direction,
    }


def _run_export(job_id: str, build_fn, *args) -> None:
    try:
        content, media_type, filename = build_fn(*args)
        complete_job(job_id, content, media_type, filename)
    except Exception as exc:
        logger.exception("Export job %s failed", job_id)
        fail_job(job_id, str(exc))


# ------------------------------------------------------------------ #
# CRUD                                                                 #
# ------------------------------------------------------------------ #

@router.get(TemplateRoutes.LIST_CREATE, response_model=list[TemplateRead])
def list_templates(db: Session = Depends(get_db), current_user: User = _reports_read):
    return service.get_all(db)


@router.post(TemplateRoutes.LIST_CREATE, response_model=TemplateRead, status_code=status.HTTP_201_CREATED)
def create_template(payload: TemplateCreate, db: Session = Depends(get_db), current_user: User = _reports_edit):
    if service.get_by_name(db, payload.name):
        raise HTTPException(status_code=400, detail="Template already exists")
    return service.create(db, payload)


@router.get(TemplateRoutes.BY_ID, response_model=TemplateRead)
def get_template(template_id: int, db: Session = Depends(get_db), current_user: User = _reports_read):
    template = service.get_by_id(db, template_id)
    if not template:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Template not found")
    return template


@router.put(TemplateRoutes.BY_ID, response_model=TemplateRead)
def update_template(
    template_id: int, payload: TemplateUpdate, db: Session = Depends(get_db), current_user: User = _reports_edit
):
    if payload.name:
        duplicate = service.get_by_name(db, payload.name)
        if duplicate and duplicate.id != template_id:
            raise HTTPException(status_code=400, detail="Template already exists")

    template = service.update(db, template_id, payload)
    if not template:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Template not found")
    return template


@router.delete(TemplateRoutes.BY_ID, status_code=status.HTTP_204_NO_CONTENT)
def delete_template(template_id: int, db: Session = Depends(get_db), current_user: User = _reports_edit):
    deleted = service.delete(db, template_id)
    if not deleted:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Template not found")
    return None


@router.post(TemplateRoutes.UPLOAD_LOGO, response_model=LogoUploadResponse)
async def upload_logo(file: UploadFile = File(...), current_user: User = _reports_edit):
    url = await service.upload_logo(file)
    return LogoUploadResponse(url=url)


@router.get(TemplateRoutes.LOGO_FILE)
def get_logo_file(file_name: str):
    # No auth dependency — this is loaded directly via <img src>, which can't send an
    # Authorization header. Same exposure as the old public-GCS-URL approach (an
    # unguessable uuid4 filename), just proxied through our own service-account
    # credentials instead of requiring the bucket itself to be public.
    contents, content_type = service.get_logo_bytes(file_name)
    return Response(content=contents, media_type=content_type)


# ------------------------------------------------------------------ #
# Synchronous exports                                                  #
# ------------------------------------------------------------------ #

@router.post(TemplateRoutes.EXPORT_PDF)
def export_template_pdf(template_id: int, db: Session = Depends(get_db), current_user: User = _reports_read):
    template = service.get_by_id(db, template_id)
    if not template:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Template not found")

    try:
        pdf_bytes = service.build_pdf(template)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("PDF generation failed for template %s", template_id)
        raise HTTPException(status_code=500, detail=f"PDF generation failed: {exc}") from exc

    filename = template.name.replace(" ", "_") + ".pdf"
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Content-Length": str(len(pdf_bytes)),
        },
    )


@router.post(TemplateRoutes.EXPORT_EXCEL)
def export_template_excel(template_id: int, db: Session = Depends(get_db), current_user: User = _reports_read):
    template = service.get_by_id(db, template_id)
    if not template:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Template not found")

    try:
        excel_bytes = service.build_excel(template)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Excel generation failed for template %s", template_id)
        raise HTTPException(status_code=500, detail=f"Excel generation failed: {exc}") from exc

    filename = template.name.replace(" ", "_") + ".xlsx"
    return Response(
        content=excel_bytes,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Content-Length": str(len(excel_bytes)),
        },
    )


# ------------------------------------------------------------------ #
# Async exports — start / poll / download                             #
# ------------------------------------------------------------------ #

@router.post(TemplateRoutes.EXPORT_PDF_ASYNC, status_code=status.HTTP_202_ACCEPTED)
def start_pdf_export(template_id: int, db: Session = Depends(get_db), current_user: User = _reports_read):
    template = service.get_by_id(db, template_id)
    if not template:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Template not found")

    cleanup_old_jobs()
    job_id = uuid4().hex
    create_job(job_id)
    snapshot = _template_snapshot(template)

    threading.Thread(target=_run_export, args=(job_id, _build_pdf, snapshot), daemon=True).start()
    logger.info("Async PDF export started: job=%s template=%s", job_id, template_id)
    return {"job_id": job_id, "status": "pending"}


@router.post(TemplateRoutes.EXPORT_EXCEL_ASYNC, status_code=status.HTTP_202_ACCEPTED)
def start_excel_export(template_id: int, db: Session = Depends(get_db), current_user: User = _reports_read):
    template = service.get_by_id(db, template_id)
    if not template:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Template not found")

    cleanup_old_jobs()
    job_id = uuid4().hex
    create_job(job_id)
    snapshot = _template_snapshot(template)

    threading.Thread(target=_run_export, args=(job_id, _build_excel, snapshot), daemon=True).start()
    logger.info("Async Excel export started: job=%s template=%s", job_id, template_id)
    return {"job_id": job_id, "status": "pending"}


@router.get(TemplateRoutes.EXPORT_JOB_STATUS)
def get_export_job_status(job_id: str, current_user: User = _reports_read):
    job = get_job(job_id)
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found")
    resp = {"job_id": job_id, "status": job.status}
    if job.status == "error":
        resp["error"] = job.error
    return resp


@router.get(TemplateRoutes.EXPORT_JOB_DOWNLOAD)
def download_export_job(job_id: str, current_user: User = _reports_read):
    job = get_job(job_id)
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found")
    if job.status == "pending":
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Export not ready yet")
    if job.status == "error":
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=job.error)

    content, media_type, filename = job.content, job.media_type, job.filename
    pop_job(job_id)  # free memory after download

    return Response(
        content=content,
        media_type=media_type,
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Content-Length": str(len(content)),
        },
    )
