from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, EmailStr, ConfigDict
from sqlalchemy.orm import Session

from app.api.dependencies import get_db, get_current_user, require_permission
from app.core.config import settings
from app.core.endpoints import UserRoutes
from app.models.user import User
from app.schemas.role import AccessLevel, Module
from app.schemas.user import UserCreate, UserInviteResponse, UserRead
from app.services.auth_service import AuthService
from app.services.user_service import UserService
from app.utils.mailer import send_activation_email

router = APIRouter()
service = UserService()
auth_service = AuthService()


class UserUpdate(BaseModel):
    username: Optional[str] = None
    email: Optional[EmailStr] = None
    role_id: Optional[UUID] = None
    is_active: Optional[bool] = None


class UserListRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    username: str
    email: EmailStr
    is_active: bool
    role_name: Optional[str] = None


@router.post(UserRoutes.LIST_CREATE, response_model=UserInviteResponse)
def create_user(
    user_in: UserCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permission(Module.USERS, AccessLevel.EDIT)),
):
    if service.get_by_username(db, user_in.username):
        raise HTTPException(status_code=400, detail="Username already exists")
    if service.get_by_email(db, user_in.email):
        raise HTTPException(status_code=400, detail="Email already exists")

    user = service.create_user(db, user_in)
    activation_token = auth_service.create_activation_token(user)
    activation_url = f"{settings.frontend_url}/create-password?token={activation_token}"
    send_activation_email(user.email, user.username, activation_url)

    return UserInviteResponse.model_validate(
        {
            **UserRead.model_validate(user).model_dump(),
            "activation_url": activation_url,
        }
    )


@router.get(UserRoutes.ME, response_model=UserRead)
def read_current_user(current_user=Depends(get_current_user)):
    return current_user


@router.get(UserRoutes.LIST_CREATE, response_model=List[UserListRead])
def list_users(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permission(Module.USERS, AccessLevel.READ)),
):
    users = service.get_users(db)
    return [
        UserListRead(
            id=user.id,
            username=user.username,
            email=user.email,
            is_active=user.is_active,
            role_name=user.role.name if user.role else None,
        )
        for user in users
    ]


@router.put(UserRoutes.BY_ID, response_model=UserRead)
def update_user_by_admin(
    user_id: UUID,
    user_update: UserUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permission(Module.USERS, AccessLevel.EDIT)),
):
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found",
        )

    if user_update.username is not None:
        user.username = user_update.username
    if user_update.email is not None:
        user.email = user_update.email
    if user_update.role_id is not None:
        user.role_id = user_update.role_id
    if user_update.is_active is not None:
        user.is_active = user_update.is_active

    db.commit()
    db.refresh(user)
    return user


@router.delete(UserRoutes.BY_ID, status_code=status.HTTP_204_NO_CONTENT)
def delete_user(
    user_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permission(Module.USERS, AccessLevel.EDIT)),
):
    if user_id == current_user.id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="You cannot delete your own account",
        )

    user = service.get_by_id(db, user_id)
    if user is None or user.is_deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found",
        )

    service.delete_user(db, user)
    return None