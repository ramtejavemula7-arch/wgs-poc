from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.dependencies import get_db, require_permission
from app.models.role import Role
from app.models.user import User
from app.schemas.role import AccessLevel, Module, RoleCreate, RoleRead, RoleUpdate, RolePermissionsUpdate
from app.services.role_service import RoleService
from app.core.endpoints import RoleRoutes

router = APIRouter(tags=["roles"])
service = RoleService()


@router.post(RoleRoutes.LIST_CREATE, response_model=RoleRead, status_code=status.HTTP_201_CREATED)
def create_role(
    role_in: RoleCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permission(Module.ROLES, AccessLevel.EDIT)),
):
    exists = service.get_by_name(db, role_in.name)
    if exists:
        raise HTTPException(status_code=400, detail="Role already exists")
    role = service.create_role(db, role_in, created_by=current_user.id)
    return service.to_role_read(role)


@router.get(RoleRoutes.LIST_CREATE, response_model=list[RoleRead])
def list_roles(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permission(Module.ROLES, AccessLevel.READ)),
):
    return [service.to_role_read(role) for role in service.list_roles(db)]


@router.get(RoleRoutes.BY_ID, response_model=RoleRead)
def get_role(
    role_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permission(Module.ROLES, AccessLevel.READ)),
):
    role = service.get_by_id(db, role_id)
    if not role:
        raise HTTPException(status_code=404, detail="Role not found")
    return service.to_role_read(role)


@router.put(RoleRoutes.BY_ID, response_model=RoleRead)
def update_role(
    role_id: UUID,
    role_in: RoleUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permission(Module.ROLES, AccessLevel.EDIT)),
):
    role = service.get_by_id(db, role_id)
    if not role:
        raise HTTPException(status_code=404, detail="Role not found")

    if role_in.name:
        duplicate = service.get_by_name(db, role_in.name)
        if duplicate and duplicate.id != role_id:
            raise HTTPException(status_code=400, detail="Role already exists")

    role = service.update_role(db, role, role_in)
    return service.to_role_read(role)


@router.delete(RoleRoutes.BY_ID, status_code=status.HTTP_204_NO_CONTENT)
def delete_role(
    role_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permission(Module.ROLES, AccessLevel.EDIT)),
):
    role = service.get_by_id(db, role_id)
    if not role:
        raise HTTPException(status_code=404, detail="Role not found")
    service.delete_role(db, role)
    return None


@router.put(RoleRoutes.PERMISSIONS, response_model=RoleRead)
def set_role_permissions(
    role_id: UUID,
    permissions_in: RolePermissionsUpdate,
    db: Session = Depends(get_db),
    _admin: User = Depends(require_permission(Module.ROLES, AccessLevel.EDIT)),
):
    role = service.get_by_id(db, role_id)
    if not role:
        raise HTTPException(status_code=404, detail="Role not found")
    if service.is_admin_role(role):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Admin permissions are fixed in code and cannot be modified",
        )
    role = service.set_permissions(db, role, permissions_in.permissions)
    return service.to_role_read(role)
