import uuid

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.dependencies import get_current_user
from app.core.config import settings
from app.core.database import get_db
from app.core.endpoints import ChatRoutes
from app.core.rate_limit import InMemoryRateLimiter
from app.models.user import User
from app.schemas.chat import ChatRequest, ChatResponse
from app.services.assistant_service import AssistantService
from app.services.gemini_service import DataAgentOption, _list_data_agents

router = APIRouter(prefix=ChatRoutes.PREFIX, tags=["chat"])
service = AssistantService()
_rate_limiter = InMemoryRateLimiter(max_requests=settings.chat_rate_limit_per_minute, window_seconds=60)


@router.post(ChatRoutes.ASK, response_model=ChatResponse)
def ask_chat(
    payload: ChatRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _rate_limiter.check(str(current_user.id))
    session_id = payload.session_id or str(uuid.uuid4())
    result = service.ask(payload.question, db, session_id, agent_name=payload.data_agent)
    return ChatResponse(
        answer=result.answer,
        sql=result.sql,
        table=result.table,
        chart=result.chart,
        intent=result.intent,
        confidence=result.confidence,
        follow_ups=result.follow_ups,
        session_id=result.session_id,
    )


@router.get(ChatRoutes.AGENTS, response_model=list[DataAgentOption])
def list_chat_agents(current_user: User = Depends(get_current_user)):
    """Lists published BigQuery Data Agents for the Chat Assistant's
    per-question agent picker — any logged-in user who can reach Chat
    Assistant can call this, same auth level as asking a question."""
    return _list_data_agents()
