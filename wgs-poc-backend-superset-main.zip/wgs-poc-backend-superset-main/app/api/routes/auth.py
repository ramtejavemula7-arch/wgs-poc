from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.api.dependencies import get_current_user, get_db, require_permission
from app.models.user import User
from app.schemas.auth import ActivateAccountRequest, LoginRequest, Token
from app.schemas.role import AccessLevel, Module
from app.schemas.user import UserCreate, UserInviteResponse, UserRead
from app.services.auth_service import AuthService
from app.services.user_service import UserService
from app.core.config import settings
from app.core.endpoints import AuthRoutes
from app.utils.mailer import send_activation_email

router = APIRouter()
auth_service = AuthService()
user_service = UserService()


@router.post(AuthRoutes.SIGNUP, response_model=UserInviteResponse, status_code=status.HTTP_201_CREATED)
def signup(
    user_in: UserCreate,
    db: Session = Depends(get_db),
    _: User = Depends(require_permission(Module.USERS, AccessLevel.EDIT)),
):
    if user_service.get_by_username(db, user_in.username):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Username already exists")
    if user_service.get_by_email(db, user_in.email):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Email already exists")
    user = user_service.create_user(db, user_in)
    activation_token = auth_service.create_activation_token(user)
    activation_url = f"{settings.frontend_url}/create-password?token={activation_token}"
    send_activation_email(user.email, user.username, activation_url)
    return UserInviteResponse.model_validate(
        {
            **UserRead.model_validate(user).model_dump(),
            "activation_url": activation_url,
        }
    )


@router.post(AuthRoutes.LOGIN, response_model=Token)
def login(credentials: LoginRequest, db: Session = Depends(get_db)):
    user = auth_service.authenticate_user(db, credentials.email, credentials.password)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Incorrect email or password")
    return auth_service.create_token(user)


@router.post(AuthRoutes.ACTIVATE, response_model=UserRead)
def activate_account(payload: ActivateAccountRequest, db: Session = Depends(get_db)):
    user_id = auth_service.decode_activation_token(payload.token)
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    if user.hashed_password and user.is_active:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Account is already activated")
    return user_service.set_password(db, user, payload.password)


@router.post(AuthRoutes.LOGOUT)
def logout(current_user=Depends(get_current_user)):
    return {"message": "Successfully logged out"}
