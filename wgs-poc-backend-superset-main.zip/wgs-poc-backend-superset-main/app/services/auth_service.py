from uuid import UUID
from datetime import timedelta
from fastapi import HTTPException, status
from sqlalchemy.orm import Session
from jose import JWTError, jwt

from app.core.config import settings
from app.core.security import verify_password, create_access_token
from app.models.user import User
from app.schemas.auth import Token


class AuthService:
    def authenticate_user(self, db: Session, email: str, password: str):
        user = db.query(User).filter(User.email == email).first()
        if (
            not user
            or not user.is_active
            or user.is_deleted
            or not user.hashed_password
            or not verify_password(password, user.hashed_password)
        ):
            return None
        return user

    def create_token(self, user: User) -> Token:
        role_name = user.role.name if user.role else None
        access_token = create_access_token(
            data={
                "sub": str(user.id),
                "role": role_name,
                "user_id": str(user.id),
            }
        )
        return Token(
            access_token=access_token,
            token_type="bearer",
            role=role_name,
            user_id=user.id,
        )

    def create_activation_token(self, user: User) -> str:
        return create_access_token(
            data={"sub": str(user.id), "purpose": "activate"},
            expires_delta=timedelta(hours=settings.activation_token_expire_hours),
        )

    def decode_activation_token(self, token: str) -> UUID:
        try:
            payload = jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm])
            if payload.get("purpose") != "activate":
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid activation token",
                )

            user_id = payload.get("sub")
            if not user_id:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid activation token",
                )

            return UUID(user_id)

        except (JWTError, ValueError):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid or expired activation token",
            )