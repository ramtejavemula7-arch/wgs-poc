from uuid import UUID

from sqlalchemy.orm import Session, joinedload

from app.core.security import get_password_hash
from app.models.user import User
from app.schemas.user import UserCreate


class UserService:
    def get_by_username(self, db: Session, username: str):
        return db.query(User).filter(User.username == username).first()

    def get_by_email(self, db: Session, email: str):
        return db.query(User).filter(User.email == email).first()

    def get_by_id(self, db: Session, user_id: UUID):
        return db.query(User).filter(User.id == user_id).first()

    def create_user(self, db: Session, user_in: UserCreate):
        user = User(
            username=user_in.username,
            email=user_in.email,
            role_id=user_in.role_id,
            is_active=False,
            is_deleted=False,
            hashed_password=None,
        )
        db.add(user)
        db.commit()
        db.refresh(user)
        return user

    def set_password(self, db: Session, user: User, password: str):
        user.hashed_password = get_password_hash(password)
        user.is_active = True
        db.add(user)
        db.commit()
        db.refresh(user)
        return user

    def update_user(
        self,
        db: Session,
        user: User,
        *,
        username=None,
        email=None,
        role_id=None,
        is_active=None,
    ):
        if username is not None:
            user.username = username
        if email is not None:
            user.email = email
        if role_id is not None:
            user.role_id = role_id
        if is_active is not None:
            user.is_active = is_active

        db.add(user)
        db.commit()
        db.refresh(user)
        return user

    def get_users(self, db: Session):
        return (
            db.query(User)
            .options(joinedload(User.role))
            .filter(User.is_deleted.is_(False))
            .all()
        )

    def delete_user(self, db: Session, user: User):
        """Soft delete — the row is kept (audit trail, FK references stay intact) and just
        flagged so it drops out of get_users() and can no longer authenticate."""
        user.is_deleted = True
        db.add(user)
        db.commit()