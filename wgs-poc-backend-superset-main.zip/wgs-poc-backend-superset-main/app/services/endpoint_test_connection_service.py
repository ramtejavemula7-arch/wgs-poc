import time
from typing import Any

import requests

from app.models.endpoint_registration import EndpointRegistration
from app.schemas.endpoint_registration import EndpointRegistrationTestDraft, TestConnectionResult
from app.services.endpoint_auth_handlers import OutboundRequestSpec, get_auth_handler
from app.services.endpoint_registration_service import EndpointRegistrationService

# Cap the raw response text sent back to the caller — arbitrary registered
# endpoints could return a pathologically large body, and this is a
# debugging aid, not a data-fetch path. Confirmed directly: a plain list
# response (e.g. jsonplaceholder.typicode.com/posts, ~27KB) already exceeded
# a smaller cap and got sliced mid-JSON, breaking the frontend's table
# preview entirely — ordinary API responses routinely run into the tens to
# low hundreds of KB, so the cap needs real headroom above that, not just
# above a single record.
_MAX_RAW_RESPONSE_CHARS = 1_000_000


def _build_url(base_url: str, endpoint_path: str | None) -> str:
    base = base_url.rstrip("/")
    path = (endpoint_path or "").lstrip("/")
    return f"{base}/{path}" if path else base


def _run_request(
    base_url: str,
    endpoint_path: str | None,
    http_method: str,
    timeout: int,
    custom_headers: list[dict[str, str]],
    query_params: list[dict[str, str]],
    auth_type: str,
    auth_config: dict[str, Any],
    secret_value: str | None,
) -> TestConnectionResult:
    spec = OutboundRequestSpec()
    for h in custom_headers:
        spec.headers[h["name"]] = h["value"]
    for p in query_params:
        spec.params[p["name"]] = p["value"]

    get_auth_handler(auth_type).apply(spec, auth_config, secret_value)

    url = _build_url(base_url, endpoint_path)
    t0 = time.perf_counter()
    try:
        # Real cert validation by default (verify defaults to True) — unlike
        # app/api/routes/superset.py's verify=False, which only exists there
        # for Superset's own self-signed cert, not a general convention.
        resp = requests.request(
            method=http_method,
            url=url,
            headers=spec.headers,
            params=spec.params,
            cookies=spec.cookies,
            auth=spec.auth,
            timeout=timeout,
        )
        elapsed_ms = int((time.perf_counter() - t0) * 1000)
        return TestConnectionResult(
            status_code=resp.status_code,
            elapsed_ms=elapsed_ms,
            success=resp.ok,
            message="Request succeeded" if resp.ok else f"Request failed with status {resp.status_code}",
            raw_response=resp.text[:_MAX_RAW_RESPONSE_CHARS],
        )
    except requests.RequestException as exc:
        elapsed_ms = int((time.perf_counter() - t0) * 1000)
        return TestConnectionResult(
            status_code=None,
            elapsed_ms=elapsed_ms,
            success=False,
            message=f"Request failed: {exc}",
            raw_response=None,
        )


class EndpointTestConnectionService:
    def __init__(self, registration_service: EndpointRegistrationService | None = None) -> None:
        self._registrations = registration_service or EndpointRegistrationService()

    def test_saved(self, endpoint: EndpointRegistration) -> TestConnectionResult:
        secret_value = self._registrations.resolve_secret(endpoint)
        return _run_request(
            endpoint.base_url,
            endpoint.endpoint_path,
            endpoint.http_method,
            endpoint.timeout,
            endpoint.custom_headers or [],
            endpoint.query_params or [],
            endpoint.auth_type,
            endpoint.auth_config or {},
            secret_value,
        )

    def test_draft(self, payload: EndpointRegistrationTestDraft) -> TestConnectionResult:
        return _run_request(
            payload.base_url,
            payload.endpoint_path,
            payload.http_method,
            payload.timeout,
            [h.model_dump() for h in payload.custom_headers],
            [p.model_dump() for p in payload.query_params],
            payload.auth_type,
            payload.auth_config,
            payload.secret_value,
        )
