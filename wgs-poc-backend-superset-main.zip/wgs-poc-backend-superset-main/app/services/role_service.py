from uuid import UUID

from sqlalchemy.orm import Session
from app.models.role import Role
from app.models.permission import RolePermission
from app.schemas.role import AccessLevel, Module, RoleCreate, RoleRead, RoleUpdate, RolePermissionIn, RolePermissionRead

ADMIN_ROLE_NAME = "admin"


class RoleService:
    def get_by_id(self, db: Session, role_id: UUID):
        return db.query(Role).filter(Role.id == role_id).first()

    def get_by_name(self, db: Session, name: str):
        return db.query(Role).filter(Role.name == name).first()

    def list_roles(self, db: Session):
        return db.query(Role).order_by(Role.id.desc()).all()

    def create_role(self, db: Session, role_in: RoleCreate, created_by: UUID | None = None):
        role = Role(
            name=role_in.name.strip(),
            created_by=created_by,
        )
        db.add(role)
        db.commit()
        db.refresh(role)

        # New roles start with Read access everywhere rather than no explicit permission rows —
        # "none" is no longer a choice an admin can pick, so nothing should default to it either.
        for module in Module:
            db.add(RolePermission(role_id=role.id, module=module.value, access_level=AccessLevel.READ.value))
        db.commit()
        db.refresh(role)
        return role

    def update_role(self, db: Session, role: Role, role_in: RoleUpdate):
        if role_in.name is not None:
            role.name = role_in.name.strip()
        db.commit()
        db.refresh(role)
        return role

    def delete_role(self, db: Session, role: Role):
        db.delete(role)
        db.commit()

    def is_admin_role(self, role: Role) -> bool:
        return role.name.strip().casefold() == ADMIN_ROLE_NAME

    def get_permissions(self, role: Role) -> list[RolePermissionRead]:
        if self.is_admin_role(role):
            return [RolePermissionRead(module=module, access_level=AccessLevel.EDIT) for module in Module]
        return [RolePermissionRead.model_validate(p) for p in role.permissions]

    def to_role_read(self, role: Role) -> RoleRead:
        return RoleRead(
            id=role.id,
            name=role.name,
            created_by=role.created_by,
            created_at=role.created_at,
            permissions=self.get_permissions(role),
        )

    def set_permissions(self, db: Session, role: Role, permissions_in: list[RolePermissionIn]):
        db.query(RolePermission).filter(RolePermission.role_id == role.id).delete()
        for perm in permissions_in:
            db.add(RolePermission(role_id=role.id, module=perm.module.value, access_level=perm.access_level.value))
        db.commit()
        db.refresh(role)
        return role
