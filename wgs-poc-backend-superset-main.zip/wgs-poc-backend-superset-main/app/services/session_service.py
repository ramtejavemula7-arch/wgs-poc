"""In-memory chat session store.

Keeps recent turns per session so CONTEXT-intent questions ("what about last
month?", "summarize what we discussed") can be answered without a fresh
BigQuery/RAG call. Process-local and unbounded across sessions (fine for a
single-instance POC) — swap for a Postgres-backed table or Redis if this
needs to survive restarts or run across multiple workers.
"""

from __future__ import annotations

import threading
from collections import deque

from app.core.config import settings

_lock = threading.Lock()
_sessions: dict[str, deque[tuple[str, str]]] = {}


def add_message(session_id: str, role: str, content: str) -> None:
    """Append a turn to the session's history, trimming to the configured window."""
    max_turns = settings.chat_session_context_messages
    with _lock:
        history = _sessions.setdefault(session_id, deque(maxlen=max_turns * 2))
        history.append((role, content))


def get_context(session_id: str) -> str:
    """Return the session's recent history formatted for prompt injection, or "" if empty."""
    with _lock:
        history = _sessions.get(session_id)
        if not history:
            return ""
        turns = list(history)

    lines = [f"{role.capitalize()}: {content}" for role, content in turns]
    return "\n".join(lines)
