from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from fastapi import HTTPException


@dataclass
class OutboundRequestSpec:
    """What an AuthHandler is allowed to mutate on the outbound test/probe
    request — kept separate from the actual `requests` call so handlers
    never touch method/url/timeout/body, only auth-related placement."""
    headers: dict[str, str] = field(default_factory=dict)
    params: dict[str, str] = field(default_factory=dict)
    cookies: dict[str, str] = field(default_factory=dict)
    auth: tuple[str, str] | None = None  # requests-compatible (username, password)


class AuthHandler(ABC):
    @abstractmethod
    def apply(self, spec: OutboundRequestSpec, auth_config: dict[str, Any], secret_value: str | None) -> None:
        """Mutate `spec` in place for this auth type. `secret_value` is the
        actual credential (already resolved from Secret Manager, or taken
        straight from a draft test request) — never persisted by handlers
        themselves."""


class NoneAuthHandler(AuthHandler):
    def apply(self, spec: OutboundRequestSpec, auth_config: dict[str, Any], secret_value: str | None) -> None:
        return


class ApiKeyAuthHandler(AuthHandler):
    def apply(self, spec: OutboundRequestSpec, auth_config: dict[str, Any], secret_value: str | None) -> None:
        name = auth_config["api_key_name"]
        target = {"header": spec.headers, "query": spec.params, "cookie": spec.cookies}[auth_config.get("send_in", "header")]
        target[name] = secret_value or ""


class BasicAuthHandler(AuthHandler):
    def apply(self, spec: OutboundRequestSpec, auth_config: dict[str, Any], secret_value: str | None) -> None:
        spec.auth = (auth_config["username"], secret_value or "")


class BearerTokenAuthHandler(AuthHandler):
    def apply(self, spec: OutboundRequestSpec, auth_config: dict[str, Any], secret_value: str | None) -> None:
        spec.headers["Authorization"] = f"Bearer {secret_value or ''}"


# Registry + decorator: adding a new auth type later (OAuth2/JWT/HMAC/mTLS/
# Custom Headers) is exactly one new decorated class — zero edits to
# existing handlers or to get_auth_handler().
_REGISTRY: dict[str, type[AuthHandler]] = {}


def register_auth_handler(auth_type: str):
    def _wrap(cls: type[AuthHandler]) -> type[AuthHandler]:
        _REGISTRY[auth_type] = cls
        return cls
    return _wrap


register_auth_handler("none")(NoneAuthHandler)
register_auth_handler("api_key")(ApiKeyAuthHandler)
register_auth_handler("basic_auth")(BasicAuthHandler)
register_auth_handler("bearer_token")(BearerTokenAuthHandler)


def get_auth_handler(auth_type: str) -> AuthHandler:
    cls = _REGISTRY.get(auth_type)
    if cls is None:
        raise HTTPException(status_code=400, detail=f"Unsupported auth_type: {auth_type!r}")
    return cls()
