"""In-memory semantic cache for chat responses and SQL/RAG tool results.

Ported from Tensor's `tools/cache.py`. Fine for this app's single-uvicorn-
worker deployment (see docker-compose.yml); would need a shared backend
(e.g. Redis) if this app is ever run with multiple workers, since each
worker would otherwise keep its own cache.
"""

from __future__ import annotations

import hashlib
import re
import threading
import time
from collections import OrderedDict
from typing import Any

from app.core.config import settings


class SemanticCache:
    """In-memory LRU cache with TTL for query responses."""

    def __init__(self, max_entries: int = 1000, ttl_seconds: int = 300) -> None:
        self._cache: OrderedDict[str, tuple[float, Any]] = OrderedDict()
        self._lock = threading.Lock()
        self.max_entries = max_entries
        self.ttl_seconds = ttl_seconds

    @staticmethod
    def _normalize_query(query: str) -> str:
        q = query.lower().strip()
        q = re.sub(r"[^\w\s]", "", q)
        return re.sub(r"\s+", " ", q)

    @staticmethod
    def _make_key(query: str, user_scope: str = "") -> str:
        raw = f"{query}|{user_scope}"
        return hashlib.md5(raw.encode()).hexdigest()

    def get(self, query: str, user_scope: str = "") -> Any | None:
        key = self._make_key(self._normalize_query(query), user_scope)
        with self._lock:
            if key not in self._cache:
                return None
            timestamp, value = self._cache[key]
            if time.time() - timestamp > self.ttl_seconds:
                del self._cache[key]
                return None
            self._cache.move_to_end(key)
            return value

    def set(self, query: str, value: Any, user_scope: str = "") -> None:
        key = self._make_key(self._normalize_query(query), user_scope)
        with self._lock:
            self._cache[key] = (time.time(), value)
            self._cache.move_to_end(key)
            while len(self._cache) > self.max_entries:
                self._cache.popitem(last=False)

    def invalidate_all(self) -> None:
        with self._lock:
            self._cache.clear()

    @property
    def size(self) -> int:
        return len(self._cache)


class ToolCache:
    """Per-tool cache with independent TTLs — SQL results change less often
    than nothing, RAG results (documents) change less often still."""

    def __init__(self) -> None:
        self._sql_cache = SemanticCache(max_entries=500, ttl_seconds=settings.chat_sql_cache_ttl_seconds)
        self._rag_cache = SemanticCache(max_entries=500, ttl_seconds=settings.chat_rag_cache_ttl_seconds)

    def get_sql(self, query: str) -> dict | None:
        return self._sql_cache.get(query, user_scope="sql")

    def set_sql(self, query: str, result: dict) -> None:
        self._sql_cache.set(query, result, user_scope="sql")

    def get_rag(self, query: str) -> dict | None:
        return self._rag_cache.get(query, user_scope="rag")

    def set_rag(self, query: str, result: dict) -> None:
        self._rag_cache.set(query, result, user_scope="rag")

    def invalidate_all(self) -> None:
        self._sql_cache.invalidate_all()
        self._rag_cache.invalidate_all()


_response_cache: SemanticCache | None = None
_tool_cache: ToolCache | None = None


def get_response_cache() -> SemanticCache:
    """Singleton cache for full chat responses, keyed by question (+ session)."""
    global _response_cache
    if _response_cache is None:
        _response_cache = SemanticCache(
            max_entries=1000,
            ttl_seconds=settings.chat_cache_ttl_seconds,
        )
    return _response_cache


def get_tool_cache() -> ToolCache:
    """Singleton cache for SQL/RAG tool results, independent of the response cache."""
    global _tool_cache
    if _tool_cache is None:
        _tool_cache = ToolCache()
    return _tool_cache
