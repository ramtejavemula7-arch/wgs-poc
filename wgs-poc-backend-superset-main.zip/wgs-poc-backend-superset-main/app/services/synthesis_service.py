"""Synthesis — merges BigQuery SQL results with RAG document chunks into one
response with dual citations (📊 data / 📎 documents), plus a confidence
score and follow-up suggestions.

GeminiService only returns raw rows from BigQuery (there's no Data Agent
summarizing them anymore), so this is where the actual data analysis
happens — reasoning over `sql_result["rows"]` to produce the answer, not
just formatting a pre-written summary.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any

from app.core.config import settings
from app.services.vertex_ai_client import build_vertex_ai_client

logger = logging.getLogger(__name__)

_SYNTHESIS_INSTRUCTION = """You are the expert answer-synthesis step for an enterprise analytics chat assistant.
{conversation_context}
## Available Context
- SQL query result (if available): <<<SQL_RESULTS>>>
- Document search result (if available): <<<RAG_RESULTS>>>

## RESPONSE STRUCTURE — follow this precisely:

### For SQL-only answers (data questions):
1. **Key Finding** — the most important insight in 1-2 sentences.
2. **Data Analysis** — patterns/trends, what stands out (highest/lowest, outliers), why the
   numbers might look this way, comparisons (e.g. "X is 3x larger than Y").
3. **Detailed Breakdown** — key data points, numbered lists for rankings, bold for important
   numbers, percentage shares where relevant.
4. **Implications** — what this means for the business.

### For RAG-only answers (document questions):
1. **Direct Answer** — answer clearly in 1-2 sentences.
2. **Key Details** — bullet points for policy items/requirements/steps, quote specific numbers,
   dates, thresholds, or criteria, reference specific sections where possible.
3. **Context & Explanation** — why the policy exists, who it applies to, key exceptions.
4. **Practical Takeaway** — what the user should know or do.

### For HYBRID answers (data + documents):
1. **Integrated Summary** — combine both in 2-3 sentences.
2. **Data Perspective** — what the numbers show (with 📊 citations).
3. **Document Perspective** — what the policies/documents say (with 📎 citations).
4. **Cross-Analysis** — explicitly connect data to documents (e.g. "the SLA target is X per the
   handbook, but actual performance is Y").
5. **Recommendations** — based on both data and policy.

### For CONTEXT answers (conversation follow-ups):
1. Answer directly from the conversation history provided.
2. Reference specific prior exchanges — what was asked and answered.
3. Synthesize across exchanges — connect themes/patterns.
4. Include key data points repeated from earlier responses.
5. Suggest next steps based on the conversation.

## Citation Rules — mandatory for every factual claim
- Data from BigQuery: 📊 *Source: BigQuery*
- Information from documents: 📎 *Source: document_name*
- Place citations inline, immediately after the claim.
- For HYBRID answers, include both kinds of citations and explicitly connect them.

## Quality Standards
- Be specific: cite exact numbers, not vague quantities.
- Be analytical: don't just list data — explain WHY and WHAT IT MEANS.
- Be structured: use markdown headers, bold, bullet points, numbered lists.
- Be honest: state clearly if data is incomplete or a source is unavailable.
- Never fabricate — only cite what actually appears in the results above.
- For CONTEXT questions, answer only from the conversation history; do not invent new data.

At the end of your answer, add:
FOLLOW_UPS: ["relevant follow-up question 1", "relevant follow-up question 2", "relevant follow-up question 3"]
CONFIDENCE: 0.XX"""


def synthesize_answer(
    question: str,
    intent: str,
    sql_result: dict[str, Any] | None,
    rag_result: dict[str, Any] | None,
    conversation_context: str = "",
) -> str:
    """Return the raw synthesis text, including trailing FOLLOW_UPS/CONFIDENCE markers."""
    instruction = _SYNTHESIS_INSTRUCTION.format(
        conversation_context=f"## Conversation History\n{conversation_context}\n" if conversation_context else "",
    )
    instruction = instruction.replace(
        "<<<SQL_RESULTS>>>",
        json.dumps(sql_result, default=str) if sql_result else "No SQL results available",
    )
    instruction = instruction.replace(
        "<<<RAG_RESULTS>>>",
        json.dumps(rag_result, default=str) if rag_result else "No document results available",
    )

    prompt_parts = [f"## User Question\n{question}\n", f"## Intent: {intent}\n"]
    if sql_result and sql_result.get("answer"):
        prompt_parts.append(f"## Query Summary\n{sql_result['answer']}\n")
    if sql_result and sql_result.get("rows"):
        prompt_parts.append(
            f"## Data Rows ({len(sql_result['rows'])} results)\n{json.dumps(sql_result['rows'][:20], default=str)}\n"
        )
    if rag_result and rag_result.get("chunks"):
        prompt_parts.append("## Document Chunks")
        for i, chunk in enumerate(rag_result["chunks"][:5]):
            prompt_parts.append(f"### Chunk {i + 1} (Source: {chunk.get('source', 'Unknown')})")
            prompt_parts.append(chunk.get("text", "")[:1500])
    if intent == "CONTEXT":
        prompt_parts.append("Answer using ONLY the conversation history above — make no new data calls.")
    else:
        prompt_parts.append("Provide a clear, well-structured answer with inline citations.")

    try:
        from google.genai import types

        client = build_vertex_ai_client()
        response = client.models.generate_content(
            model=settings.gemini_chat_model,
            contents="\n".join(prompt_parts),
            config=types.GenerateContentConfig(
                system_instruction=instruction,
                temperature=0.3,
                max_output_tokens=1024,
            ),
        )
        if response.text:
            return response.text
    except Exception as exc:
        logger.error("Synthesis failed, falling back to raw source text: %s", exc)

    # Fallback: stitch together whatever raw source text is available
    parts = []
    if sql_result and sql_result.get("answer"):
        parts.append(f"📊 {sql_result['answer']}")
    if rag_result and rag_result.get("chunks"):
        for chunk in rag_result["chunks"][:3]:
            parts.append(f"📎 From {chunk.get('source', 'document')}: {chunk.get('text', '')[:200]}")
    return "\n\n".join(parts) if parts else "I wasn't able to generate a complete answer. Please try rephrasing your question."


def extract_confidence(text: str) -> float:
    match = re.search(r"CONFIDENCE:\s*(-?[\d.]+)", text)
    if match:
        try:
            return max(0.0, min(float(match.group(1)), 1.0))
        except ValueError:
            pass
    return 0.7


def extract_follow_ups(text: str) -> list[str]:
    match = re.search(r"FOLLOW_UPS:\s*(\[.*?\])", text, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1))
        except json.JSONDecodeError:
            pass
    return []


def clean_synthesis(text: str) -> str:
    text = re.sub(r"\nFOLLOW_UPS:.*$", "", text, flags=re.DOTALL)
    text = re.sub(r"\nCONFIDENCE:.*$", "", text, flags=re.DOTALL)
    return text.strip()


def calculate_confidence(
    intent_confidence: float,
    sql_result: dict[str, Any] | None,
    rag_chunks: list[dict[str, Any]] | None,
) -> float:
    """Blend intent-classification confidence with source-quality signals."""
    signals, weights = [intent_confidence], [0.4]

    if sql_result is not None:
        if sql_result.get("error"):
            signals.append(0.2)
        elif sql_result.get("answer"):
            signals.append(0.9)
        else:
            signals.append(0.5)
        weights.append(0.3)

    if rag_chunks is not None:
        if rag_chunks:
            signals.append(sum(c.get("score", 0) for c in rag_chunks) / len(rag_chunks))
        else:
            signals.append(0.2)
        weights.append(0.3)

    total_weight = sum(weights)
    return max(0.0, min(1.0, sum(s * w for s, w in zip(signals, weights)) / total_weight))
