import logging

from fastapi import HTTPException
from google.api_core.exceptions import NotFound
from google.cloud import secretmanager
from google.oauth2 import service_account

from app.core.config import settings

logger = logging.getLogger(__name__)


class SecretManagerService:
    """Thin wrapper over GCP Secret Manager — the only place in this app
    that's allowed to read/write a raw secret value. Credential loading
    mirrors app/services/vertex_ai_client.py exactly (service-account file
    via settings.google_application_credentials if set, else ADC)."""

    def __init__(self) -> None:
        self._client: secretmanager.SecretManagerServiceClient | None = None

    def _get_client(self) -> secretmanager.SecretManagerServiceClient:
        if self._client is not None:
            return self._client

        kwargs = {}
        if settings.google_application_credentials:
            try:
                kwargs["credentials"] = service_account.Credentials.from_service_account_file(
                    settings.google_application_credentials,
                    scopes=["https://www.googleapis.com/auth/cloud-platform"],
                )
            except (OSError, ValueError) as exc:
                raise HTTPException(
                    status_code=502,
                    detail=f"Failed to load Secret Manager service-account credentials: {exc}",
                ) from exc

        self._client = secretmanager.SecretManagerServiceClient(**kwargs)
        return self._client

    def create_secret(self, secret_id: str, secret_value: str) -> str:
        """Creates the secret container and its first version. Returns the
        secret's full resource name (projects/{project}/secrets/{secret_id})
        — this, not the version, is what gets stored as secret_reference."""
        client = self._get_client()
        parent = f"projects/{settings.google_cloud_project}"
        try:
            secret = client.create_secret(
                request={
                    "parent": parent,
                    "secret_id": secret_id,
                    "secret": {"replication": {"automatic": {}}},
                }
            )
            client.add_secret_version(
                request={
                    "parent": secret.name,
                    "payload": {"data": secret_value.encode("utf-8")},
                }
            )
            return secret.name
        except Exception as exc:
            raise HTTPException(status_code=502, detail=f"Failed to create secret: {exc}") from exc

    def add_secret_version(self, secret_reference: str, secret_value: str) -> str:
        """Adds a new version under an EXISTING secret — used to rotate a
        credential without changing auth_type. Returns the new version's
        resource name."""
        client = self._get_client()
        try:
            version = client.add_secret_version(
                request={
                    "parent": secret_reference,
                    "payload": {"data": secret_value.encode("utf-8")},
                }
            )
            return version.name
        except Exception as exc:
            raise HTTPException(status_code=502, detail=f"Failed to rotate secret: {exc}") from exc

    def access_secret_value(self, secret_reference: str, version: str = "latest") -> str:
        client = self._get_client()
        try:
            response = client.access_secret_version(request={"name": f"{secret_reference}/versions/{version}"})
            return response.payload.data.decode("utf-8")
        except NotFound as exc:
            raise HTTPException(status_code=502, detail=f"Secret not found: {secret_reference}") from exc
        except Exception as exc:
            raise HTTPException(status_code=502, detail=f"Failed to access secret: {exc}") from exc

    def delete_secret(self, secret_reference: str) -> None:
        """Deletes the secret and all its versions. Idempotent — a secret
        that's already gone is not an error, since callers use this for
        best-effort cleanup (e.g. on registration delete) and must not be
        blocked by it."""
        client = self._get_client()
        try:
            client.delete_secret(request={"name": secret_reference})
        except NotFound:
            pass
        except Exception:
            logger.warning("Failed to delete secret %s — leaving it in place", secret_reference, exc_info=True)
