from datetime import datetime

from sqlalchemy import Column, DateTime, Integer, String

from app.core.database import Base


class SupersetEmbed(Base):
    __tablename__ = "superset_embeds"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    dashboard_uuid = Column(String, nullable=False, unique=True, index=True)
    # Numeric Superset dashboard ID (visible in /superset/dashboard/{id}/ URL).
    # Used to bypass UUID→ID resolution when the admin lacks can_read on Dashboard.
    superset_dashboard_id = Column(Integer, nullable=True)
    embed_url = Column(String, nullable=False)
    # BigQuery table this dashboard's chat questions should be scoped to.
    # Falls back to the global BIGQUERY_DATASET/BIGQUERY_TABLE settings when unset.
    bigquery_dataset = Column(String, nullable=True)
    bigquery_table = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)