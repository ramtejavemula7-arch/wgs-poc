from datetime import datetime
from sqlalchemy import Column, DateTime, Integer, String, JSON
from app.core.database import Base


class EndpointRegistration(Base):
    __tablename__ = "endpoint_registrations"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False, unique=True, index=True)
    description = Column(String, nullable=True)

    base_url = Column(String, nullable=False)
    endpoint_path = Column(String, nullable=True)
    http_method = Column(String, nullable=False, default="GET")
    timeout = Column(Integer, nullable=False, default=30)  # seconds
    custom_headers = Column(JSON, nullable=False, default=list)  # [{"name": ..., "value": ...}] — plain request headers, NOT auth
    query_params = Column(JSON, nullable=False, default=list)    # [{"name": ..., "value": ...}]
    status = Column(String, nullable=False, default="enabled")   # "enabled" | "disabled"

    # Per spec: the DB stores ONLY the auth type + a Secret Manager reference,
    # plus whatever non-secret structural metadata that auth type needs (e.g.
    # API Key's header name / "send in"). The actual secret value never lands
    # in this table — see app/services/secret_manager_service.py.
    auth_type = Column(String, nullable=False, default="none")  # "none"|"api_key"|"basic_auth"|"bearer_token"
    auth_config = Column(JSON, nullable=False, default=dict)     # non-secret fields for auth_type; shape varies by type
    secret_reference = Column(String, nullable=True)             # GCP Secret Manager resource name; internal use only

    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    @property
    def has_secret(self) -> bool:
        return bool(self.secret_reference)
