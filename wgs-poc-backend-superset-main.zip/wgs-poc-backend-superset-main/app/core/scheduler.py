import logging
from datetime import datetime, time as dt_time

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.date import DateTrigger

from app.core.config import settings
from app.core.database import SessionLocal
from app.services.scheduled_report_service import ScheduledReportService

logger = logging.getLogger(__name__)

_scheduler = BackgroundScheduler(timezone=settings.scheduler_timezone)
_service = ScheduledReportService()


def _job_id(schedule_id: int) -> str:
    return f"scheduled_report_{schedule_id}"


def _build_trigger(schedule):
    # BackgroundScheduler(timezone=...) above only affects the scheduler's own
    # bookkeeping — it is NOT applied to a trigger that's already a BaseTrigger
    # instance (only to one APScheduler builds itself from a string alias), so
    # each trigger needs the timezone passed explicitly or it silently falls
    # back to the host OS's local timezone (UTC on Cloud Run, unlike a dev
    # machine whose clock may already be IST-equivalent).
    if schedule.frequency == "weekly":
        return CronTrigger(
            day_of_week=schedule.day_of_week,
            hour=schedule.hour,
            minute=schedule.minute,
            timezone=settings.scheduler_timezone,
        )
    if schedule.frequency == "once":
        run_at = datetime.combine(schedule.run_date, dt_time(hour=schedule.hour, minute=schedule.minute))
        return DateTrigger(run_date=run_at, timezone=settings.scheduler_timezone)
    return CronTrigger(
        hour=schedule.hour, minute=schedule.minute, timezone=settings.scheduler_timezone
    )  # "daily"


def _run_schedule(schedule_id: int) -> None:
    db = SessionLocal()
    try:
        schedule = _service.get_by_id(db, schedule_id)
        if not schedule or not schedule.is_active:
            return
        logger.info("Running scheduled report %s", schedule_id)
        _service.send_report(db, schedule)
        if schedule.frequency == "once":
            # a one-time send is done after it fires — deactivate so the UI
            # reflects that (APScheduler's DateTrigger won't fire again anyway)
            schedule.is_active = False
            db.commit()
    except Exception:
        logger.exception("Scheduled report %s run failed", schedule_id)
    finally:
        db.close()


def remove_job(schedule_id: int) -> None:
    job_id = _job_id(schedule_id)
    if _scheduler.get_job(job_id):
        _scheduler.remove_job(job_id)


def sync_job(schedule) -> None:
    """Add/update/remove this schedule's job to match its current
    is_active/hour/minute/frequency. Call after every create/update. Safe to
    call whether the scheduler has started yet or not."""
    if not schedule.is_active:
        remove_job(schedule.id)
        return

    _scheduler.add_job(
        _run_schedule,
        _build_trigger(schedule),
        id=_job_id(schedule.id),
        args=[schedule.id],
        replace_existing=True,
        # A restart (redeploy, instance recycle, local --reload) can land right
        # on top of a fire time. Without this, APScheduler's ~1s default grace
        # window treats the reloaded job as already-missed and silently drops
        # it instead of running it. A generous grace period means a bumped job
        # still fires (a bit late) rather than vanishing without a trace.
        misfire_grace_time=24 * 60 * 60,
    )


def start_scheduler() -> None:
    """Load every active schedule's own job, then start the scheduler.
    Safe to call more than once (no-op if already running or disabled via
    settings.scheduler_enabled)."""
    if not settings.scheduler_enabled:
        logger.info("Report scheduler disabled via settings.scheduler_enabled")
        return
    if _scheduler.running:
        return

    db = SessionLocal()
    try:
        for schedule in _service.get_all(db):
            if schedule.is_active:
                sync_job(schedule)
    finally:
        db.close()

    _scheduler.start()
    logger.info("Report scheduler started with %d active job(s)", len(_scheduler.get_jobs()))
