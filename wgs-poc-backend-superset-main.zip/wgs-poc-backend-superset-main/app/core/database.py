from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

from app.core.config import settings

engine = create_engine(
    settings.database_url,
    pool_size=10,
    max_overflow=20,
    pool_pre_ping=True,      # reconnect silently if connection dropped
    pool_recycle=3600,       # recycle connections after 1 hour
    pool_timeout=10,         # fail fast if the pool is exhausted, don't hang
    connect_args={"connect_timeout": 10},  # psycopg-level TCP connect timeout (seconds)
    echo=settings.debug,     # log SQL only in debug mode
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
