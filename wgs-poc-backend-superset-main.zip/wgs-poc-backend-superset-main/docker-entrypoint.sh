#!/bin/sh
set -e

# Applies any migrations not yet in the DB — idempotent, so safe to run on
# every container start (this VM redeploys via `docker rm` + `docker run` on
# every push to main, there's no separate one-off "run migrations" step).
alembic upgrade head

exec "$@"
