"""add column_formats (per-column currency format) to templates

Revision ID: 020
Revises: 019
Create Date: 2026-07-23 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


revision = "020"
down_revision = "019"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "templates",
        sa.Column("column_formats", sa.JSON(), nullable=False, server_default="{}"),
    )
    op.alter_column("templates", "column_formats", server_default=None)


def downgrade() -> None:
    op.drop_column("templates", "column_formats")
