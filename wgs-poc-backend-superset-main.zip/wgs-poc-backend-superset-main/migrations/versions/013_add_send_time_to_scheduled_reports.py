"""add per-schedule hour/minute send time to scheduled_reports

Revision ID: 013
Revises: 012
Create Date: 2026-07-06 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


revision = "013"
down_revision = "012"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("scheduled_reports", sa.Column("hour", sa.Integer(), nullable=False, server_default="10"))
    op.add_column("scheduled_reports", sa.Column("minute", sa.Integer(), nullable=False, server_default="0"))
    op.alter_column("scheduled_reports", "hour", server_default=None)
    op.alter_column("scheduled_reports", "minute", server_default=None)


def downgrade() -> None:
    op.drop_column("scheduled_reports", "minute")
    op.drop_column("scheduled_reports", "hour")
