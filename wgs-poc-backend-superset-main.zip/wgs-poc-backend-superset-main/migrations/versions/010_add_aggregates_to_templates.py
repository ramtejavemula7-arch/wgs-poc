"""add aggregates column to templates

Revision ID: 010
Revises: 009
Create Date: 2026-07-03 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


revision = "010"
down_revision = "009"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "templates",
        sa.Column("aggregates", sa.JSON(), nullable=False, server_default="[]"),
    )
    op.alter_column("templates", "aggregates", server_default=None)


def downgrade() -> None:
    op.drop_column("templates", "aggregates")
