"""remove any stored admin role permissions (admin access is now computed in code)

Revision ID: 009
Revises: 008
Create Date: 2026-07-02 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


revision = "009"
down_revision = "008"
branch_labels = None
depends_on = None


def upgrade() -> None:
    conn = op.get_bind()
    conn.execute(
        sa.text(
            "DELETE FROM role_permissions "
            "WHERE role_id IN (SELECT id FROM roles WHERE lower(name) = 'admin')"
        )
    )


def downgrade() -> None:
    pass
