"""create endpoint_registrations table

Revision ID: 021
Revises: 020
Create Date: 2026-07-27 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


revision = "021"
down_revision = "020"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "endpoint_registrations",
        sa.Column("id", sa.Integer(), primary_key=True, index=True),
        sa.Column("name", sa.String(), nullable=False, unique=True, index=True),
        sa.Column("description", sa.String(), nullable=True),
        sa.Column("base_url", sa.String(), nullable=False),
        sa.Column("endpoint_path", sa.String(), nullable=True),
        sa.Column("http_method", sa.String(), nullable=False, server_default="GET"),
        sa.Column("timeout", sa.Integer(), nullable=False, server_default="30"),
        sa.Column("custom_headers", sa.JSON(), nullable=False, server_default="[]"),
        sa.Column("query_params", sa.JSON(), nullable=False, server_default="[]"),
        sa.Column("status", sa.String(), nullable=False, server_default="enabled"),
        sa.Column("auth_type", sa.String(), nullable=False, server_default="none"),
        sa.Column("auth_config", sa.JSON(), nullable=False, server_default="{}"),
        sa.Column("secret_reference", sa.String(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )
    for col in ("http_method", "timeout", "custom_headers", "query_params", "status", "auth_type", "auth_config"):
        op.alter_column("endpoint_registrations", col, server_default=None)


def downgrade() -> None:
    op.drop_table("endpoint_registrations")
